#!/usr/bin/env python3
"""
Enhanced Geo Validator mit umfassender deutscher PLZ-Datenbank
Verbesserte Validierung und Korrektur von Adressen
"""

import pandas as pd
import json
from datetime import datetime
import logging
from difflib import SequenceMatcher
import re

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class EnhancedGeoValidator:
    def __init__(self, enriched_file: str):
        self.enriched_file = enriched_file
        self.df = None
        self.plz_database = self._load_plz_database()
        
        self.validation_stats = {
            'total_processed': 0,
            'exact_matches': 0,
            'corrected_addresses': 0,
            'plz_corrections': 0,
            'city_corrections': 0,
            'coordinates_added': 0,
            'fuzzy_matches': 0,
            'estimated_coordinates': 0,
            'validation_rate': 0
        }
    
    def _load_plz_database(self):
        """Lädt die umfassende PLZ-Datenbank"""
        try:
            with open('comprehensive_german_plz_database.json', 'r', encoding='utf-8') as f:
                plz_db = json.load(f)
            logger.info(f"📍 Umfassende PLZ-Datenbank geladen: {len(plz_db):,} Einträge")
            return plz_db
        except FileNotFoundError:
            logger.error("❌ PLZ-Datenbank nicht gefunden! Führe zuerst comprehensive_plz_generator.py aus.")
            return {}
    
    def load_data(self):
        """Lädt die angereicherten Daten"""
        logger.info(f"📂 Lade Daten: {self.enriched_file}")
        self.df = pd.read_excel(self.enriched_file)
        logger.info(f"✅ {len(self.df):,} Datensätze geladen")
        return self.df
    
    def validate_and_enhance_addresses(self):
        """Validiert und verbessert alle Adressen"""
        logger.info("🗺️ Starte umfassende Adress-Validierung...")
        
        # Neue Spalten hinzufügen
        new_columns = {
            'geo_validated': False,
            'geo_confidence': 0.0,
            'latitude': None,
            'longitude': None,
            'state': None,
            'region_code': None,
            'geo_source': None,
            'address_corrected': False,
            'original_plz': self.df['PLZ'].copy(),
            'original_city': self.df['Ort'].copy(),
            'validation_notes': None
        }
        
        for col, default_value in new_columns.items():
            if col not in ['original_plz', 'original_city']:
                self.df[col] = default_value
        
        self.validation_stats['total_processed'] = len(self.df)
        
        for idx, row in self.df.iterrows():
            result = self._process_single_address(row)
            self._apply_validation_result(idx, result)
        
        # Berechne finale Statistiken
        self._calculate_final_statistics()
        
        logger.info(f"✅ Adress-Validierung abgeschlossen:")
        logger.info(f"   🎯 Verarbeitete Adressen: {self.validation_stats['total_processed']:,}")
        logger.info(f"   ✅ Exakte Treffer: {self.validation_stats['exact_matches']:,}")
        logger.info(f"   🔧 Korrigierte Adressen: {self.validation_stats['corrected_addresses']:,}")
        logger.info(f"   🔍 Fuzzy-Matches: {self.validation_stats['fuzzy_matches']:,}")
        logger.info(f"   📊 Gesamt-Validierungsrate: {self.validation_stats['validation_rate']:.1f}%")
        logger.info(f"   🌍 Koordinaten hinzugefügt: {self.validation_stats['coordinates_added']:,}")
        
        return self.df
    
    def _process_single_address(self, row) -> dict:
        """Verarbeitet eine einzelne Adresse"""
        plz = self._clean_plz(row.get('PLZ', ''))
        city = self._clean_city(row.get('Ort', ''))
        
        if not plz or not city:
            return {'status': 'incomplete', 'confidence': 0.0}
        
        # 1. Exakte PLZ-Match prüfen
        if plz in self.plz_database:
            db_entry = self.plz_database[plz]
            return self._validate_with_db_entry(plz, city, db_entry)
        
        # 2. Fuzzy PLZ-Matching (Tippfehler in PLZ)
        fuzzy_plz_result = self._fuzzy_plz_matching(plz, city)
        if fuzzy_plz_result['found']:
            return fuzzy_plz_result
        
        # 3. Stadt-basierte Suche
        city_result = self._city_based_search(plz, city)
        if city_result['found']:
            return city_result
        
        # 4. Regionale Schätzung
        regional_result = self._regional_estimation(plz, city)
        if regional_result['found']:
            return regional_result
        
        return {'status': 'not_found', 'confidence': 0.0}
    
    def _validate_with_db_entry(self, plz: str, city: str, db_entry: dict) -> dict:
        """Validiert Adresse gegen Datenbank-Eintrag"""
        db_city = db_entry['city'].lower()
        input_city = city.lower()
        
        # Exakte Übereinstimmung
        if input_city == db_city:
            return {
                'status': 'exact_match',
                'confidence': 1.0,
                'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                'state': db_entry['state'],
                'region_code': db_entry['region_code'],
                'source': 'plz_database_exact'
            }
        
        # Ähnlichkeits-Check
        similarity = SequenceMatcher(None, input_city, db_city).ratio()
        
        if similarity >= 0.85:
            # Hohe Ähnlichkeit - wahrscheinlich korrekt
            return {
                'status': 'high_similarity',
                'confidence': similarity,
                'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                'state': db_entry['state'],
                'region_code': db_entry['region_code'],
                'source': 'plz_database_similar',
                'suggested_city': db_entry['city'],
                'similarity_score': similarity
            }
        
        elif similarity >= 0.6:
            # Mittlere Ähnlichkeit - Korrektur vorschlagen
            return {
                'status': 'correction_suggested',
                'confidence': similarity * 0.8,  # Reduziert wegen Unsicherheit
                'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                'state': db_entry['state'],
                'region_code': db_entry['region_code'],
                'source': 'plz_database_corrected',
                'suggested_city': db_entry['city'],
                'original_city': city,
                'similarity_score': similarity,
                'correction_needed': True
            }
        
        else:
            # PLZ stimmt, aber Stadt passt nicht
            return {
                'status': 'plz_only',
                'confidence': 0.7,
                'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                'state': db_entry['state'],
                'region_code': db_entry['region_code'],
                'source': 'plz_only_match',
                'note': f'PLZ {plz} gültig, aber Stadt "{city}" unpassend (erwartet: "{db_entry["city"]}")'
            }
    
    def _fuzzy_plz_matching(self, plz: str, city: str) -> dict:
        """Sucht ähnliche PLZ (für Tippfehler)"""
        if len(plz) != 5:
            return {'found': False}
        
        # Suche PLZ mit 1-2 Zeichen Unterschied
        best_match = {'found': False, 'confidence': 0}
        
        for db_plz, db_entry in self.plz_database.items():
            # PLZ-Ähnlichkeit
            plz_similarity = SequenceMatcher(None, plz, db_plz).ratio()
            if plz_similarity < 0.8:  # Mindestens 80% PLZ-Ähnlichkeit
                continue
            
            # Stadt-Ähnlichkeit
            city_similarity = SequenceMatcher(None, city.lower(), db_entry['city'].lower()).ratio()
            
            # Kombinierte Bewertung
            combined_score = (plz_similarity * 0.4 + city_similarity * 0.6)
            
            if combined_score > best_match['confidence'] and combined_score >= 0.75:
                best_match = {
                    'found': True,
                    'status': 'fuzzy_match',
                    'confidence': combined_score,
                    'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                    'state': db_entry['state'],
                    'region_code': db_entry['region_code'],
                    'source': 'fuzzy_matching',
                    'suggested_plz': db_plz,
                    'suggested_city': db_entry['city'],
                    'plz_similarity': plz_similarity,
                    'city_similarity': city_similarity
                }
        
        return best_match
    
    def _city_based_search(self, plz: str, city: str) -> dict:
        """Sucht basierend auf Stadtnamen"""
        city_lower = city.lower()
        matches = []
        
        for db_plz, db_entry in self.plz_database.items():
            city_similarity = SequenceMatcher(None, city_lower, db_entry['city'].lower()).ratio()
            
            if city_similarity >= 0.9:  # Sehr hohe Stadt-Ähnlichkeit
                matches.append({
                    'plz': db_plz,
                    'entry': db_entry,
                    'city_similarity': city_similarity,
                    'plz_proximity': self._calculate_plz_proximity(plz, db_plz)
                })
        
        if matches:
            # Sortiere nach kombiniertem Score
            matches.sort(key=lambda x: x['city_similarity'] + x['plz_proximity'], reverse=True)
            best_match = matches[0]
            
            return {
                'found': True,
                'status': 'city_match',
                'confidence': best_match['city_similarity'] * 0.9,
                'coordinates': {'lat': best_match['entry']['lat'], 'lon': best_match['entry']['lon']},
                'state': best_match['entry']['state'],
                'region_code': best_match['entry']['region_code'],
                'source': 'city_based_search',
                'suggested_plz': best_match['plz'],
                'city_similarity': best_match['city_similarity']
            }
        
        return {'found': False}
    
    def _regional_estimation(self, plz: str, city: str) -> dict:
        """Schätzt Koordinaten basierend auf PLZ-Regionen"""
        if len(plz) < 1:
            return {'found': False}
        
        region_code = plz[0]
        
        # Sammle alle PLZ der gleichen Region
        regional_entries = []
        for db_plz, db_entry in self.plz_database.items():
            if db_plz.startswith(region_code):
                regional_entries.append(db_entry)
        
        if not regional_entries:
            return {'found': False}
        
        # Berechne Durchschnittskoordinaten für die Region
        avg_lat = sum(entry['lat'] for entry in regional_entries) / len(regional_entries)
        avg_lon = sum(entry['lon'] for entry in regional_entries) / len(regional_entries)
        
        # Häufigster Staat in der Region
        states = [entry['state'] for entry in regional_entries]
        most_common_state = max(set(states), key=states.count)
        
        # Leichte Variation basierend auf PLZ
        plz_hash = hash(plz) % 1000
        lat_variation = (plz_hash % 100 - 50) * 0.001
        lon_variation = ((plz_hash // 100) % 100 - 50) * 0.001
        
        return {
            'found': True,
            'status': 'regional_estimation',
            'confidence': 0.4,
            'coordinates': {
                'lat': round(avg_lat + lat_variation, 4),
                'lon': round(avg_lon + lon_variation, 4)
            },
            'state': most_common_state,
            'region_code': region_code,
            'source': 'regional_estimation',
            'note': f'Regionale Schätzung für PLZ-Bereich {region_code}xxxx'
        }
    
    def _calculate_plz_proximity(self, plz1: str, plz2: str) -> float:
        """Berechnet PLZ-Nähe (0-1, höher = näher)"""
        if len(plz1) != 5 or len(plz2) != 5:
            return 0.0
        
        # Numerische Differenz
        try:
            diff = abs(int(plz1) - int(plz2))
            # Normalisiere auf 0-1 (max Differenz ist 99999)
            proximity = max(0, 1 - (diff / 99999))
            return proximity
        except:
            return 0.0
    
    def _apply_validation_result(self, idx: int, result: dict):
        """Wendet Validierungsergebnis auf DataFrame an"""
        if result.get('status') in ['exact_match', 'high_similarity', 'correction_suggested', 'plz_only', 'fuzzy_match', 'city_match', 'regional_estimation']:
            self.df.at[idx, 'geo_validated'] = True
            self.df.at[idx, 'geo_confidence'] = result.get('confidence', 0)
            
            coords = result.get('coordinates', {})
            self.df.at[idx, 'latitude'] = coords.get('lat')
            self.df.at[idx, 'longitude'] = coords.get('lon')
            self.df.at[idx, 'state'] = result.get('state', '')
            self.df.at[idx, 'region_code'] = result.get('region_code', '')
            self.df.at[idx, 'geo_source'] = result.get('source', '')
            
            # Korrekturen anwenden
            if result.get('correction_needed') or result.get('suggested_city'):
                if result.get('suggested_city'):
                    self.df.at[idx, 'Ort'] = result['suggested_city']
                    self.df.at[idx, 'address_corrected'] = True
                    self.validation_stats['city_corrections'] += 1
            
            if result.get('suggested_plz'):
                self.df.at[idx, 'PLZ'] = result['suggested_plz']
                self.df.at[idx, 'address_corrected'] = True
                self.validation_stats['plz_corrections'] += 1
            
            # Notizen
            notes = []
            if result.get('note'):
                notes.append(result['note'])
            if result.get('similarity_score'):
                notes.append(f"Ähnlichkeit: {result['similarity_score']:.2f}")
            
            if notes:
                self.df.at[idx, 'validation_notes'] = "; ".join(notes)
            
            # Statistiken aktualisieren
            status = result['status']
            if status == 'exact_match':
                self.validation_stats['exact_matches'] += 1
            elif status in ['correction_suggested', 'high_similarity']:
                self.validation_stats['corrected_addresses'] += 1
            elif status == 'fuzzy_match':
                self.validation_stats['fuzzy_matches'] += 1
            elif status == 'regional_estimation':
                self.validation_stats['estimated_coordinates'] += 1
            
            self.validation_stats['coordinates_added'] += 1
    
    def _calculate_final_statistics(self):
        """Berechnet finale Statistiken"""
        total = self.validation_stats['total_processed']
        validated = self.validation_stats['coordinates_added']
        self.validation_stats['validation_rate'] = (validated / total * 100) if total > 0 else 0
    
    def _clean_plz(self, plz) -> str:
        """Bereinigt PLZ"""
        if pd.isna(plz):
            return ''
        plz_str = str(plz).strip()
        plz_clean = re.sub(r'[^\d]', '', plz_str)
        return plz_clean if len(plz_clean) == 5 else ''
    
    def _clean_city(self, city) -> str:
        """Bereinigt Ortsnamen"""
        if pd.isna(city):
            return ''
        return str(city).strip()
    
    def calculate_enhanced_geo_score(self):
        """Berechnet erweiterten Geo-Qualitäts-Score"""
        logger.info("📊 Berechne erweiterten Geo-Score...")
        
        total = len(self.df)
        
        # Verschiedene Qualitätsstufen mit Gewichtung
        scores = {
            'plz_database_exact': 1.0,
            'plz_database_similar': 0.95,
            'plz_database_corrected': 0.85,
            'plz_only_match': 0.75,
            'fuzzy_matching': 0.70,
            'city_based_search': 0.65,
            'regional_estimation': 0.40
        }
        
        weighted_score = 0
        source_counts = {}
        
        for idx, row in self.df.iterrows():
            if pd.notna(row['geo_source']):
                source = row['geo_source']
                confidence = row['geo_confidence']
                source_weight = scores.get(source, 0)
                
                # Kombiniere Quellen-Gewicht mit Confidence
                final_weight = source_weight * confidence
                weighted_score += final_weight
                
                source_counts[source] = source_counts.get(source, 0) + 1
        
        geo_score = (weighted_score / total) * 100 if total > 0 else 0
        
        coverage = sum(1 for lat in self.df['latitude'] if pd.notna(lat)) / total * 100
        
        geo_metrics = {
            'enhanced_geo_score': round(geo_score, 1),
            'coordinates_coverage': round(coverage, 1),
            'total_records': total,
            'source_distribution': source_counts,
            'validation_statistics': self.validation_stats
        }
        
        logger.info(f"🎯 Erweiterter Geo-Score: {geo_score:.1f}/100")
        logger.info(f"📍 Koordinaten-Abdeckung: {coverage:.1f}%")
        
        return geo_metrics
    
    def save_enhanced_data(self, output_file: str = None):
        """Speichert die geo-erweiterten Daten"""
        if output_file is None:
            output_file = self.enriched_file.replace('_ENRICHED_FINAL.xlsx', '_ENHANCED_GEO.xlsx')
        
        logger.info(f"💾 Speichere geo-erweiterte Daten: {output_file}")
        self.df.to_excel(output_file, index=False)
        
        # Report erstellen
        geo_metrics = self.calculate_enhanced_geo_score()
        
        report_file = output_file.replace('.xlsx', '_ENHANCED_GEO_REPORT.json')
        report = {
            'timestamp': datetime.now().isoformat(),
            'source_file': self.enriched_file,
            'output_file': output_file,
            'plz_database_size': len(self.plz_database),
            'enhanced_geo_metrics': geo_metrics
        }
        
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        logger.info(f"📋 Enhanced Geo-Report: {report_file}")
        return output_file, report_file, geo_metrics
    
    def run_enhanced_validation(self):
        """Führt die erweiterte Geo-Validierung durch"""
        logger.info("🚀 Starte erweiterte Geo-Validierung...")
        
        if not self.plz_database:
            logger.error("❌ Keine PLZ-Datenbank verfügbar!")
            return None, None, None
        
        self.load_data()
        self.validate_and_enhance_addresses()
        
        return self.save_enhanced_data()

def main():
    """Hauptfunktion"""
    enriched_file = 'Kundendatenabgleich_202507251500_ENRICHED_FINAL.xlsx'
    
    validator = EnhancedGeoValidator(enriched_file)
    output_file, report_file, metrics = validator.run_enhanced_validation()
    
    if output_file:
        print("\n" + "="*80)
        print("🗺️ ERWEITERTE GEO-VALIDIERUNG ABGESCHLOSSEN")
        print("="*80)
        print(f"📁 Finale Datei: {output_file}")
        print(f"🎯 Erweiterter Geo-Score: {metrics['enhanced_geo_score']}/100")
        print(f"📍 Koordinaten-Abdeckung: {metrics['coordinates_coverage']:.1f}%")
        print(f"📊 PLZ-Datenbank: {len(validator.plz_database):,} Einträge")
        print(f"✅ Validierte Adressen: {validator.validation_stats['coordinates_added']:,}")
        print(f"📋 Detailbericht: {report_file}")
        print("="*80)

if __name__ == "__main__":
    main()