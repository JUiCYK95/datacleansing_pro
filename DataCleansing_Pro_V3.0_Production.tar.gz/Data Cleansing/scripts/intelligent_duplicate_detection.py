#!/usr/bin/env python3
"""
Intelligente Duplikaterkennung mit Privat/Geschäft-Unterscheidung
Verhindert das Löschen wertvoller Business/Private Kontakt-Paare
"""

import pandas as pd
import re
import json
from datetime import datetime
from difflib import SequenceMatcher
from collections import defaultdict
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class IntelligentDuplicateDetector:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.df = None
        self.original_count = 0
        
        # Business vs Personal Domains
        self.personal_domains = [
            'gmail.com', 'googlemail.com', 'yahoo.de', 'yahoo.com', 'web.de', 
            'gmx.de', 'gmx.net', 't-online.de', 'arcor.de', 'freenet.de',
            'hotmail.com', 'hotmail.de', 'outlook.com', 'outlook.de',
            'icloud.com', 'me.com', 'live.com', 'live.de', 'aol.com',
            'freenet.de', 'online.de', 'vodafone.de'
        ]
        
        self.duplicate_analysis = {
            'exact_duplicates_removed': 0,
            'business_private_pairs_preserved': 0,
            'true_duplicates_removed': 0,
            'similar_names_different_contacts': 0,
            'preserved_pairs': [],
            'removed_duplicates': []
        }
    
    def load_data(self):
        """Lädt die zu analysierende Datei"""
        logger.info(f"📂 Lade Datei: {self.file_path}")
        if self.file_path.endswith('.xlsx'):
            self.df = pd.read_excel(self.file_path)
        else:
            self.df = pd.read_csv(self.file_path)
        
        self.original_count = len(self.df)
        logger.info(f"✅ {self.original_count:,} Datensätze geladen")
        return self.df
    
    def classify_contact_type(self, row):
        """Klassifiziert einen Kontakt als privat oder geschäftlich"""
        business_score = 0
        indicators = []
        
        # E-Mail-Analyse (beide Spalten)
        emails_to_check = []
        if 'eMail_Clean' in row and pd.notna(row['eMail_Clean']):
            emails_to_check.append(('private', str(row['eMail_Clean']).strip().lower()))
        if 'eMail_Business_Clean' in row and pd.notna(row['eMail_Business_Clean']):
            emails_to_check.append(('business', str(row['eMail_Business_Clean']).strip().lower()))
        if 'e-mail-Adresse' in row and pd.notna(row['e-mail-Adresse']):
            emails_to_check.append(('general', str(row['e-mail-Adresse']).strip().lower()))
        if 'E-Mail geschäft' in row and pd.notna(row['E-Mail geschäft']):
            emails_to_check.append(('business', str(row['E-Mail geschäft']).strip().lower()))
        
        email_is_business = False
        for email_type, email in emails_to_check:
            if '@' in email:
                domain = email.split('@')[1]
                if domain in self.personal_domains:
                    if email_type == 'business':
                        # Business-E-Mail-Feld, aber Personal-Domain -> gemischt
                        business_score += 0.2
                        indicators.append('business_field_personal_domain')
                    else:
                        # Klar privat
                        indicators.append('personal_email')
                else:
                    # Potentiell geschäftlich
                    email_is_business = True
                    if email_type == 'business':
                        business_score += 0.6
                        indicators.append('business_email_business_field')
                    else:
                        business_score += 0.4
                        indicators.append('business_email_general_field')
        
        # Telefon-Analyse
        business_phone_fields = ['Telefon_Business_Clean', 'Telefon geschaeftlich', 'Mobil_Business_Clean', 'Mobil geschäft']
        has_business_phone = False
        
        for field in business_phone_fields:
            if field in row and pd.notna(row[field]) and str(row[field]).strip():
                has_business_phone = True
                business_score += 0.3
                indicators.append(f'business_phone_{field}')
        
        # Kundengruppe/Branche als Indikator
        if 'Bezeichnung Kundengruppe' in row and pd.notna(row['Bezeichnung Kundengruppe']):
            kundengruppe = str(row['Bezeichnung Kundengruppe']).lower()
            if any(keyword in kundengruppe for keyword in ['geschäft', 'business', 'firma', 'unternehmen', 'gewerblich']):
                business_score += 0.4
                indicators.append('business_customer_group')
        
        if 'Branche' in row and pd.notna(row['Branche']):
            branche = str(row['Branche']).lower()
            if branche.strip():
                business_score += 0.3
                indicators.append('has_industry_classification')
        
        # Kreditlimit als Business-Indikator
        if 'Kreditlimit' in row and pd.notna(row['Kreditlimit']):
            try:
                limit = float(str(row['Kreditlimit']).replace(',', '.'))
                if limit > 10000:
                    business_score += 0.2
                    indicators.append('high_credit_limit')
            except:
                pass
        
        # Klassifikation
        is_business = business_score >= 0.4
        confidence = min(business_score, 1.0)
        
        return {
            'is_business': is_business,
            'confidence': confidence,
            'score': business_score,
            'indicators': indicators,
            'has_business_email': email_is_business,
            'has_business_phone': has_business_phone
        }
    
    def find_potential_duplicates(self):
        """Findet potentielle Duplikate basierend auf Namen und Adressen"""
        logger.info("🔍 Suche potentielle Duplikate...")
        
        # Gruppiere nach Name + Adresse (ähnlich)
        duplicate_groups = defaultdict(list)
        
        for idx, row in self.df.iterrows():
            # Erstelle einen Schlüssel für Gruppierung
            vorname = str(row.get('Vorname', '')).strip().lower()
            nachname = str(row.get('Nachname', '')).strip().lower()
            plz = str(row.get('PLZ_Clean', row.get('Postleitzahl zum Ort', ''))).strip()
            
            if vorname and nachname:  # Nur wenn Name vorhanden
                key = f"{nachname}_{vorname}_{plz}"
                duplicate_groups[key].append({
                    'index': idx,
                    'row': row,
                    'name': f"{vorname} {nachname}",
                    'plz': plz
                })
        
        # Filtere Gruppen mit mehr als einem Eintrag
        potential_duplicates = {k: v for k, v in duplicate_groups.items() if len(v) > 1}
        
        logger.info(f"📊 {len(potential_duplicates)} Gruppen mit potentiellen Duplikaten gefunden")
        return potential_duplicates
    
    def analyze_duplicate_group(self, group):
        """Analysiert eine Gruppe potentieller Duplikate"""
        if len(group) < 2:
            return {'action': 'keep_all', 'reason': 'single_entry'}
        
        # Klassifiziere alle Einträge in der Gruppe
        classified_entries = []
        for entry in group:
            classification = self.classify_contact_type(entry['row'])
            entry['classification'] = classification
            classified_entries.append(entry)
        
        # Analysiere die Kombinationen
        business_entries = [e for e in classified_entries if e['classification']['is_business']]
        private_entries = [e for e in classified_entries if not e['classification']['is_business']]
        
        # Fall 1: Ein Business + Ein Private -> Behalte beide!
        if len(business_entries) == 1 and len(private_entries) == 1:
            return {
                'action': 'keep_all',
                'reason': 'business_private_pair',
                'business_entry': business_entries[0]['index'],
                'private_entry': private_entries[0]['index'],
                'details': {
                    'business_indicators': business_entries[0]['classification']['indicators'],
                    'private_indicators': private_entries[0]['classification']['indicators']
                }
            }
        
        # Fall 2: Mehrere Business oder mehrere Private -> Prüfe echte Duplikate
        if len(business_entries) > 1 or len(private_entries) > 1:
            # Prüfe auf identische Kontaktdaten innerhalb derselben Kategorie
            to_remove = []
            
            # Prüfe Business-Einträge untereinander
            for i, entry1 in enumerate(business_entries):
                for j, entry2 in enumerate(business_entries[i+1:], i+1):
                    if self.are_true_duplicates(entry1['row'], entry2['row']):
                        # Behalte den vollständigeren Eintrag
                        filled1 = sum(1 for val in entry1['row'] if pd.notna(val) and str(val).strip())
                        filled2 = sum(1 for val in entry2['row'] if pd.notna(val) and str(val).strip())
                        
                        if filled1 >= filled2:
                            to_remove.append(entry2['index'])
                        else:
                            to_remove.append(entry1['index'])
            
            # Prüfe Private-Einträge untereinander
            for i, entry1 in enumerate(private_entries):
                for j, entry2 in enumerate(private_entries[i+1:], i+1):
                    if self.are_true_duplicates(entry1['row'], entry2['row']):
                        filled1 = sum(1 for val in entry1['row'] if pd.notna(val) and str(val).strip())
                        filled2 = sum(1 for val in entry2['row'] if pd.notna(val) and str(val).strip())
                        
                        if filled1 >= filled2:
                            to_remove.append(entry2['index'])
                        else:
                            to_remove.append(entry1['index'])
            
            return {
                'action': 'remove_some',
                'reason': 'true_duplicates_within_category',
                'to_remove': list(set(to_remove)),
                'business_count': len(business_entries),
                'private_count': len(private_entries)
            }
        
        # Fall 3: Alle gleiche Kategorie, ähnliche Kontaktdaten -> echter Duplikat
        if len(classified_entries) > 1:
            # Prüfe ob alle sehr ähnliche Kontaktdaten haben
            first_entry = classified_entries[0]
            similar_contacts = all(
                self.are_true_duplicates(first_entry['row'], entry['row']) 
                for entry in classified_entries[1:]
            )
            
            if similar_contacts:
                # Behalte den vollständigsten Eintrag
                best_entry = max(classified_entries, 
                               key=lambda x: sum(1 for val in x['row'] if pd.notna(val) and str(val).strip()))
                
                to_remove = [e['index'] for e in classified_entries if e['index'] != best_entry['index']]
                
                return {
                    'action': 'remove_some',
                    'reason': 'identical_contacts_same_category',
                    'to_remove': to_remove,
                    'kept': best_entry['index']
                }
        
        # Default: Behalte alle (unsicher)
        return {
            'action': 'keep_all',
            'reason': 'unclear_relationship',
            'analysis': {
                'business_count': len(business_entries),
                'private_count': len(private_entries),
                'total': len(classified_entries)
            }
        }
    
    def are_true_duplicates(self, row1, row2):
        """Prüft ob zwei Zeilen echte Duplikate sind (sehr ähnliche Kontaktdaten)"""
        similarity_score = 0
        comparisons = 0
        
        # E-Mail-Vergleich
        email_fields = ['eMail_Clean', 'eMail_Business_Clean', 'e-mail-Adresse', 'E-Mail geschäft']
        emails1 = [str(row1.get(field, '')).strip().lower() for field in email_fields if pd.notna(row1.get(field))]
        emails2 = [str(row2.get(field, '')).strip().lower() for field in email_fields if pd.notna(row2.get(field))]
        
        emails1 = [e for e in emails1 if e and '@' in e]
        emails2 = [e for e in emails2 if e and '@' in e]
        
        if emails1 and emails2:
            # Prüfe auf gemeinsame E-Mails
            common_emails = set(emails1) & set(emails2)
            if common_emails:
                similarity_score += 0.4
            comparisons += 1
        
        # Telefon-Vergleich
        phone_fields = ['Telefon_Clean', 'Telefon_Business_Clean', 'Mobiltelefon_Clean', 'Mobil_Business_Clean']
        phones1 = [str(row1.get(field, '')).strip() for field in phone_fields if pd.notna(row1.get(field))]
        phones2 = [str(row2.get(field, '')).strip() for field in phone_fields if pd.notna(row2.get(field))]
        
        phones1 = [p for p in phones1 if p and p != '']
        phones2 = [p for p in phones2 if p and p != '']
        
        if phones1 and phones2:
            common_phones = set(phones1) & set(phones2)
            if common_phones:
                similarity_score += 0.3
            comparisons += 1
        
        # Adress-Vergleich (sollte bereits ähnlich sein durch Gruppierung)
        similarity_score += 0.1  # Bonus für gleiche Adresse
        comparisons += 1
        
        # Echte Duplikate wenn Ähnlichkeit > 70% und mindestens eine Übereinstimmung
        return (similarity_score / comparisons) > 0.7 if comparisons > 0 else False
    
    def remove_intelligent_duplicates(self):
        """Führt die intelligente Duplikaterkennung durch"""
        logger.info("🧠 Starte intelligente Duplikaterkennung...")
        
        original_count = len(self.df)
        
        # Finde potentielle Duplikate
        potential_duplicates = self.find_potential_duplicates()
        
        indices_to_remove = set()
        business_private_pairs = []
        preserved_pairs = []
        
        # Analysiere jede Duplikat-Gruppe
        for group_key, group in potential_duplicates.items():
            analysis = self.analyze_duplicate_group(group)
            
            if analysis['action'] == 'remove_some':
                indices_to_remove.update(analysis['to_remove'])
                self.duplicate_analysis['true_duplicates_removed'] += len(analysis['to_remove'])
                
                self.duplicate_analysis['removed_duplicates'].append({
                    'group': group_key,
                    'reason': analysis['reason'],
                    'removed_indices': analysis['to_remove']
                })
                
            elif analysis['action'] == 'keep_all':
                if analysis['reason'] == 'business_private_pair':
                    business_private_pairs.append({
                        'group': group_key,
                        'business_index': analysis['business_entry'],
                        'private_index': analysis['private_entry'],
                        'business_indicators': analysis['details']['business_indicators'],
                        'private_indicators': analysis['details']['private_indicators']
                    })
                    
                    self.duplicate_analysis['business_private_pairs_preserved'] += 1
                    
                    # Markiere die Einträge als Paar
                    business_idx = analysis['business_entry']
                    private_idx = analysis['private_entry']
                    
                    if 'contact_pair_type' not in self.df.columns:
                        self.df['contact_pair_type'] = ''
                        self.df['contact_pair_partner_index'] = ''
                    
                    self.df.at[business_idx, 'contact_pair_type'] = 'business_part_of_pair'
                    self.df.at[business_idx, 'contact_pair_partner_index'] = str(private_idx)
                    self.df.at[private_idx, 'contact_pair_type'] = 'private_part_of_pair'
                    self.df.at[private_idx, 'contact_pair_partner_index'] = str(business_idx)
                    
                    preserved_pairs.append({
                        'business_index': business_idx,
                        'private_index': private_idx,
                        'name': group[0]['name']
                    })
        
        # Entferne die identifizierten echten Duplikate
        if indices_to_remove:
            logger.info(f"🗑️ Entferne {len(indices_to_remove)} echte Duplikate...")
            self.df = self.df.drop(index=list(indices_to_remove)).reset_index(drop=True)
        
        removed_count = len(indices_to_remove)
        final_count = len(self.df)
        
        # Statistiken
        self.duplicate_analysis['exact_duplicates_removed'] = removed_count
        self.duplicate_analysis['preserved_pairs'] = preserved_pairs
        
        logger.info("✅ Intelligente Duplikaterkennung abgeschlossen:")
        logger.info(f"   🗑️ Echte Duplikate entfernt: {removed_count:,}")
        logger.info(f"   💼👤 Business/Privat-Paare erhalten: {len(business_private_pairs):,}")
        logger.info(f"   📊 Finale Datensätze: {final_count:,}")
        
        return self.df
    
    def save_results(self, output_file: str = None):
        """Speichert die Ergebnisse"""
        if output_file is None:
            base_name = self.file_path.replace('.xlsx', '').replace('.csv', '')
            output_file = f"{base_name}_INTELLIGENT_DEDUPLICATED.xlsx"
        
        logger.info(f"💾 Speichere Ergebnisse: {output_file}")
        self.df.to_excel(output_file, index=False)
        
        # Speichere Analyse-Report
        report_file = output_file.replace('.xlsx', '_DUPLICATE_ANALYSIS_REPORT.json')
        analysis_report = {
            'timestamp': datetime.now().isoformat(),
            'original_file': self.file_path,
            'processed_file': output_file,
            'original_record_count': self.original_count,
            'final_record_count': len(self.df),
            'duplicate_analysis': self.duplicate_analysis,
            'summary': {
                'records_removed': self.original_count - len(self.df),
                'business_private_pairs_preserved': self.duplicate_analysis['business_private_pairs_preserved'],
                'data_integrity_maintained': True
            }
        }
        
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(analysis_report, f, indent=2, ensure_ascii=False)
        
        logger.info(f"📋 Analyse-Report gespeichert: {report_file}")
        return output_file, report_file
    
    def run_intelligent_deduplication(self):
        """Führt die komplette intelligente Duplikaterkennung durch"""
        logger.info("🚀 Starte intelligente Duplikaterkennung mit Business/Privat-Erkennung...")
        
        self.load_data()
        self.remove_intelligent_duplicates()
        output_file, report_file = self.save_results()
        
        logger.info("✅ Intelligente Duplikaterkennung abgeschlossen!")
        return output_file, report_file, self.duplicate_analysis

def main():
    """Hauptfunktion"""
    # Teste mit der bereits bereinigten Kundendatenabgleich Datei
    file_path = 'Kundendatenabgleich_202507251500_CLEANED.xlsx'
    
    detector = IntelligentDuplicateDetector(file_path)
    output_file, report_file, analysis = detector.run_intelligent_deduplication()
    
    print("\n" + "="*70)
    print("🧠 INTELLIGENTE DUPLIKATERKENNUNG ABGESCHLOSSEN")
    print("="*70)
    print(f"📁 Ausgabedatei: {output_file}")
    print(f"🗑️ Echte Duplikate entfernt: {analysis['exact_duplicates_removed']:,}")
    print(f"💼👤 Business/Privat-Paare erhalten: {analysis['business_private_pairs_preserved']:,}")
    print(f"📋 Detailbericht: {report_file}")
    print("="*70)
    
    if analysis['preserved_pairs']:
        print("\n🎯 ERHALTENE BUSINESS/PRIVAT-PAARE:")
        for pair in analysis['preserved_pairs'][:5]:  # Zeige erste 5
            print(f"   👤 {pair['name']} -> Business: Index {pair['business_index']}, Privat: Index {pair['private_index']}")
        if len(analysis['preserved_pairs']) > 5:
            print(f"   ... und {len(analysis['preserved_pairs']) - 5} weitere Paare")

if __name__ == "__main__":
    main()