#!/usr/bin/env python3
"""
Initial Data Analysis Report Generator
Erstellt professionelle PDF-Berichte für die Kundenübergabe vor der Datenbereinigung
"""

import pandas as pd
import numpy as np
import json
from datetime import datetime
from pathlib import Path
import io
import base64
import logging

# Optional dependencies
try:
    import matplotlib.pyplot as plt
    import seaborn as sns
    MATPLOTLIB_AVAILABLE = True
except ImportError:
    MATPLOTLIB_AVAILABLE = False

# WeasyPrint is optional - will be imported when needed
WEASYPRINT_AVAILABLE = False

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class InitialDataAnalysisReport:
    def __init__(self, file_path: str, client_name: str = None):
        self.file_path = file_path
        self.client_name = client_name or "Kunde"
        self.df = None
        self.analysis_results = {}

    def load_data(self):
        """Lädt die Datei für die Analyse"""
        logger.info(f"📂 Lade Datei: {self.file_path}")

        try:
            if self.file_path.endswith('.xlsx') or self.file_path.endswith('.xls'):
                self.df = pd.read_excel(self.file_path)
            elif self.file_path.endswith('.csv'):
                self.df = pd.read_csv(self.file_path)
            else:
                raise ValueError("Unsupported file format")

            logger.info(f"✅ {len(self.df):,} Datensätze geladen")
            return True

        except Exception as e:
            logger.error(f"❌ Fehler beim Laden der Datei: {e}")
            return False

    def analyze_data_quality(self):
        """Führt eine umfassende Datenqualitätsanalyse durch"""
        logger.info("📊 Starte Datenqualitätsanalyse...")

        total_records = len(self.df)
        total_fields = len(self.df.columns)

        # 1. Vollständigkeitsanalyse
        missing_data = self.df.isnull().sum()
        completeness_rate = ((total_records * total_fields - missing_data.sum()) / (total_records * total_fields)) * 100

        # 2. Spalten-spezifische Analyse
        column_analysis = {}
        for col in self.df.columns:
            non_null_count = self.df[col].count()
            null_count = total_records - non_null_count
            completeness = (non_null_count / total_records) * 100

            # Datentyp-Analyse
            unique_values = self.df[col].nunique()
            most_common = self.df[col].value_counts().head(3) if non_null_count > 0 else {}

            # Sichere Konvertierung für JSON
            most_common_dict = {}
            if hasattr(most_common, 'to_dict'):
                for key, value in most_common.to_dict().items():
                    # Konvertiere alle Keys und Values zu Strings wenn nötig
                    str_key = str(key) if not isinstance(key, (str, int, float, bool)) else key
                    str_value = int(value) if hasattr(value, 'item') else value
                    most_common_dict[str_key] = str_value

            column_analysis[col] = {
                'completeness': round(completeness, 1),
                'null_count': int(null_count),
                'non_null_count': int(non_null_count),
                'unique_values': int(unique_values),
                'data_type': str(self.df[col].dtype),
                'most_common': most_common_dict
            }

        # 3. Telefonnummer-Analyse
        phone_analysis = self._analyze_phone_fields()

        # 4. E-Mail-Analyse
        email_analysis = self._analyze_email_fields()

        # 5. Adress-Analyse
        address_analysis = self._analyze_address_fields()

        # 6. Duplikat-Analyse
        duplicate_analysis = self._analyze_duplicates()

        self.analysis_results = {
            'summary': {
                'total_records': total_records,
                'total_fields': total_fields,
                'completeness_rate': round(completeness_rate, 1),
                'timestamp': datetime.now().isoformat()
            },
            'column_analysis': column_analysis,
            'phone_analysis': phone_analysis,
            'email_analysis': email_analysis,
            'address_analysis': address_analysis,
            'duplicate_analysis': duplicate_analysis
        }

        logger.info(f"✅ Datenqualitätsanalyse abgeschlossen - Vollständigkeit: {completeness_rate:.1f}%")
        return self.analysis_results

    def _analyze_phone_fields(self):
        """Analysiert Telefonnummer-Felder"""
        phone_fields = ['Telefon', 'Mobiltelefon', 'Phone', 'Mobile', 'Handy']
        found_fields = [col for col in phone_fields if col in self.df.columns]

        analysis = {
            'fields_found': found_fields,
            'total_phone_entries': 0,
            'valid_format_count': 0,
            'issues': []
        }

        for field in found_fields:
            non_empty = self.df[field].dropna()
            non_empty = non_empty[non_empty.astype(str).str.strip() != '']

            analysis['total_phone_entries'] += len(non_empty)

            # Einfache Format-Validierung
            valid_patterns = 0
            for phone in non_empty.astype(str):
                if any(char.isdigit() for char in phone) and len(phone.replace(' ', '').replace('-', '').replace('+', '')) >= 6:
                    valid_patterns += 1

            analysis['valid_format_count'] += valid_patterns

            if len(non_empty) > 0:
                invalid_rate = ((len(non_empty) - valid_patterns) / len(non_empty)) * 100
                if invalid_rate > 20:
                    analysis['issues'].append(f"Feld '{field}': {invalid_rate:.1f}% ungültige Formate")

        return analysis

    def _analyze_email_fields(self):
        """Analysiert E-Mail-Felder"""
        email_fields = ['eMail', 'Email', 'E-Mail', 'email']
        found_fields = [col for col in email_fields if col in self.df.columns]

        analysis = {
            'fields_found': found_fields,
            'total_email_entries': 0,
            'valid_format_count': 0,
            'domain_distribution': {},
            'issues': []
        }

        for field in found_fields:
            non_empty = self.df[field].dropna()
            non_empty = non_empty[non_empty.astype(str).str.strip() != '']

            analysis['total_email_entries'] += len(non_empty)

            # E-Mail Format-Validierung
            valid_emails = 0
            domains = []

            for email in non_empty.astype(str):
                if '@' in email and '.' in email.split('@')[-1]:
                    valid_emails += 1
                    domain = email.split('@')[-1].lower()
                    domains.append(domain)

            analysis['valid_format_count'] += valid_emails

            # Domain-Verteilung
            if domains:
                domain_counts = pd.Series(domains).value_counts().head(10)
                analysis['domain_distribution'].update(domain_counts.to_dict())

            if len(non_empty) > 0:
                invalid_rate = ((len(non_empty) - valid_emails) / len(non_empty)) * 100
                if invalid_rate > 10:
                    analysis['issues'].append(f"Feld '{field}': {invalid_rate:.1f}% ungültige E-Mail-Formate")

        return analysis

    def _analyze_address_fields(self):
        """Analysiert Adress-Felder"""
        address_fields = {
            'street': ['Straße', 'Strasse', 'Street', 'Address'],
            'city': ['Ort', 'Stadt', 'City'],
            'postal': ['PLZ', 'Postleitzahl', 'Postal', 'ZIP'],
            'country': ['Land', 'Country']
        }

        analysis = {
            'found_fields': {},
            'complete_addresses': 0,
            'plz_issues': [],
            'consistency_issues': []
        }

        for field_type, field_names in address_fields.items():
            found = [col for col in field_names if col in self.df.columns]
            analysis['found_fields'][field_type] = found

        # Vollständige Adressen zählen
        street_cols = analysis['found_fields']['street']
        city_cols = analysis['found_fields']['city']
        postal_cols = analysis['found_fields']['postal']

        if street_cols and city_cols and postal_cols:
            complete_mask = True
            for cols in [street_cols, city_cols, postal_cols]:
                for col in cols:
                    complete_mask &= self.df[col].notna() & (self.df[col].astype(str).str.strip() != '')

            analysis['complete_addresses'] = complete_mask.sum()

        # PLZ-Validierung (deutsche PLZ)
        for col in postal_cols:
            non_empty = self.df[col].dropna().astype(str)
            invalid_plz = []

            for plz in non_empty:
                plz_clean = plz.strip()
                if not (plz_clean.isdigit() and len(plz_clean) == 5):
                    invalid_plz.append(plz_clean)

            if invalid_plz:
                analysis['plz_issues'].append(f"Feld '{col}': {len(invalid_plz)} ungültige PLZ-Formate")

        return analysis

    def _analyze_duplicates(self):
        """Analysiert potenzielle Duplikate"""
        analysis = {
            'exact_duplicates': 0,
            'potential_duplicates': 0,
            'duplicate_fields': []
        }

        # Exakte Duplikate
        exact_dups = self.df.duplicated().sum()
        analysis['exact_duplicates'] = exact_dups

        # Potenzielle Duplikate basierend auf Namen + Kontaktdaten
        key_fields = ['Vorname', 'Nachname', 'eMail', 'Telefon']
        available_key_fields = [col for col in key_fields if col in self.df.columns]

        if len(available_key_fields) >= 2:
            # Prüfe auf Duplikate in wichtigen Feldern
            for field in available_key_fields:
                field_dups = self.df[field].duplicated().sum()
                if field_dups > 0:
                    analysis['duplicate_fields'].append({
                        'field': field,
                        'duplicate_count': field_dups
                    })

        return analysis

    def generate_charts(self):
        """Erstellt Visualisierungen für den Report"""
        charts = {}

        if not MATPLOTLIB_AVAILABLE:
            logger.warning("Matplotlib nicht verfügbar - verwende Text-basierte Charts")
            return self.generate_text_charts()

        try:
            # 1. Vollständigkeits-Chart
            completeness_data = []
            for col, data in self.analysis_results['column_analysis'].items():
                completeness_data.append({
                    'Spalte': col,
                    'Vollständigkeit': data['completeness']
                })

            completeness_df = pd.DataFrame(completeness_data)

            plt.figure(figsize=(12, 6))
            sns.barplot(data=completeness_df, x='Vollständigkeit', y='Spalte', palette='viridis')
            plt.title('Datenvollständigkeit pro Spalte (%)', fontsize=14, fontweight='bold')
            plt.xlabel('Vollständigkeit (%)')
            plt.tight_layout()

            # Chart als Base64 speichern
            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
            buffer.seek(0)
            charts['completeness'] = base64.b64encode(buffer.getvalue()).decode()
            plt.close()

            # 2. Datenqualitäts-Overview
            quality_metrics = [
                ('Vollständigkeit', self.analysis_results['summary']['completeness_rate']),
                ('Telefon-Qualität', self._calculate_phone_quality()),
                ('E-Mail-Qualität', self._calculate_email_quality()),
                ('Adress-Qualität', self._calculate_address_quality())
            ]

            metrics_df = pd.DataFrame(quality_metrics, columns=['Metrik', 'Score'])

            plt.figure(figsize=(10, 6))
            colors = ['#2E8B57' if score >= 80 else '#FF6B35' if score >= 60 else '#DC143C' for score in metrics_df['Score']]
            bars = plt.bar(metrics_df['Metrik'], metrics_df['Score'], color=colors)
            plt.title('Datenqualitäts-Übersicht', fontsize=14, fontweight='bold')
            plt.ylabel('Qualitäts-Score (%)')
            plt.ylim(0, 100)

            # Werte auf Balken anzeigen
            for bar, score in zip(bars, metrics_df['Score']):
                plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                        f'{score:.1f}%', ha='center', va='bottom', fontweight='bold')

            plt.xticks(rotation=45)
            plt.tight_layout()

            buffer = io.BytesIO()
            plt.savefig(buffer, format='png', dpi=300, bbox_inches='tight')
            buffer.seek(0)
            charts['quality_overview'] = base64.b64encode(buffer.getvalue()).decode()
            plt.close()

        except Exception as e:
            logger.error(f"Fehler bei Chart-Generierung: {e}")
            return self.generate_text_charts()

        return charts

    def generate_text_charts(self):
        """Erstellt text-basierte Charts als Fallback"""
        return {
            'completeness': 'placeholder',
            'quality_overview': 'placeholder'
        }

    def _generate_chart_html(self, charts):
        """Generiert HTML für Charts basierend auf verfügbaren Daten"""
        chart_html = {}

        if charts.get('quality_overview') and charts['quality_overview'] != 'placeholder':
            chart_html['quality_overview'] = f'''
            <div class="chart-container">
                <img src="data:image/png;base64,{charts['quality_overview']}" alt="Datenqualitäts-Übersicht">
            </div>'''
        else:
            # Text-basierte Qualitäts-Übersicht
            quality_metrics = [
                ('Vollständigkeit', self.analysis_results['summary']['completeness_rate']),
                ('Telefon-Qualität', self._calculate_phone_quality()),
                ('E-Mail-Qualität', self._calculate_email_quality()),
                ('Adress-Qualität', self._calculate_address_quality())
            ]

            chart_html['quality_overview'] = '<div class="metrics-grid">'
            for metric, score in quality_metrics:
                color = '#28a745' if score >= 80 else '#ffc107' if score >= 60 else '#dc3545'
                chart_html['quality_overview'] += f'''
                <div class="metric-card">
                    <span class="metric-value" style="color: {color};">{score:.1f}%</span>
                    <div class="metric-label">{metric}</div>
                </div>'''
            chart_html['quality_overview'] += '</div>'

        if charts.get('completeness') and charts['completeness'] != 'placeholder':
            chart_html['completeness'] = f'''
            <div class="chart-container">
                <img src="data:image/png;base64,{charts['completeness']}" alt="Datenvollständigkeit pro Spalte">
            </div>'''
        else:
            # Text-basierte Vollständigkeits-Übersicht
            chart_html['completeness'] = '''
            <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <p><strong>📊 Vollständigkeits-Übersicht:</strong></p>
                <p>Detaillierte Spalten-Analyse siehe Tabelle unten.</p>
            </div>'''

        return chart_html

    def _calculate_phone_quality(self):
        """Berechnet Telefonnummer-Qualität"""
        phone_data = self.analysis_results['phone_analysis']
        if phone_data['total_phone_entries'] == 0:
            return 0
        return (phone_data['valid_format_count'] / phone_data['total_phone_entries']) * 100

    def _calculate_email_quality(self):
        """Berechnet E-Mail-Qualität"""
        email_data = self.analysis_results['email_analysis']
        if email_data['total_email_entries'] == 0:
            return 0
        return (email_data['valid_format_count'] / email_data['total_email_entries']) * 100

    def _calculate_address_quality(self):
        """Berechnet Adress-Qualität"""
        address_data = self.analysis_results['address_analysis']
        total_records = self.analysis_results['summary']['total_records']
        if total_records == 0:
            return 0
        return (address_data['complete_addresses'] / total_records) * 100

    def generate_html_report(self):
        """Generiert den HTML-Report"""
        charts = self.generate_charts()

        # Recommendations generieren
        recommendations = self._generate_recommendations()

        # Chart-HTML generieren basierend auf verfügbaren Charts
        chart_html = self._generate_chart_html(charts)

        html_content = f"""
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Initiale Datenanalyse - {self.client_name}</title>
    <style>
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f8f9fa;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }}
        .header h1 {{
            margin: 0;
            font-size: 2.5em;
            font-weight: 300;
        }}
        .header p {{
            margin: 10px 0 0 0;
            font-size: 1.2em;
            opacity: 0.9;
        }}
        .section {{
            background: white;
            padding: 30px;
            margin: 20px 0;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            color: #667eea;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
            margin-top: 0;
        }}
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }}
        .metric-card {{
            background: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid #667eea;
            text-align: center;
        }}
        .metric-value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #667eea;
            display: block;
        }}
        .metric-label {{
            color: #666;
            font-size: 1.1em;
            margin-top: 5px;
        }}
        .chart-container {{
            text-align: center;
            margin: 30px 0;
        }}
        .chart-container img {{
            max-width: 100%;
            height: auto;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .issues-list {{
            background: #fff3cd;
            border: 1px solid #ffeaa7;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }}
        .issue-item {{
            margin: 10px 0;
            padding: 10px;
            background: white;
            border-radius: 5px;
            border-left: 4px solid #f39c12;
        }}
        .recommendations {{
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
        }}
        .recommendation-item {{
            margin: 15px 0;
            padding: 15px;
            background: white;
            border-radius: 5px;
            border-left: 4px solid #17a2b8;
        }}
        .priority-high {{ border-left-color: #dc3545; }}
        .priority-medium {{ border-left-color: #ffc107; }}
        .priority-low {{ border-left-color: #28a745; }}
        table {{
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }}
        th, td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }}
        th {{
            background-color: #667eea;
            color: white;
            font-weight: 600;
        }}
        tr:hover {{
            background-color: #f5f5f5;
        }}
        .footer {{
            text-align: center;
            margin-top: 50px;
            padding: 20px;
            color: #666;
            border-top: 1px solid #ddd;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔍 Initiale Datenanalyse</h1>
        <p>Professionelle Bewertung Ihrer Datenqualität für: <strong>{self.client_name}</strong></p>
        <p>Erstellt am: {datetime.now().strftime('%d.%m.%Y um %H:%M Uhr')}</p>
    </div>

    <div class="section">
        <h2>📊 Datenübersicht</h2>
        <div class="metrics-grid">
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['summary']['total_records']:,}</span>
                <div class="metric-label">Datensätze insgesamt</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['summary']['total_fields']}</span>
                <div class="metric-label">Datenfelder</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['summary']['completeness_rate']:.1f}%</span>
                <div class="metric-label">Gesamt-Vollständigkeit</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['duplicate_analysis']['exact_duplicates']}</span>
                <div class="metric-label">Exakte Duplikate</div>
            </div>
        </div>
    </div>

    <div class="section">
        <h2>📈 Datenqualitäts-Übersicht</h2>
        {chart_html['quality_overview']}
    </div>

    <div class="section">
        <h2>📋 Vollständigkeitsanalyse</h2>
        {chart_html['completeness']}

        <h3>Detaillierte Spaltenanalyse</h3>
        <table>
            <thead>
                <tr>
                    <th>Spalte</th>
                    <th>Vollständigkeit</th>
                    <th>Fehlende Werte</th>
                    <th>Eindeutige Werte</th>
                    <th>Datentyp</th>
                </tr>
            </thead>
            <tbody>
                {self._generate_column_table()}
            </tbody>
        </table>
    </div>

    <div class="section">
        <h2>📞 Telefonnummer-Analyse</h2>
        <div class="metrics-grid">
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['phone_analysis']['total_phone_entries']}</span>
                <div class="metric-label">Telefonnummern insgesamt</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['phone_analysis']['valid_format_count']}</span>
                <div class="metric-label">Gültige Formate</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self._calculate_phone_quality():.1f}%</span>
                <div class="metric-label">Qualitäts-Score</div>
            </div>
        </div>

        {self._generate_phone_issues_html()}
    </div>

    <div class="section">
        <h2>📧 E-Mail-Analyse</h2>
        <div class="metrics-grid">
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['email_analysis']['total_email_entries']}</span>
                <div class="metric-label">E-Mails insgesamt</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['email_analysis']['valid_format_count']}</span>
                <div class="metric-label">Gültige Formate</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self._calculate_email_quality():.1f}%</span>
                <div class="metric-label">Qualitäts-Score</div>
            </div>
        </div>

        {self._generate_email_domains_html()}
        {self._generate_email_issues_html()}
    </div>

    <div class="section">
        <h2>🏠 Adress-Analyse</h2>
        <div class="metrics-grid">
            <div class="metric-card">
                <span class="metric-value">{self.analysis_results['address_analysis']['complete_addresses']}</span>
                <div class="metric-label">Vollständige Adressen</div>
            </div>
            <div class="metric-card">
                <span class="metric-value">{self._calculate_address_quality():.1f}%</span>
                <div class="metric-label">Adress-Qualität</div>
            </div>
        </div>

        {self._generate_address_issues_html()}
    </div>

    <div class="section">
        <h2>🎯 Handlungsempfehlungen</h2>
        <div class="recommendations">
            {self._generate_recommendations_html(recommendations)}
        </div>
    </div>

    <div class="footer">
        <p>📊 Erstellt mit dem Advanced Data Cleansing System</p>
        <p>🚀 Bereit für die nächste Phase: Automatische Datenbereinigung und -anreicherung</p>
    </div>
</body>
</html>
        """

        return html_content

    def _generate_column_table(self):
        """Generiert HTML-Tabelle für Spaltenanalyse"""
        rows = []
        for col, data in self.analysis_results['column_analysis'].items():
            completeness_class = ""
            if data['completeness'] >= 90:
                completeness_class = "style='color: #28a745; font-weight: bold;'"
            elif data['completeness'] >= 70:
                completeness_class = "style='color: #ffc107; font-weight: bold;'"
            else:
                completeness_class = "style='color: #dc3545; font-weight: bold;'"

            rows.append(f"""
                <tr>
                    <td><strong>{col}</strong></td>
                    <td {completeness_class}>{data['completeness']:.1f}%</td>
                    <td>{data['null_count']:,}</td>
                    <td>{data['unique_values']:,}</td>
                    <td>{data['data_type']}</td>
                </tr>
            """)

        return "".join(rows)

    def _generate_phone_issues_html(self):
        """Generiert HTML für Telefonnummer-Probleme"""
        issues = self.analysis_results['phone_analysis']['issues']
        if not issues:
            return "<p style='color: #28a745;'>✅ Keine kritischen Telefonnummer-Probleme gefunden.</p>"

        issues_html = "<div class='issues-list'><h4>⚠️ Identifizierte Probleme:</h4>"
        for issue in issues:
            issues_html += f"<div class='issue-item'>{issue}</div>"
        issues_html += "</div>"

        return issues_html

    def _generate_email_domains_html(self):
        """Generiert HTML für E-Mail-Domain-Verteilung"""
        domains = self.analysis_results['email_analysis']['domain_distribution']
        if not domains:
            return ""

        html = "<h4>📊 Top E-Mail-Domains:</h4><ul>"
        for domain, count in list(domains.items())[:10]:
            html += f"<li><strong>{domain}</strong>: {count} E-Mails</li>"
        html += "</ul>"

        return html

    def _generate_email_issues_html(self):
        """Generiert HTML für E-Mail-Probleme"""
        issues = self.analysis_results['email_analysis']['issues']
        if not issues:
            return "<p style='color: #28a745;'>✅ Keine kritischen E-Mail-Probleme gefunden.</p>"

        issues_html = "<div class='issues-list'><h4>⚠️ Identifizierte Probleme:</h4>"
        for issue in issues:
            issues_html += f"<div class='issue-item'>{issue}</div>"
        issues_html += "</div>"

        return issues_html

    def _generate_address_issues_html(self):
        """Generiert HTML für Adress-Probleme"""
        issues = self.analysis_results['address_analysis']['plz_issues']
        if not issues:
            return "<p style='color: #28a745;'>✅ Keine kritischen Adress-Probleme gefunden.</p>"

        issues_html = "<div class='issues-list'><h4>⚠️ Identifizierte Probleme:</h4>"
        for issue in issues:
            issues_html += f"<div class='issue-item'>{issue}</div>"
        issues_html += "</div>"

        return issues_html

    def _generate_recommendations(self):
        """Generiert Handlungsempfehlungen basierend auf der Analyse"""
        recommendations = []

        # Vollständigkeits-Empfehlungen
        completeness = self.analysis_results['summary']['completeness_rate']
        if completeness < 70:
            recommendations.append({
                'priority': 'high',
                'title': 'Kritische Datenlücken schließen',
                'description': f'Mit nur {completeness:.1f}% Vollständigkeit sind umfangreiche Datenergänzungen erforderlich.',
                'action': 'Sofortige Datenbereinigung und -anreicherung durch unser Advanced Enrichment System'
            })
        elif completeness < 85:
            recommendations.append({
                'priority': 'medium',
                'title': 'Datenvollständigkeit optimieren',
                'description': f'Die Vollständigkeit von {completeness:.1f}% kann deutlich verbessert werden.',
                'action': 'Automatische Datenanreicherung mit externen Datenquellen'
            })

        # Telefonnummer-Empfehlungen
        phone_quality = self._calculate_phone_quality()
        if phone_quality < 80:
            recommendations.append({
                'priority': 'high',
                'title': 'Telefonnummer-Bereinigung erforderlich',
                'description': f'Nur {phone_quality:.1f}% der Telefonnummern haben gültige Formate.',
                'action': 'Automatische Normalisierung und Validierung aller Telefonnummern'
            })

        # E-Mail-Empfehlungen
        email_quality = self._calculate_email_quality()
        if email_quality < 85:
            recommendations.append({
                'priority': 'medium',
                'title': 'E-Mail-Validierung durchführen',
                'description': f'E-Mail-Qualität von {email_quality:.1f}% kann verbessert werden.',
                'action': 'Syntax-Validierung und Deliverability-Checks implementieren'
            })

        # Duplikat-Empfehlungen
        duplicates = self.analysis_results['duplicate_analysis']['exact_duplicates']
        if duplicates > 0:
            recommendations.append({
                'priority': 'high',
                'title': 'Duplikate entfernen',
                'description': f'{duplicates} exakte Duplikate gefunden.',
                'action': 'Intelligente Duplikaterkennung mit Business/Privat-Kontakt-Erhaltung'
            })

        # Adress-Empfehlungen
        address_quality = self._calculate_address_quality()
        if address_quality < 75:
            recommendations.append({
                'priority': 'medium',
                'title': 'Adressdaten vervollständigen',
                'description': f'Nur {address_quality:.1f}% vollständige Adressen vorhanden.',
                'action': 'Geo-Validierung und PLZ-Korrektur mit deutscher Post-API'
            })

        # Immer: Allgemeine Empfehlung
        recommendations.append({
            'priority': 'low',
            'title': 'Advanced Data Enrichment',
            'description': 'Anreicherung mit Business Intelligence und Automotive-Branchenexpertise.',
            'action': 'Vollautomatische Anreicherung mit 15+ zusätzlichen Datenfeldern'
        })

        return recommendations

    def _generate_recommendations_html(self, recommendations):
        """Generiert HTML für Handlungsempfehlungen"""
        html = ""

        for i, rec in enumerate(recommendations, 1):
            priority_class = f"priority-{rec['priority']}"
            priority_text = {
                'high': '🔴 Hohe Priorität',
                'medium': '🟡 Mittlere Priorität',
                'low': '🟢 Niedrige Priorität'
            }[rec['priority']]

            html += f"""
            <div class="recommendation-item {priority_class}">
                <h4>{i}. {rec['title']} ({priority_text})</h4>
                <p><strong>Problem:</strong> {rec['description']}</p>
                <p><strong>Lösung:</strong> {rec['action']}</p>
            </div>
            """

        return html

    def generate_pdf_report(self, output_path: str = None):
        """Generiert PDF-Report aus HTML oder HTML-Fallback"""
        if output_path is None:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_path = f"Initial_Data_Analysis_Report_{timestamp}.pdf"

        logger.info(f"🔄 Generiere Report: {output_path}")

        try:
            # HTML generieren
            html_content = self.generate_html_report()

            # Versuche PDF-Generierung wenn WeasyPrint verfügbar
            try:
                from weasyprint import HTML, CSS
                html_doc = HTML(string=html_content)
                html_doc.write_pdf(output_path)
                logger.info(f"✅ PDF-Report erfolgreich erstellt: {output_path}")
                return output_path
            except ImportError:
                logger.info("WeasyPrint nicht verfügbar - erstelle HTML-Report")
            except Exception as pdf_error:
                logger.warning(f"PDF-Generierung fehlgeschlagen: {pdf_error}")

            # Fallback: HTML-Datei erstellen
            html_path = output_path.replace('.pdf', '.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            logger.info(f"📄 HTML-Report erstellt: {html_path}")
            return html_path

        except Exception as e:
            logger.error(f"❌ Fehler bei Report-Generierung: {e}")
            return None

    def run_full_analysis(self, output_path: str = None):
        """Führt die komplette Analyse durch und erstellt PDF-Report"""
        logger.info("🚀 Starte initiale Datenanalyse...")

        # Daten laden
        if not self.load_data():
            return None

        # Analyse durchführen
        self.analyze_data_quality()

        # PDF-Report generieren
        report_path = self.generate_pdf_report(output_path)

        # Statistiken speichern
        if report_path:
            stats_path = report_path.replace('.pdf', '_stats.json').replace('.html', '_stats.json')

            try:
                # Verwende default=str für alle nicht-serialisierbaren Objekte
                with open(stats_path, 'w', encoding='utf-8') as f:
                    json.dump(self.analysis_results, f, indent=2, ensure_ascii=False, default=str)
                logger.info(f"📊 Statistiken gespeichert: {stats_path}")
            except Exception as e:
                logger.warning(f"Warnung: Statistiken konnten nicht gespeichert werden: {e}")
                stats_path = None
        else:
            stats_path = None

        logger.info("✅ Initiale Datenanalyse abgeschlossen!")
        return report_path, stats_path

def main():
    """Hauptfunktion für Kommandozeilen-Nutzung"""
    file_path = '/Users/justin/Desktop/Kundendaten/Kunden9725.xlsx'
    client_name = "Automotive Kunden"

    analyzer = InitialDataAnalysisReport(file_path, client_name)
    report_path, stats_path = analyzer.run_full_analysis()

    if report_path:
        print("\n" + "="*60)
        print("📊 INITIALE DATENANALYSE ABGESCHLOSSEN")
        print("="*60)
        print(f"📄 PDF-Report: {report_path}")
        print(f"📊 Statistiken: {stats_path}")
        print(f"🎯 Qualitäts-Score: {analyzer.analysis_results['summary']['completeness_rate']:.1f}%")
        print("💡 Report kann direkt an Kunden übergeben werden!")
        print("="*60)

if __name__ == "__main__":
    main()