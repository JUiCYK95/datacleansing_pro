#!/usr/bin/env python3
"""
Geo-Koordinaten-Validierung Engine
Deutsche PLZ-Ort-Validierung und Adress-Standardisierung
"""

import pandas as pd
import requests
import json
import time
from datetime import datetime
import logging
from typing import Dict, List, Tuple, Optional
import re

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class GeoValidationEngine:
    def __init__(self, enriched_file: str):
        self.enriched_file = enriched_file
        self.df = None
        self.validation_stats = {
            'addresses_validated': 0,
            'addresses_corrected': 0,
            'coordinates_added': 0,
            'plz_corrections': 0,
            'city_corrections': 0,
            'validation_rate': 0
        }
        
        # Deutsche PLZ-Datenbank (erweiterte Sammlung)
        self.plz_database = self._load_comprehensive_plz_database()
        
        # OpenCage API für Geocoding (kostenlos bis 2500 requests/Tag)
        self.opencage_api_key = None  # Würde in Praxis API-Key verwenden
        
        # Rate limiting
        self.request_delay = 0.1  # 100ms zwischen Requests
        
    def _load_comprehensive_plz_database(self) -> Dict[str, Dict]:
        """Lädt eine umfassendere PLZ-Datenbank"""
        # In einer echten Implementierung würde man die komplette Deutsche Post PLZ-DB laden
        # Hier eine erweiterte Sammlung der häufigsten PLZ für Demo-Zwecke
        plz_data = {
            # Großstädte
            '10115': {'city': 'Berlin', 'state': 'Berlin', 'lat': 52.5200, 'lon': 13.4050},
            '10117': {'city': 'Berlin', 'state': 'Berlin', 'lat': 52.5170, 'lon': 13.3888},
            '10119': {'city': 'Berlin', 'state': 'Berlin', 'lat': 52.5308, 'lon': 13.3847},
            '20095': {'city': 'Hamburg', 'state': 'Hamburg', 'lat': 53.5511, 'lon': 9.9937},
            '20099': {'city': 'Hamburg', 'state': 'Hamburg', 'lat': 53.5510, 'lon': 10.0001},
            '80331': {'city': 'München', 'state': 'Bayern', 'lat': 48.1351, 'lon': 11.5820},
            '80333': {'city': 'München', 'state': 'Bayern', 'lat': 48.1400, 'lon': 11.5700},
            '50667': {'city': 'Köln', 'state': 'Nordrhein-Westfalen', 'lat': 50.9375, 'lon': 6.9603},
            '50672': {'city': 'Köln', 'state': 'Nordrhein-Westfalen', 'lat': 50.9429, 'lon': 6.9529},
            '60311': {'city': 'Frankfurt am Main', 'state': 'Hessen', 'lat': 50.1109, 'lon': 8.6821},
            '60313': {'city': 'Frankfurt am Main', 'state': 'Hessen', 'lat': 50.1147, 'lon': 8.6797},
            '70173': {'city': 'Stuttgart', 'state': 'Baden-Württemberg', 'lat': 48.7758, 'lon': 9.1829},
            '70174': {'city': 'Stuttgart', 'state': 'Baden-Württemberg', 'lat': 48.7823, 'lon': 9.1770},
            '40210': {'city': 'Düsseldorf', 'state': 'Nordrhein-Westfalen', 'lat': 51.2277, 'lon': 6.7735},
            '40212': {'city': 'Düsseldorf', 'state': 'Nordrhein-Westfalen', 'lat': 51.2254, 'lon': 6.7763},
            '44135': {'city': 'Dortmund', 'state': 'Nordrhein-Westfalen', 'lat': 51.5136, 'lon': 7.4653},
            '44137': {'city': 'Dortmund', 'state': 'Nordrhein-Westfalen', 'lat': 51.5089, 'lon': 7.4687},
            '45127': {'city': 'Essen', 'state': 'Nordrhein-Westfalen', 'lat': 51.4556, 'lon': 7.0116},
            '45130': {'city': 'Essen', 'state': 'Nordrhein-Westfalen', 'lat': 51.4508, 'lon': 7.0131},
            '01067': {'city': 'Dresden', 'state': 'Sachsen', 'lat': 51.0504, 'lon': 13.7373},
            '01069': {'city': 'Dresden', 'state': 'Sachsen', 'lat': 51.0493, 'lon': 13.7384},
            
            # Mittelstädte
            '30159': {'city': 'Hannover', 'state': 'Niedersachsen', 'lat': 52.3759, 'lon': 9.7320},
            '28195': {'city': 'Bremen', 'state': 'Bremen', 'lat': 53.0793, 'lon': 8.8017},
            '90403': {'city': 'Nürnberg', 'state': 'Bayern', 'lat': 49.4521, 'lon': 11.0767},
            '68159': {'city': 'Mannheim', 'state': 'Baden-Württemberg', 'lat': 49.4875, 'lon': 8.4660},
            '76133': {'city': 'Karlsruhe', 'state': 'Baden-Württemberg', 'lat': 49.0069, 'lon': 8.4037},
            '86150': {'city': 'Augsburg', 'state': 'Bayern', 'lat': 48.3705, 'lon': 10.8978},
            '99084': {'city': 'Erfurt', 'state': 'Thüringen', 'lat': 50.9848, 'lon': 11.0299},
            '39104': {'city': 'Magdeburg', 'state': 'Sachsen-Anhalt', 'lat': 52.1205, 'lon': 11.6276},
            '24103': {'city': 'Kiel', 'state': 'Schleswig-Holstein', 'lat': 54.3233, 'lon': 10.1228},
            '55116': {'city': 'Mainz', 'state': 'Rheinland-Pfalz', 'lat': 49.9929, 'lon': 8.2473},
            
            # Kleinstädte (Sample)
            '78462': {'city': 'Konstanz', 'state': 'Baden-Württemberg', 'lat': 47.6779, 'lon': 9.1732},
            '88212': {'city': 'Ravensburg', 'state': 'Baden-Württemberg', 'lat': 47.7815, 'lon': 9.6128},
            '72072': {'city': 'Tübingen', 'state': 'Baden-Württemberg', 'lat': 48.5216, 'lon': 9.0576},
            '07545': {'city': 'Gera', 'state': 'Thüringen', 'lat': 50.8774, 'lon': 12.0821},
            '77654': {'city': 'Offenburg', 'state': 'Baden-Württemberg', 'lat': 48.4729, 'lon': 7.9422}
        }
        
        logger.info(f"📍 Erweiterte PLZ-Datenbank geladen: {len(plz_data)} PLZ-Einträge")
        return plz_data
    
    def load_data(self):
        """Lädt die angereicherten Daten"""
        logger.info(f"📂 Lade Daten für Geo-Validierung: {self.enriched_file}")
        self.df = pd.read_excel(self.enriched_file)
        logger.info(f"✅ {len(self.df):,} Datensätze geladen")
        return self.df
    
    def validate_and_correct_addresses(self):
        """Validiert und korrigiert Adressen basierend auf PLZ-Datenbank"""
        logger.info("🗺️ Starte Adress-Validierung und -Korrektur...")
        
        validated_count = 0
        corrected_count = 0
        plz_corrections = 0
        city_corrections = 0
        
        # Neue Spalten für Geo-Daten
        self.df['geo_validated'] = False
        self.df['geo_confidence'] = 0.0
        self.df['latitude'] = None
        self.df['longitude'] = None
        self.df['state'] = None
        self.df['geo_source'] = None
        self.df['address_corrected'] = False
        self.df['original_plz'] = self.df['PLZ'].copy()
        self.df['original_city'] = self.df['Ort'].copy()
        
        for idx, row in self.df.iterrows():
            plz = str(row['PLZ']).strip()
            city = str(row['Ort']).strip()
            
            validation_result = self._validate_plz_city_combination(plz, city)
            
            if validation_result['status'] == 'valid':
                # Direkte Übereinstimmung
                self.df.at[idx, 'geo_validated'] = True
                self.df.at[idx, 'geo_confidence'] = validation_result['confidence']
                self.df.at[idx, 'latitude'] = validation_result['coordinates']['lat']
                self.df.at[idx, 'longitude'] = validation_result['coordinates']['lon']
                self.df.at[idx, 'state'] = validation_result['state']
                self.df.at[idx, 'geo_source'] = 'plz_database_exact'
                validated_count += 1
                
            elif validation_result['status'] == 'correctable':
                # Korrektur möglich
                if validation_result.get('corrected_city'):
                    self.df.at[idx, 'Ort'] = validation_result['corrected_city']
                    self.df.at[idx, 'address_corrected'] = True
                    city_corrections += 1
                
                if validation_result.get('corrected_plz'):
                    self.df.at[idx, 'PLZ'] = validation_result['corrected_plz']
                    self.df.at[idx, 'address_corrected'] = True
                    plz_corrections += 1
                
                self.df.at[idx, 'geo_validated'] = True
                self.df.at[idx, 'geo_confidence'] = validation_result['confidence']
                self.df.at[idx, 'latitude'] = validation_result['coordinates']['lat']
                self.df.at[idx, 'longitude'] = validation_result['coordinates']['lon']
                self.df.at[idx, 'state'] = validation_result['state']
                self.df.at[idx, 'geo_source'] = 'plz_database_corrected'
                corrected_count += 1
                
            elif validation_result['status'] == 'plz_only':
                # Nur PLZ validiert, Stadt unbekannt aber PLZ gültig
                self.df.at[idx, 'geo_validated'] = True
                self.df.at[idx, 'geo_confidence'] = validation_result['confidence']
                self.df.at[idx, 'latitude'] = validation_result['coordinates']['lat']
                self.df.at[idx, 'longitude'] = validation_result['coordinates']['lon']
                self.df.at[idx, 'state'] = validation_result['state']
                self.df.at[idx, 'geo_source'] = 'plz_database_partial'
                validated_count += 1
                
            else:
                # Fallback: Versuche Fuzzy-Matching oder Geocoding
                fuzzy_result = self._fuzzy_address_matching(plz, city)
                if fuzzy_result['found']:
                    self.df.at[idx, 'geo_validated'] = True
                    self.df.at[idx, 'geo_confidence'] = fuzzy_result['confidence']
                    self.df.at[idx, 'latitude'] = fuzzy_result['coordinates']['lat']
                    self.df.at[idx, 'longitude'] = fuzzy_result['coordinates']['lon']
                    self.df.at[idx, 'state'] = fuzzy_result.get('state', '')
                    self.df.at[idx, 'geo_source'] = 'fuzzy_matching'
                    validated_count += 1
        
        # Statistiken aktualisieren
        self.validation_stats['addresses_validated'] = validated_count
        self.validation_stats['addresses_corrected'] = corrected_count
        self.validation_stats['plz_corrections'] = plz_corrections
        self.validation_stats['city_corrections'] = city_corrections
        self.validation_stats['coordinates_added'] = validated_count + corrected_count
        self.validation_stats['validation_rate'] = (validated_count + corrected_count) / len(self.df) * 100
        
        logger.info(f"✅ Geo-Validierung abgeschlossen:")
        logger.info(f"   📍 Validierte Adressen: {validated_count:,}")
        logger.info(f"   🔧 Korrigierte Adressen: {corrected_count:,}")
        logger.info(f"   📮 PLZ-Korrekturen: {plz_corrections:,}")
        logger.info(f"   🏙️ Orts-Korrekturen: {city_corrections:,}")
        logger.info(f"   🌍 Koordinaten hinzugefügt: {self.validation_stats['coordinates_added']:,}")
        logger.info(f"   📊 Validierungsrate: {self.validation_stats['validation_rate']:.1f}%")
        
        return self.df
    
    def _validate_plz_city_combination(self, plz: str, city: str) -> Dict:
        """Validiert PLZ-Stadt-Kombination"""
        if not plz or not city or plz == 'nan' or city == 'nan':
            return {'status': 'invalid', 'confidence': 0}
        
        # PLZ normalisieren
        plz_clean = re.sub(r'[^\d]', '', plz)
        if len(plz_clean) != 5:
            return {'status': 'invalid', 'confidence': 0}
        
        city_clean = city.lower().strip()
        
        # Direkte PLZ-Übereinstimmung
        if plz_clean in self.plz_database:
            db_entry = self.plz_database[plz_clean]
            db_city = db_entry['city'].lower()
            
            # Exakte Übereinstimmung
            if city_clean == db_city:
                return {
                    'status': 'valid',
                    'confidence': 1.0,
                    'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                    'state': db_entry['state']
                }
            
            # Ähnlichkeits-Check
            similarity = self._calculate_similarity(city_clean, db_city)
            if similarity > 0.8:
                return {
                    'status': 'correctable',
                    'confidence': similarity,
                    'corrected_city': db_entry['city'],
                    'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                    'state': db_entry['state']
                }
            
            # PLZ stimmt, aber Stadt passt nicht - nehme PLZ-Koordinaten
            return {
                'status': 'plz_only',
                'confidence': 0.7,
                'coordinates': {'lat': db_entry['lat'], 'lon': db_entry['lon']},
                'state': db_entry['state'],
                'note': f'PLZ {plz_clean} gültig, aber Stadt "{city}" passt nicht zu erwarteter Stadt "{db_entry["city"]}"'
            }
        
        return {'status': 'not_found', 'confidence': 0}
    
    def _fuzzy_address_matching(self, plz: str, city: str) -> Dict:
        """Fuzzy-Matching für unbekannte Adressen"""
        if not plz or not city:
            return {'found': False, 'confidence': 0}
        
        plz_clean = re.sub(r'[^\d]', '', plz)
        city_clean = city.lower().strip()
        
        best_match = {'found': False, 'confidence': 0}
        
        # Suche ähnliche PLZ (Prefix-Match für Regionen)
        if len(plz_clean) >= 2:
            plz_prefix = plz_clean[:2]
            
            for db_plz, db_data in self.plz_database.items():
                if db_plz.startswith(plz_prefix):
                    city_similarity = self._calculate_similarity(city_clean, db_data['city'].lower())
                    if city_similarity > 0.6:
                        confidence = (city_similarity + 0.5) / 2  # Reduzierte Confidence für Fuzzy
                        if confidence > best_match['confidence']:
                            best_match = {
                                'found': True,
                                'confidence': confidence,
                                'coordinates': {'lat': db_data['lat'], 'lon': db_data['lon']},
                                'state': db_data['state'],
                                'matched_plz': db_plz,
                                'matched_city': db_data['city']
                            }
        
        return best_match
    
    def _calculate_similarity(self, str1: str, str2: str) -> float:
        """Berechnet Ähnlichkeit zwischen zwei Strings"""
        from difflib import SequenceMatcher
        return SequenceMatcher(None, str1, str2).ratio()
    
    def perform_geocoding_enhancement(self):
        """Erweitert Geo-Daten durch zusätzliche Services (falls API verfügbar)"""
        logger.info("🌍 Erweitere Geo-Daten...")
        
        # Für Adressen ohne Koordinaten: Versuche alternative Methoden
        no_coords = self.df[self.df['latitude'].isna()]
        enhanced_count = 0
        
        for idx, row in no_coords.iterrows():
            # Vereinfachte Schätzung basierend auf PLZ-Bereichen
            plz = str(row['PLZ']).strip()
            if len(plz) == 5 and plz.isdigit():
                estimated_coords = self._estimate_coordinates_by_plz_range(plz)
                if estimated_coords:
                    self.df.at[idx, 'latitude'] = estimated_coords['lat']
                    self.df.at[idx, 'longitude'] = estimated_coords['lon']
                    self.df.at[idx, 'geo_validated'] = True
                    self.df.at[idx, 'geo_confidence'] = 0.4  # Niedrige Confidence für Schätzung
                    self.df.at[idx, 'geo_source'] = 'plz_range_estimation'
                    enhanced_count += 1
        
        if enhanced_count > 0:
            logger.info(f"🎯 {enhanced_count:,} zusätzliche Koordinaten geschätzt")
            self.validation_stats['coordinates_added'] += enhanced_count
        
        return self.df
    
    def _estimate_coordinates_by_plz_range(self, plz: str) -> Optional[Dict]:
        """Schätzt Koordinaten basierend auf PLZ-Bereichen"""
        if not plz or len(plz) != 5:
            return None
        
        # Deutsche PLZ-Bereiche (grobe Schätzung)
        plz_regions = {
            '0': {'name': 'Sachsen/Thüringen', 'lat': 51.0, 'lon': 13.0},
            '1': {'name': 'Berlin/Brandenburg', 'lat': 52.5, 'lon': 13.4},
            '2': {'name': 'Hamburg/Schleswig-Holstein', 'lat': 53.6, 'lon': 10.0},
            '3': {'name': 'Niedersachsen', 'lat': 52.8, 'lon': 9.8},
            '4': {'name': 'NRW Nord', 'lat': 51.5, 'lon': 7.5},
            '5': {'name': 'NRW Süd', 'lat': 50.7, 'lon': 7.1},
            '6': {'name': 'Hessen', 'lat': 50.5, 'lon': 8.8},
            '7': {'name': 'Baden-Württemberg', 'lat': 48.8, 'lon': 9.2},
            '8': {'name': 'Bayern', 'lat': 48.8, 'lon': 11.5},
            '9': {'name': 'Bayern Nord', 'lat': 49.4, 'lon': 11.1}
        }
        
        first_digit = plz[0]
        if first_digit in plz_regions:
            region = plz_regions[first_digit]
            return {
                'lat': region['lat'] + (hash(plz) % 100 - 50) * 0.01,  # Kleine Variation
                'lon': region['lon'] + (hash(plz) % 100 - 50) * 0.01,
                'region': region['name']
            }
        
        return None
    
    def calculate_geo_quality_score(self):
        """Berechnet den Geo-Qualitäts-Score"""
        logger.info("📊 Berechne Geo-Qualitäts-Score...")
        
        total_records = len(self.df)
        
        # Verschiedene Qualitätsstufen
        exact_matches = sum(1 for source in self.df['geo_source'] if source == 'plz_database_exact')
        corrected_matches = sum(1 for source in self.df['geo_source'] if source == 'plz_database_corrected')
        partial_matches = sum(1 for source in self.df['geo_source'] if source == 'plz_database_partial')
        fuzzy_matches = sum(1 for source in self.df['geo_source'] if source == 'fuzzy_matching')
        estimated_matches = sum(1 for source in self.df['geo_source'] if source == 'plz_range_estimation')
        
        # Gewichteter Score
        geo_score = (
            exact_matches * 1.0 +
            corrected_matches * 0.9 +
            partial_matches * 0.7 +
            fuzzy_matches * 0.6 +
            estimated_matches * 0.4
        ) / total_records * 100
        
        geo_metrics = {
            'geo_quality_score': round(geo_score, 1),
            'total_records': total_records,
            'exact_matches': exact_matches,
            'corrected_matches': corrected_matches,
            'partial_matches': partial_matches,
            'fuzzy_matches': fuzzy_matches,
            'estimated_matches': estimated_matches,
            'validation_rate': round((exact_matches + corrected_matches + partial_matches + fuzzy_matches + estimated_matches) / total_records * 100, 1),
            'coordinates_coverage': round(sum(1 for lat in self.df['latitude'] if pd.notna(lat)) / total_records * 100, 1)
        }
        
        logger.info(f"🗺️ Geo-Qualitäts-Score: {geo_score:.1f}/100")
        logger.info(f"   ✅ Exakte Treffer: {exact_matches:,} ({exact_matches/total_records*100:.1f}%)")
        logger.info(f"   🔧 Korrigierte Treffer: {corrected_matches:,} ({corrected_matches/total_records*100:.1f}%)")
        logger.info(f"   📍 Partielle Treffer: {partial_matches:,} ({partial_matches/total_records*100:.1f}%)")
        logger.info(f"   🎯 Koordinaten-Abdeckung: {geo_metrics['coordinates_coverage']:.1f}%")
        
        return geo_metrics
    
    def save_geo_enhanced_data(self, output_file: str = None):
        """Speichert die geo-erweiterten Daten"""
        if output_file is None:
            output_file = self.enriched_file.replace('_ENRICHED_FINAL.xlsx', '_GEO_ENHANCED.xlsx')
        
        logger.info(f"💾 Speichere geo-erweiterte Daten: {output_file}")
        self.df.to_excel(output_file, index=False)
        
        # Geo-Validierung-Report
        geo_metrics = self.calculate_geo_quality_score()
        
        report_file = output_file.replace('.xlsx', '_GEO_REPORT.json')
        geo_report = {
            'timestamp': datetime.now().isoformat(),
            'source_file': self.enriched_file,
            'geo_enhanced_file': output_file,
            'record_count': len(self.df),
            'validation_statistics': self.validation_stats,
            'geo_quality_metrics': geo_metrics,
            'new_columns_added': [
                'geo_validated', 'geo_confidence', 'latitude', 'longitude', 
                'state', 'geo_source', 'address_corrected', 'original_plz', 'original_city'
            ]
        }
        
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(geo_report, f, indent=2, ensure_ascii=False)
        
        logger.info(f"📋 Geo-Report gespeichert: {report_file}")
        return output_file, report_file, geo_metrics
    
    def run_full_geo_validation(self):
        """Führt die komplette Geo-Validierung durch"""
        logger.info("🚀 Starte umfassende Geo-Koordinaten-Validierung...")
        
        # Lade Daten
        self.load_data()
        
        # Geo-Validierung
        self.validate_and_correct_addresses()
        self.perform_geocoding_enhancement()
        
        # Speichere Ergebnisse
        output_file, report_file, geo_metrics = self.save_geo_enhanced_data()
        
        logger.info("✅ Geo-Validierung abgeschlossen!")
        return output_file, report_file, geo_metrics

def main():
    """Hauptfunktion"""
    enriched_file = 'Kundendatenabgleich_202507251500_ENRICHED_FINAL.xlsx'
    
    geo_engine = GeoValidationEngine(enriched_file)
    output_file, report_file, geo_metrics = geo_engine.run_full_geo_validation()
    
    print("\n" + "="*70)
    print("🗺️ GEO-KOORDINATEN-VALIDIERUNG ABGESCHLOSSEN")
    print("="*70)
    print(f"📁 Geo-erweiterte Datei: {output_file}")
    print(f"🎯 Geo-Qualitäts-Score: {geo_metrics['geo_quality_score']}/100")
    print(f"📍 Koordinaten-Abdeckung: {geo_metrics['coordinates_coverage']:.1f}%")
    print(f"✅ Exakte Treffer: {geo_metrics['exact_matches']:,}")
    print(f"🔧 Korrigierte Adressen: {geo_metrics['corrected_matches']:,}")
    print(f"📊 Gesamt-Validierungsrate: {geo_metrics['validation_rate']:.1f}%")
    print(f"📋 Detailbericht: {report_file}")
    print("="*70)

if __name__ == "__main__":
    main()