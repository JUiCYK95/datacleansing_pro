#!/usr/bin/env python3
"""
Advanced Configurable Data Cleaning Engine
Konfigurationsbasierte, hochpräzise Spalten-Erkennung mit verbesserter Flexibilität
"""

import pandas as pd
import re
import phonenumbers
from phonenumbers import NumberParseException, PhoneNumberFormat
import json
import yaml
from datetime import datetime
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
import logging
from typing import Dict, List, Optional, Tuple, Set
import numpy as np
import os

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AdvancedConfigurableDataCleaningEngine:
    """
    Konfigurationsbasierte Advanced Data Cleaning Engine
    """

    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or "/Users/justin/Desktop/Data Cleansing/config/config.yaml"
        self.config = self._load_config()

        # Dynamischer Dateipfad aus Konfiguration
        self.input_directory = self.config['data_sources']['default_input_directory']
        self.current_file = self.config['data_sources']['current_input_file']
        self.file_path = os.path.join(self.input_directory, self.current_file)

        self.output_directory = self.config['data_sources']['output_directory']
        self.reports_directory = self.config['data_sources']['reports_directory']

        # Engine-spezifische Variablen
        self.df = None
        self.original_count = 0
        self.column_mapping = {}
        self.categorization_confidence = {}
        self.cleaning_stats = {
            'phone_fixes': 0,
            'mobile_fixes': 0,
            'email_fixes': 0,
            'address_fixes': 0,
            'duplicates_removed': 0,
            'quality_improvements': {},
            'categorization_warnings': [],
            'content_analysis': {}
        }

        # Konfigurationsbasierte Pattern
        self._load_categorization_patterns()

    def _load_config(self) -> Dict:
        """Lädt die YAML-Konfiguration"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"✅ Konfiguration geladen: {self.config_path}")
            return config
        except Exception as e:
            logger.error(f"❌ Fehler beim Laden der Konfiguration: {e}")
            # Fallback-Konfiguration
            return self._get_fallback_config()

    def _get_fallback_config(self) -> Dict:
        """Fallback-Konfiguration falls YAML-Datei nicht geladen werden kann"""
        return {
            'data_sources': {
                'default_input_directory': '/Users/justin/Desktop/Kundendaten',
                'current_input_file': 'Kunden9725.xlsx',
                'output_directory': '/Users/justin/Desktop/Data Cleansing/results',
                'reports_directory': '/Users/justin/Desktop/Data Cleansing/reports'
            },
            'categorization': {
                'content_validation_threshold': 0.2,
                'exact_match_override': True,
                'exact_matches': {
                    'phone_fields': ['Telefon', 'Mobiltelefon', 'Fax'],
                    'email_fields': ['eMail', 'Email', 'E-Mail'],
                    'address_fields': ['Straße', 'PLZ', 'Ort'],
                    'name_fields': ['Vorname', 'Nachname'],
                    'date_fields': ['Geburtstag'],
                    'id_fields': ['Kundennummer']
                }
            }
        }

    def _load_categorization_patterns(self) -> None:
        """Lädt Kategorisierungs-Pattern aus der Konfiguration"""

        # Basis-Pattern (erweitert und verbessert)
        self.column_patterns = {
            'phone_fields': {
                'private_phone': {
                    'include': [r'tel.*privat', r'telefon.*privat', r'phone.*private', r'private.*phone',
                               r'festnetz.*privat', r'privates.*telefon', r'^tel\.\s*privat$'],
                    'exclude': [r'email', r'mail', r'@', r'adresse', r'postleitzahl', r'plz']
                },
                'business_phone': {
                    'include': [r'^telefon$', r'tel.*geschäft', r'telefon.*geschäft', r'phone.*business',
                               r'business.*phone', r'geschäftlich.*telefon', r'office.*phone', r'work.*phone',
                               r'telefon.*büro', r'büro.*telefon', r'^telefon\s*geschäftlich$'],
                    'exclude': [r'email', r'mail', r'@', r'adresse', r'postleitzahl', r'plz', r'mobil']
                },
                'mobile_phone': {
                    'include': [r'mobil.*telefon', r'^handy$', r'mobile.*phone', r'cell.*phone',
                               r'smartphone', r'^mobil$', r'cellular', r'mobil-telefon', r'^mobiltelefon$'],
                    'exclude': [r'email', r'mail', r'@', r'adresse', r'geschäft']
                },
                'fax': {
                    'include': [r'^fax$', r'faxnummer', r'telefax', r'fax.*nummer'],
                    'exclude': [r'email', r'mail', r'telefon(?!fax)']
                }
            },
            'email_fields': {
                'include': [r'^e.*mail$', r'^email$', r'mail.*adresse', r'elektronische.*post', r'^e.*post$',
                           r'e-mail-adresse', r'email.*adresse'],
                'exclude': [r'postleitzahl', r'plz', r'telefon', r'phone', r'fax', r'strasse', r'straße']
            },
            'address_fields': {
                'street': {
                    'include': [r'^straße$', r'^strasse$', r'^street$', r'straßen.*name'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'postleitzahl', r'plz']
                },
                'house_number': {
                    'include': [r'^hausnummer$', r'^nr\.?$', r'^number$', r'haus.*nr', r'house.*number'],
                    'exclude': [r'telefon', r'phone', r'email', r'mail', r'kunde', r'id']
                },
                'postal_code': {
                    'include': [r'^plz$', r'postleitzahl(?!.*postfach)', r'postal.*code', r'zip.*code', r'^zip$'],
                    'exclude': [r'postfach', r'email', r'mail', r'telefon', r'phone']
                },
                'city': {
                    'include': [r'^ort$', r'^city$', r'^stadt$', r'gemeinde', r'municipality'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'plz', r'postleitzahl']
                },
                'country': {
                    'include': [r'^land$', r'^country$', r'^nation$'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone']
                }
            },
            'name_fields': {
                'first_name': {
                    'include': [r'^vorname$', r'first.*name', r'given.*name', r'christian.*name'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'firma', r'company']
                },
                'last_name': {
                    'include': [r'^nachname$', r'familienname', r'last.*name', r'^surname$', r'family.*name'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'firma', r'company']
                },
                'title': {
                    'include': [r'^titel$', r'^title$', r'anrede', r'salutation'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone']
                },
                'company': {
                    'include': [r'^firma$', r'unternehmen', r'^company$', r'^business$', r'betrieb'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone']
                }
            },
            'date_fields': {
                'include': [r'datum', r'date', r'geboren', r'birth', r'created', r'erstellt',
                           r'geändert', r'modified', r'updated', r'kontakt', r'besuch', r'seit', r'geburtstag'],
                'exclude': [r'email', r'mail', r'telefon', r'phone']
            },
            'id_fields': {
                'include': [r'^id$', r'nummer', r'number', r'kundennummer', r'customer.*id',
                           r'client.*id', r'referenz', r'reference', r'ust.*id'],
                'exclude': [r'telefon', r'phone', r'email', r'mail', r'hausnummer']
            }
        }

    def switch_input_file(self, filename: str) -> None:
        """Wechselt zur angegebenen Eingabedatei"""
        if filename in self.config['data_sources']['available_files']:
            self.current_file = filename
            self.file_path = os.path.join(self.input_directory, filename)
            logger.info(f"🔄 Eingabedatei gewechselt zu: {filename}")
        else:
            logger.warning(f"⚠️ Datei '{filename}' nicht in verfügbaren Dateien gefunden")
            logger.info(f"📋 Verfügbare Dateien: {self.config['data_sources']['available_files']}")

    def list_available_files(self) -> List[str]:
        """Gibt verfügbare Dateien zurück"""
        return self.config['data_sources']['available_files']

    def load_data(self) -> pd.DataFrame:
        """Lädt die konfigurierte Datei"""
        logger.info(f"📂 Lade Datei: {self.file_path}")

        try:
            if self.file_path.endswith(('.xlsx', '.xls')):
                self.df = pd.read_excel(self.file_path)
            elif self.file_path.endswith('.csv'):
                self.df = self._load_csv_intelligently()
            else:
                raise ValueError(f"Nicht unterstütztes Dateiformat: {self.file_path}")

            # Bereinige DataFrame von leeren/problematischen Spalten
            self.df = self._clean_dataframe_columns()

            self.original_count = len(self.df)
            logger.info(f"✅ {self.original_count:,} Datensätze mit {len(self.df.columns)} Spalten geladen")

            # Erweiterte Spaltenstruktur-Analyse
            self.analyze_column_structure_advanced()
            return self.df

        except Exception as e:
            logger.error(f"❌ Fehler beim Laden der Datei: {e}")
            raise

    def _clean_dataframe_columns(self) -> pd.DataFrame:
        """Bereinigt problematische Spalten im DataFrame"""
        original_columns = len(self.df.columns)

        # Entferne leere oder problematische Spaltennamen
        columns_to_drop = []

        for col in self.df.columns:
            col_str = str(col).strip()
            # Leere Spalten oder nur Whitespace/Newlines
            if (not col_str or
                col_str in ['', ' ', '\n', '\r\n', 'nan', 'None'] or
                len(col_str) == 0 or
                col_str.isspace()):
                columns_to_drop.append(col)
                continue

            # Spalten die komplett leer sind
            if self.df[col].isna().all():
                columns_to_drop.append(col)
                continue

        if columns_to_drop:
            self.df = self.df.drop(columns=columns_to_drop)
            logger.info(f"🧹 {len(columns_to_drop)} problematische Spalten entfernt: {columns_to_drop}")

        cleaned_columns = len(self.df.columns)
        logger.info(f"📊 Spalten: {original_columns} → {cleaned_columns}")

        return self.df

    def _load_csv_intelligently(self) -> pd.DataFrame:
        """Intelligentes CSV-Laden"""
        encodings = ['utf-8', 'latin1', 'cp1252', 'iso-8859-1']
        separators = [',', ';', '\t', '|']

        for encoding in encodings:
            for sep in separators:
                try:
                    df = pd.read_csv(self.file_path, encoding=encoding, sep=sep)
                    if len(df.columns) > 1 and len(df) > 0:
                        logger.info(f"✅ CSV geladen: Encoding={encoding}, Separator='{sep}'")
                        return df
                except:
                    continue

        raise ValueError("CSV konnte mit keiner Encoding/Separator-Kombination geladen werden")

    def analyze_column_structure_advanced(self) -> None:
        """Erweiterte konfigurationsbasierte Spalten-Analyse"""
        logger.info("🔍 Starte konfigurationsbasierte Spaltenstruktur-Analyse...")

        self.column_mapping = {
            'phone_fields': {},
            'email_fields': [],
            'address_fields': {},
            'name_fields': {},
            'date_fields': [],
            'id_fields': [],
            'other_fields': []
        }

        self.categorization_confidence = {}

        # Phase 1: Pattern-basierte Vorkategorisierung
        preliminary_mapping = self._pattern_based_categorization()

        # Phase 2: Konfigurationsbasierte Content-Validierung
        validated_mapping = self._content_based_validation_advanced(preliminary_mapping)

        # Phase 3: Konflikt-Auflösung
        self.column_mapping = self._resolve_conflicts(validated_mapping)

        # Phase 4: Qualitätssicherung
        self._validate_final_categorization()

        # Ergebnisse ausgeben
        self._log_advanced_column_mapping()

    def _content_based_validation_advanced(self, preliminary_mapping: Dict) -> Dict:
        """Erweiterte konfigurationsbasierte Content-Validierung"""
        logger.info("🔍 Phase 2: Konfigurationsbasierte Content-Validierung...")

        validated_mapping = {}
        threshold = self.config['categorization']['content_validation_threshold']

        for category, subcategories in preliminary_mapping.items():
            validated_mapping[category] = {}

            for subcategory, columns in subcategories.items():
                validated_columns = []

                for column in columns:
                    confidence = self._analyze_column_content(column, category, subcategory)

                    self.categorization_confidence[column] = {
                        'category': category,
                        'subcategory': subcategory,
                        'pattern_confidence': 0.8,
                        'content_confidence': confidence,
                        'overall_confidence': confidence
                    }

                    # Konfigurationsbasierte Exact Match Override
                    exact_match_override = self._check_exact_column_match_config(column, category)

                    # Validierung mit konfigurierbarem Threshold
                    if confidence > threshold or exact_match_override:
                        validated_columns.append(column)
                        if exact_match_override:
                            # Überschreibe niedrige Content-Confidence bei exakten Matches
                            self.categorization_confidence[column]['content_confidence'] = 0.95
                            self.categorization_confidence[column]['overall_confidence'] = 0.95
                            logger.info(f"🎯 Exact Match Override: '{column}' → {category}")
                    else:
                        # Bei niedriger Confidence als "other" kategorisieren
                        self.cleaning_stats['categorization_warnings'].append({
                            'column': column,
                            'issue': f'Niedrige Content-Confidence ({confidence:.2f}) für Kategorie {category}',
                            'action': 'Moved to other_fields'
                        })

                if validated_columns:
                    validated_mapping[category][subcategory] = validated_columns

        return validated_mapping

    def _check_exact_column_match_config(self, column: str, category: str) -> bool:
        """Prüft exakte Spalten-Matches basierend auf Konfiguration"""
        if not self.config['categorization']['exact_match_override']:
            return False

        exact_matches = self.config['categorization']['exact_matches']

        if category in exact_matches:
            return column in exact_matches[category]

        return False

    def _pattern_based_categorization(self) -> Dict:
        """Pattern-basierte Vorkategorisierung mit Prioritäten"""
        logger.info("🔍 Phase 1: Pattern-basierte Vorkategorisierung...")

        preliminary_mapping = defaultdict(lambda: defaultdict(list))
        used_columns = set()

        # Prioritäts-Reihenfolge (hohe Priorität zuerst)
        priority_order = [
            ('id_fields', self.column_patterns['id_fields']),
            ('email_fields', self.column_patterns['email_fields']),
            ('phone_fields', self.column_patterns['phone_fields']),
            ('address_fields', self.column_patterns['address_fields']),
            ('name_fields', self.column_patterns['name_fields']),
            ('date_fields', self.column_patterns['date_fields'])
        ]

        for column in self.df.columns:
            column_lower = str(column).lower().strip()
            best_match = None
            best_confidence = 0

            for category_name, category_patterns in priority_order:
                if column in used_columns:
                    continue

                match_result = self._advanced_pattern_match(column_lower, category_patterns)
                if match_result['confidence'] > best_confidence:
                    best_match = (category_name, match_result['subcategory'], match_result['confidence'])
                    best_confidence = match_result['confidence']

            if best_match and best_confidence > 0.7:  # Mindest-Confidence
                category, subcategory, confidence = best_match
                if subcategory:
                    preliminary_mapping[category][subcategory].append(column)
                else:
                    preliminary_mapping[category]['default'].append(column)
                used_columns.add(column)
            else:
                preliminary_mapping['other_fields']['default'].append(column)

        return dict(preliminary_mapping)

    def _advanced_pattern_match(self, column_lower: str, patterns: Dict) -> Dict:
        """Erweiterte Pattern-Matching mit Include/Exclude-Logik"""

        if isinstance(patterns, dict) and 'include' in patterns:
            # Einfache Struktur
            include_score = self._calculate_pattern_score(column_lower, patterns['include'])
            exclude_score = self._calculate_pattern_score(column_lower, patterns.get('exclude', []))

            confidence = max(0, include_score - exclude_score * 2)
            return {'confidence': confidence, 'subcategory': None}

        elif isinstance(patterns, dict):
            # Verschachtelte Struktur
            best_subcategory = None
            best_confidence = 0

            for subcategory, subpatterns in patterns.items():
                if isinstance(subpatterns, dict) and 'include' in subpatterns:
                    include_score = self._calculate_pattern_score(column_lower, subpatterns['include'])
                    exclude_score = self._calculate_pattern_score(column_lower, subpatterns.get('exclude', []))

                    confidence = max(0, include_score - exclude_score * 2)

                    if confidence > best_confidence:
                        best_confidence = confidence
                        best_subcategory = subcategory

            return {'confidence': best_confidence, 'subcategory': best_subcategory}

        return {'confidence': 0, 'subcategory': None}

    def _calculate_pattern_score(self, text: str, patterns: List[str]) -> float:
        """Berechnet Pattern-Score mit gewichteten Matches"""
        if not patterns:
            return 0

        scores = []
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                # Exakte Matches bekommen höhere Scores
                if match.group() == text:
                    scores.append(1.0)
                else:
                    # Partieller Match, gewichtet nach Länge des Matches
                    match_ratio = len(match.group()) / len(text)
                    scores.append(match_ratio * 0.8)

        return max(scores) if scores else 0

    def _analyze_column_content(self, column: str, category: str, subcategory: str) -> float:
        """Analysiert den Spalten-Inhalt zur Validierung der Kategorisierung"""

        if column not in self.df.columns:
            return 0

        # Sample nehmen für Performance
        sample_size = min(200, len(self.df))
        sample = self.df[column].dropna().head(sample_size)

        if len(sample) == 0:
            return 0.1  # Leere Spalten bekommen minimale Confidence

        # Content-Analyse je nach Kategorie
        if category == 'phone_fields':
            return self._analyze_phone_content(sample)
        elif category == 'email_fields':
            return self._analyze_email_content(sample)
        elif category == 'address_fields':
            return self._analyze_address_content(sample, subcategory)
        elif category == 'name_fields':
            return self._analyze_name_content(sample, subcategory)
        elif category == 'date_fields':
            return self._analyze_date_content(sample)
        elif category == 'id_fields':
            return self._analyze_id_content(sample)
        else:
            return 0.5  # Neutrale Confidence für andere Felder

    def _analyze_phone_content(self, sample: pd.Series) -> float:
        """Analysiert ob Spalten-Inhalt tatsächlich Telefonnummern enthält"""
        phone_like_count = 0
        total_count = len(sample)

        phone_patterns = [
            r'^\+?[\d\s\-\(\)\/]{7,}$',      # Grundlegendes Telefonnummer-Muster
            r'^0\d{2,4}[\-\/\s]?\d{4,}$',   # Deutsche Formate
            r'^\+49\s?\d',                   # Deutsche internationale Nummer
            r'^\(\d{3,4}\)\s?\d',            # Mit Klammern
            r'^\d{4,5}\s?\d{4,8}$'           # Einfaches Format
        ]

        for value in sample:
            value_str = str(value).strip()

            # Skip offensichtlich falsche Werte
            if len(value_str) < 5 or len(value_str) > 20:
                continue

            # Prüfe auf Telefonnummer-Muster
            for pattern in phone_patterns:
                if re.match(pattern, value_str):
                    phone_like_count += 1
                    break
            else:
                # Zusätzliche Heuristik: mindestens 60% Ziffern
                digits = sum(1 for c in value_str if c.isdigit())
                if digits >= len(value_str) * 0.6 and len(value_str) >= 7:
                    phone_like_count += 1

        confidence = phone_like_count / total_count

        # Speichere Analyse-Details
        self.cleaning_stats['content_analysis'][f'phone_analysis_{len(self.cleaning_stats["content_analysis"])}'] = {
            'total_samples': total_count,
            'phone_like': phone_like_count,
            'confidence': confidence
        }

        return confidence

    def _analyze_email_content(self, sample: pd.Series) -> float:
        """Analysiert ob Spalten-Inhalt tatsächlich E-Mail-Adressen enthält"""
        email_like_count = 0
        total_count = len(sample)

        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

        for value in sample:
            value_str = str(value).strip().lower()

            if '@' in value_str and '.' in value_str:
                if re.match(email_pattern, value_str):
                    email_like_count += 1

        confidence = email_like_count / total_count

        self.cleaning_stats['content_analysis'][f'email_analysis_{len(self.cleaning_stats["content_analysis"])}'] = {
            'total_samples': total_count,
            'email_like': email_like_count,
            'confidence': confidence
        }

        return confidence

    def _analyze_address_content(self, sample: pd.Series, subcategory: str) -> float:
        """Analysiert Adress-Felder basierend auf Subkategorie"""

        if subcategory == 'postal_code':
            return self._analyze_postal_code_content(sample)
        elif subcategory == 'city':
            return self._analyze_city_content(sample)
        elif subcategory == 'street':
            return self._analyze_street_content(sample)
        else:
            return 0.5  # Default für andere Adress-Felder

    def _analyze_postal_code_content(self, sample: pd.Series) -> float:
        """Analysiert PLZ-Inhalt"""
        plz_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            # Deutsche PLZ: 5 Ziffern
            if re.match(r'^\d{5}$', value_str):
                plz_like_count += 1
            # 4 Ziffern (könnte PLZ ohne führende 0 sein)
            elif re.match(r'^\d{4}$', value_str):
                plz_like_count += 0.8

        return plz_like_count / total_count

    def _analyze_city_content(self, sample: pd.Series) -> float:
        """Analysiert Stadt-Namen"""
        city_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            if (2 <= len(value_str) <= 50 and
                not '@' in value_str and
                not value_str.isdigit() and
                sum(1 for c in value_str if c.isalpha()) >= len(value_str) * 0.5):
                city_like_count += 1

        return city_like_count / total_count

    def _analyze_street_content(self, sample: pd.Series) -> float:
        """Analysiert Straßen-Namen"""
        street_like_count = 0
        total_count = len(sample)

        street_indicators = ['straße', 'strasse', 'str.', 'weg', 'platz', 'gasse', 'allee']

        for value in sample:
            value_str = str(value).strip().lower()

            has_street_indicator = any(indicator in value_str for indicator in street_indicators)
            has_mixed_content = (any(c.isalpha() for c in value_str) and
                               any(c.isdigit() for c in value_str))

            if (has_street_indicator or has_mixed_content) and '@' not in value_str:
                street_like_count += 1

        return street_like_count / total_count

    def _analyze_name_content(self, sample: pd.Series, subcategory: str) -> float:
        """Analysiert Namen-Inhalt"""
        name_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            if (2 <= len(value_str) <= 50 and
                '@' not in value_str and
                not value_str.replace(' ', '').isdigit() and
                sum(1 for c in value_str if c.isalpha()) >= len(value_str.replace(' ', '')) * 0.7):
                name_like_count += 1

        return name_like_count / total_count

    def _analyze_date_content(self, sample: pd.Series) -> float:
        """Analysiert Datums-Inhalt"""
        date_like_count = 0
        total_count = len(sample)

        date_patterns = [
            r'\d{1,2}[\.\/\-]\d{1,2}[\.\/\-]\d{2,4}',
            r'\d{4}[\.\/\-]\d{1,2}[\.\/\-]\d{1,2}',
            r'\d{1,2}\.\d{1,2}\.\d{4}',
        ]

        for value in sample:
            value_str = str(value).strip()

            for pattern in date_patterns:
                if re.search(pattern, value_str):
                    date_like_count += 1
                    break

        return date_like_count / total_count

    def _analyze_id_content(self, sample: pd.Series) -> float:
        """Analysiert ID-Inhalt"""
        id_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            if (len(value_str) >= 3 and
                not '@' in value_str and
                (value_str.isdigit() or value_str.replace('-', '').replace('_', '').isalnum())):
                id_like_count += 1

        return id_like_count / total_count

    def _resolve_conflicts(self, validated_mapping: Dict) -> Dict:
        """Löst Konflikte zwischen Kategorisierungen auf"""
        logger.info("🔍 Phase 3: Konflikt-Auflösung...")

        final_mapping = {
            'phone_fields': {},
            'email_fields': [],
            'address_fields': {},
            'name_fields': {},
            'date_fields': [],
            'id_fields': [],
            'other_fields': []
        }

        # Alle Spalten sammeln
        all_categorized_columns = set()
        column_categories = defaultdict(list)

        for category, subcategories in validated_mapping.items():
            if category == 'other_fields':
                continue

            for subcategory, columns in subcategories.items():
                for column in columns:
                    if column in all_categorized_columns:
                        column_categories[column].append((category, subcategory))
                    else:
                        all_categorized_columns.add(column)
                        column_categories[column].append((category, subcategory))

        # Löse Konflikte basierend auf Confidence-Scores
        for column, categories in column_categories.items():
            if len(categories) == 1:
                # Kein Konflikt
                category, subcategory = categories[0]
                self._add_to_final_mapping(final_mapping, column, category, subcategory)
            else:
                # Konflikt: Wähle beste Confidence
                best_category = None
                best_subcategory = None
                best_confidence = 0

                for category, subcategory in categories:
                    confidence = self.categorization_confidence.get(column, {}).get('overall_confidence', 0)
                    if confidence > best_confidence:
                        best_confidence = confidence
                        best_category = category
                        best_subcategory = subcategory

                if best_category:
                    self._add_to_final_mapping(final_mapping, column, best_category, best_subcategory)

                    self.cleaning_stats['categorization_warnings'].append({
                        'column': column,
                        'issue': f'Konflikt zwischen {categories}',
                        'action': f'Gewählt: {best_category}/{best_subcategory} (Confidence: {best_confidence:.2f})'
                    })

        # Füge nicht kategorisierte Spalten zu other_fields hinzu
        for column in self.df.columns:
            if column not in all_categorized_columns:
                final_mapping['other_fields'].append(column)

        return final_mapping

    def _add_to_final_mapping(self, final_mapping: Dict, column: str, category: str, subcategory: str) -> None:
        """Fügt eine Spalte zur finalen Zuordnung hinzu"""
        if category in ['phone_fields', 'address_fields', 'name_fields']:
            final_mapping[category][subcategory] = column
        elif category in ['email_fields', 'date_fields', 'id_fields']:
            final_mapping[category].append(column)

    def _validate_final_categorization(self) -> None:
        """Führt finale Qualitätssicherung der Kategorisierung durch"""
        logger.info("🔍 Phase 4: Finale Qualitätssicherung...")

        validation_warnings = []

        # Prüfe E-Mail-Felder
        for email_field in self.column_mapping['email_fields']:
            sample = self.df[email_field].dropna().head(50)
            actual_emails = sum(1 for x in sample if '@' in str(x))

            if len(sample) > 0 and actual_emails / len(sample) < 0.1:
                validation_warnings.append({
                    'field': email_field,
                    'category': 'email_fields',
                    'issue': f'Nur {actual_emails}/{len(sample)} Einträge sind E-Mails',
                    'severity': 'HIGH'
                })

        # Prüfe Telefon-Felder
        for phone_type, phone_field in self.column_mapping['phone_fields'].items():
            if phone_field:
                sample = self.df[phone_field].dropna().head(50)
                actual_phones = sum(1 for x in sample if re.search(r'[\d\+\-\(\)\s]{5,}', str(x)))

                if len(sample) > 0 and actual_phones / len(sample) < 0.2:
                    validation_warnings.append({
                        'field': phone_field,
                        'category': f'phone_fields/{phone_type}',
                        'issue': f'Nur {actual_phones}/{len(sample)} Einträge sehen wie Telefonnummern aus',
                        'severity': 'MEDIUM'
                    })

        # Warnung ausgeben
        if validation_warnings:
            logger.warning(f"⚠️ {len(validation_warnings)} Kategorisierungs-Warnungen gefunden:")
            for warning in validation_warnings:
                logger.warning(f"   - {warning['field']}: {warning['issue']}")

        self.cleaning_stats['categorization_warnings'].extend(validation_warnings)

    def _log_advanced_column_mapping(self) -> None:
        """Gibt die erweiterte Spalten-Zuordnung aus"""
        logger.info("📋 Finale konfigurationsbasierte Spaltenstruktur:")

        for category, fields in self.column_mapping.items():
            if fields:
                logger.info(f"   {category}:")

                if isinstance(fields, dict):
                    for field_type, column_name in fields.items():
                        if column_name:
                            confidence = self.categorization_confidence.get(column_name, {}).get('overall_confidence', 0)
                            logger.info(f"     - {field_type}: '{column_name}' (Confidence: {confidence:.2f})")
                elif isinstance(fields, list):
                    for column_name in fields:
                        confidence = self.categorization_confidence.get(column_name, {}).get('overall_confidence', 0)
                        logger.info(f"     - '{column_name}' (Confidence: {confidence:.2f})")

        logger.info(f"📊 Kategorisierungs-Statistiken:")
        logger.info(f"   - Warnungen: {len(self.cleaning_stats['categorization_warnings'])}")
        logger.info(f"   - Analysierte Spalten: {len(self.categorization_confidence)}")
        logger.info(f"   - Content Validation Threshold: {self.config['categorization']['content_validation_threshold']}")
        logger.info(f"   - Exact Match Override: {self.config['categorization']['exact_match_override']}")

    def clean_phone_numbers_advanced(self) -> None:
        """Erweiterte Telefonnummer-Bereinigung für deutsche Formate"""
        logger.info("📞 Starte erweiterte Telefonnummer-Bereinigung...")

        phone_fields = self.column_mapping['phone_fields']

        for phone_type, column in phone_fields.items():
            if not column or column not in self.df.columns:
                continue

            logger.info(f"📞 Bearbeite {phone_type}: '{column}'")
            original_count = self.df[column].notna().sum()

            # Bereinige Telefonnummern
            self.df[column] = self.df[column].apply(self._clean_phone_number)

            # Zähle Verbesserungen
            cleaned_count = self.df[column].notna().sum()
            fixes = cleaned_count - original_count

            if fixes > 0:
                self.cleaning_stats['phone_fixes'] += fixes
                logger.info(f"✅ {fixes} Telefonnummern in '{column}' verbessert")

    def _clean_phone_number(self, phone) -> str:
        """Bereinigt eine einzelne Telefonnummer"""
        if pd.isna(phone) or phone == '':
            return phone

        phone_str = str(phone).strip()

        # Entferne häufige Probleme
        phone_str = re.sub(r'[^\d\+\-\(\)\s\/]', '', phone_str)
        phone_str = re.sub(r'\s+', ' ', phone_str).strip()

        # Deutsche Formate normalisieren
        if phone_str.startswith('0'):
            # 030/12345 → 030 12345
            phone_str = re.sub(r'(\d{3,4})[\/\-](\d+)', r'\1 \2', phone_str)

        return phone_str

    def clean_email_addresses_advanced(self) -> None:
        """Erweiterte E-Mail-Adressen-Bereinigung"""
        logger.info("📧 Starte erweiterte E-Mail-Bereinigung...")

        email_fields = self.column_mapping['email_fields']

        for column in email_fields:
            if not column or column not in self.df.columns:
                continue

            logger.info(f"📧 Bearbeite E-Mail-Feld: '{column}'")
            original_count = self.df[column].notna().sum()

            # Bereinige E-Mails
            self.df[column] = self.df[column].apply(self._clean_email_address)

            # Zähle Verbesserungen
            cleaned_count = self.df[column].notna().sum()
            fixes = cleaned_count - original_count

            if fixes > 0:
                self.cleaning_stats['email_fixes'] += fixes
                logger.info(f"✅ {fixes} E-Mail-Adressen in '{column}' verbessert")

    def _clean_email_address(self, email) -> str:
        """Bereinigt eine einzelne E-Mail-Adresse"""
        if pd.isna(email) or email == '':
            return email

        email_str = str(email).strip().lower()

        # Entferne Leerzeichen um @
        email_str = re.sub(r'\s*@\s*', '@', email_str)

        # Validiere E-Mail-Format
        if '@' in email_str and '.' in email_str.split('@')[-1]:
            return email_str

        return email

    def clean_addresses_advanced(self) -> None:
        """Erweiterte Adress-Bereinigung"""
        logger.info("🏠 Starte erweiterte Adress-Bereinigung...")

        address_fields = self.column_mapping['address_fields']

        for field_type, column in address_fields.items():
            if not column or column not in self.df.columns:
                continue

            logger.info(f"🏠 Bearbeite {field_type}: '{column}'")

            if field_type == 'postal_code':
                self.df[column] = self.df[column].apply(self._clean_postal_code)
            elif field_type == 'city':
                self.df[column] = self.df[column].apply(self._clean_city_name)
            elif field_type == 'street':
                self.df[column] = self.df[column].apply(self._clean_street_name)

            self.cleaning_stats['address_fixes'] += 1

    def _clean_postal_code(self, plz) -> str:
        """Bereinigt Postleitzahlen"""
        if pd.isna(plz) or plz == '':
            return plz

        plz_str = str(plz).strip()

        # Nur Ziffern beibehalten
        plz_clean = re.sub(r'[^\d]', '', plz_str)

        # Deutsche PLZ: 5 Ziffern, führende Nullen hinzufügen
        if len(plz_clean) == 4:
            plz_clean = '0' + plz_clean
        elif len(plz_clean) == 5:
            return plz_clean

        return plz_clean if len(plz_clean) == 5 else plz

    def _clean_city_name(self, city) -> str:
        """Bereinigt Stadtnamen"""
        if pd.isna(city) or city == '':
            return city

        city_str = str(city).strip()

        # Titel-Format
        return city_str.title()

    def _clean_street_name(self, street) -> str:
        """Bereinigt Straßennamen"""
        if pd.isna(street) or street == '':
            return street

        street_str = str(street).strip()

        # Normalisiere Straßen-Abkürzungen
        street_str = re.sub(r'\bStr\.\b', 'Straße', street_str)
        street_str = re.sub(r'\bstr\b', 'straße', street_str, flags=re.IGNORECASE)

        return street_str

    def remove_duplicates_intelligent(self) -> None:
        """Intelligente Duplikat-Entfernung mit verbesserter Logik"""
        logger.info("🔍 Starte intelligente Duplikat-Entfernung...")

        original_count = len(self.df)
        self.cleaning_stats['duplicate_analysis'] = {}

        # Analysiere Datenstruktur
        self._analyze_data_structure()

        # Bestimme Duplikat-Strategie basierend auf Datentyp
        if self._is_customer_based_data():
            duplicates_removed = self._remove_customer_duplicates()
        elif self._is_vehicle_based_data():
            duplicates_removed = self._remove_vehicle_duplicates()
        else:
            duplicates_removed = self._remove_generic_duplicates()

        self.cleaning_stats['duplicates_removed'] = duplicates_removed

        if duplicates_removed > 0:
            logger.info(f"✅ {duplicates_removed} Duplikate entfernt")
        else:
            logger.info("ℹ️ Keine Duplikate gefunden")

    def _analyze_data_structure(self) -> None:
        """Analysiert die Datenstruktur um den Datentyp zu bestimmen"""
        vehicle_indicators = ['Fahrzeug', 'Kennzeichen', 'Modell', 'Fabrikat', 'KM-Stand', 'TÜV']
        customer_indicators = ['Kunde', 'Kundennummer', 'Vorname', 'Nachname']

        vehicle_fields = sum(1 for col in self.df.columns if any(indicator in str(col) for indicator in vehicle_indicators))
        customer_fields = sum(1 for col in self.df.columns if any(indicator in str(col) for indicator in customer_indicators))

        self.cleaning_stats['duplicate_analysis']['vehicle_fields_found'] = vehicle_fields
        self.cleaning_stats['duplicate_analysis']['customer_fields_found'] = customer_fields
        self.cleaning_stats['duplicate_analysis']['data_type'] = 'vehicle_based' if vehicle_fields > 5 else 'customer_based'

        logger.info(f"📊 Datenstruktur-Analyse: {vehicle_fields} Fahrzeug-Felder, {customer_fields} Kunden-Felder")

    def _is_customer_based_data(self) -> bool:
        """Prüft ob es sich um kunden-basierte Daten handelt"""
        return self.cleaning_stats['duplicate_analysis']['data_type'] == 'customer_based'

    def _is_vehicle_based_data(self) -> bool:
        """Prüft ob es sich um fahrzeug-basierte Daten handelt"""
        return self.cleaning_stats['duplicate_analysis']['data_type'] == 'vehicle_based'

    def _remove_customer_duplicates(self) -> int:
        """Entfernt echte Kunden-Duplikate"""
        logger.info("👤 Erkenne Kunden-basierte Daten - verwende Kunden-Duplikat-Logic")

        original_count = len(self.df)
        key_fields = []

        # E-Mail als Hauptkriterium (nur bei validen E-Mails)
        for email_field in self.column_mapping['email_fields']:
            if email_field in self.df.columns:
                # Filtere nur gültige E-Mails
                valid_emails = self.df[email_field].dropna()
                valid_emails = valid_emails[valid_emails.str.contains('@', na=False)]
                if len(valid_emails) > len(self.df) * 0.1:  # Mindestens 10% gültige E-Mails
                    key_fields.append(email_field)

        if key_fields:
            # Erstelle Maske für gültige E-Mails
            mask = self.df[key_fields[0]].str.contains('@', na=False)

            # Entferne nur Duplikate mit gültigen E-Mails
            valid_rows = self.df[mask]
            invalid_rows = self.df[~mask]

            valid_rows_deduplicated = valid_rows.drop_duplicates(subset=key_fields, keep='first')
            self.df = pd.concat([valid_rows_deduplicated, invalid_rows], ignore_index=True)

        return original_count - len(self.df)

    def _remove_vehicle_duplicates(self) -> int:
        """Entfernt echte Fahrzeug-Duplikate (sehr konservativ)"""
        logger.info("🚗 Erkenne Fahrzeug-basierte Daten - verwende sehr konservative Duplikat-Logic")

        original_count = len(self.df)

        # Suche eindeutige Identifikatoren
        potential_keys = []

        # Kundennummer + Fahrzeug-spezifische Felder
        if 'Kundennummer' in self.df.columns:
            vehicle_identifiers = ['Kennzeichen', 'Fahrzeug Nr.']
            for vehicle_id in vehicle_identifiers:
                if vehicle_id in self.df.columns:
                    potential_keys = ['Kundennummer', vehicle_id]
                    break

        if potential_keys:
            logger.info(f"🔑 Verwende Fahrzeug-Schlüssel: {potential_keys}")

            # Nur entfernen wenn BEIDE Felder identisch und nicht leer sind
            mask = self.df[potential_keys].notna().all(axis=1)
            valid_rows = self.df[mask]
            invalid_rows = self.df[~mask]

            if len(valid_rows) > 0:
                valid_rows_deduplicated = valid_rows.drop_duplicates(subset=potential_keys, keep='first')
                self.df = pd.concat([valid_rows_deduplicated, invalid_rows], ignore_index=True)
        else:
            logger.info("⚠️ Keine geeigneten Fahrzeug-Schlüssel gefunden - KEINE Duplikate entfernt")
            return 0

        return original_count - len(self.df)

    def _remove_generic_duplicates(self) -> int:
        """Entfernt nur offensichtliche Duplikate"""
        logger.info("📝 Verwende generische Duplikat-Logic")

        original_count = len(self.df)

        # Nur bei komplett identischen Zeilen (alle Felder gleich)
        self.df = self.df.drop_duplicates(keep='first')

        return original_count - len(self.df)

    def calculate_quality_score_advanced(self) -> Dict:
        """Berechnet erweiterten Qualitäts-Score"""
        logger.info("📊 Berechne erweiterten Qualitäts-Score...")

        scores = {
            'categorization_accuracy': 0,
            'phone_validity': 0,
            'email_validity': 0,
            'data_completeness': 0,
            'overall_score': 0
        }

        # Kategorisierungs-Genauigkeit
        total_confidence = sum(conf.get('overall_confidence', 0)
                              for conf in self.categorization_confidence.values())
        if self.categorization_confidence:
            scores['categorization_accuracy'] = (total_confidence / len(self.categorization_confidence)) * 100

        # Telefon-Validität
        phone_valid_count = 0
        phone_total_count = 0

        for phone_type, phone_field in self.column_mapping['phone_fields'].items():
            if phone_field in self.df.columns:
                sample = self.df[phone_field].dropna()
                phone_total_count += len(sample)
                phone_valid_count += sum(1 for x in sample if re.search(r'[\d\+\-\(\)\s]{7,}', str(x)))

        if phone_total_count > 0:
            scores['phone_validity'] = (phone_valid_count / phone_total_count) * 100

        # E-Mail-Validität
        email_valid_count = 0
        email_total_count = 0

        for email_field in self.column_mapping['email_fields']:
            if email_field in self.df.columns:
                sample = self.df[email_field].dropna()
                email_total_count += len(sample)
                email_valid_count += sum(1 for x in sample if '@' in str(x) and '.' in str(x))

        if email_total_count > 0:
            scores['email_validity'] = (email_valid_count / email_total_count) * 100

        # Daten-Vollständigkeit
        total_cells = len(self.df) * len(self.df.columns)
        filled_cells = total_cells - self.df.isna().sum().sum()
        scores['data_completeness'] = (filled_cells / total_cells) * 100

        # Gesamt-Score (gewichtet)
        scores['overall_score'] = (
            scores['categorization_accuracy'] * 0.35 +
            scores['phone_validity'] * 0.25 +
            scores['email_validity'] * 0.25 +
            scores['data_completeness'] * 0.15
        )

        logger.info(f"📊 Quality-Scores:")
        for metric, score in scores.items():
            logger.info(f"   - {metric}: {score:.1f}%")

        return scores

    def save_cleaned_data_advanced(self, output_file: Optional[str] = None) -> Tuple[str, str]:
        """Speichert die bereinigten Daten mit konfigurationsbasierten Pfaden"""
        if output_file is None:
            filename = Path(self.current_file).stem
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = f"{filename}_CONFIGURABLE_CLEANED_{timestamp}.xlsx"

        # Verwende konfigurierten Output-Pfad
        output_path = os.path.join(self.output_directory, output_file)

        logger.info(f"💾 Speichere konfigurationsbasierte bereinigte Daten: {output_path}")
        self.df.to_excel(output_path, index=False)

        # Erweiterten Cleaning-Report speichern
        report_file = output_file.replace('.xlsx', '_CONFIGURABLE_REPORT.json')
        report_path = os.path.join(self.reports_directory, report_file)

        cleaning_report = {
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'engine_version': 'Advanced Configurable v3.0',
                'config_path': self.config_path,
                'processing_time': 'calculated_during_runtime'
            },
            'configuration': {
                'input_file': self.current_file,
                'content_validation_threshold': self.config['categorization']['content_validation_threshold'],
                'exact_match_override': self.config['categorization']['exact_match_override'],
                'available_files': self.config['data_sources']['available_files']
            },
            'file_info': {
                'original_file': str(self.file_path),
                'cleaned_file': output_path,
                'original_size_mb': Path(self.file_path).stat().st_size / (1024*1024) if Path(self.file_path).exists() else 0,
                'cleaned_size_mb': Path(output_path).stat().st_size / (1024*1024) if Path(output_path).exists() else 0
            },
            'data_summary': {
                'original_record_count': self.original_count,
                'cleaned_record_count': len(self.df),
                'records_removed': self.original_count - len(self.df),
                'total_columns': len(self.df.columns)
            },
            'categorization_results': {
                'column_mapping': self.column_mapping,
                'categorization_confidence': self.categorization_confidence,
                'categorization_warnings': self.cleaning_stats.get('categorization_warnings', [])
            },
            'cleaning_statistics': self.cleaning_stats
        }

        with open(report_path, 'w', encoding='utf-8') as f:
            json.dump(cleaning_report, f, indent=2, ensure_ascii=False, default=str)

        logger.info(f"📋 Konfigurationsbasierten Report gespeichert: {report_path}")
        return output_path, report_path

    def run_full_configurable_cleaning(self) -> Tuple[str, str, Dict]:
        """Führt die komplette konfigurationsbasierte Datenbereinigung durch"""
        start_time = datetime.now()
        logger.info("🚀 Starte konfigurationsbasierte erweiterte Datenbereinigung...")
        logger.info(f"📁 Aktuelle Datei: {self.current_file}")
        logger.info(f"⚙️ Konfiguration: {self.config_path}")

        try:
            # Phase 1: Daten laden mit Konfiguration
            self.load_data()

            # Phase 2: Bereinigungsphasen
            self.clean_phone_numbers_advanced()
            self.clean_email_addresses_advanced()
            self.clean_addresses_advanced()
            self.remove_duplicates_intelligent()

            # Phase 3: Qualitäts-Score berechnen
            quality_score = self.calculate_quality_score_advanced()

            # Phase 4: Speichere mit konfigurierten Pfaden
            cleaned_file, report_file = self.save_cleaned_data_advanced()

            # Verarbeitungszeit berechnen
            processing_time = datetime.now() - start_time
            logger.info(f"✅ Konfigurationsbasierte Datenbereinigung abgeschlossen in {processing_time.total_seconds():.1f} Sekunden!")

            return cleaned_file, report_file, quality_score

        except Exception as e:
            logger.error(f"❌ Fehler bei der konfigurierbaren Datenbereinigung: {e}")
            raise

def main():
    """Hauptfunktion mit konfigurationsbasierter Flexibilität"""

    # Erstelle Engine mit Standardkonfiguration
    engine = AdvancedConfigurableDataCleaningEngine()

    # Zeige verfügbare Dateien
    print("📋 Verfügbare Dateien:")
    for i, file in enumerate(engine.list_available_files(), 1):
        current_marker = " ← AKTUELL" if file == engine.current_file else ""
        print(f"  {i}. {file}{current_marker}")

    # Optional: Datei wechseln
    # engine.switch_input_file("Kunden9725.xlsx")

    # Führe Bereinigung durch
    cleaned_file, report_file, quality_score = engine.run_full_configurable_cleaning()

    print("\n" + "="*90)
    print("🎯 KONFIGURATIONSBASIERTE DATENBEREINIGUNG ABGESCHLOSSEN")
    print("="*90)
    print(f"📁 Bereinigte Datei: {cleaned_file}")
    print(f"📊 Quality-Score: {quality_score['overall_score']}/100")
    print(f"📋 Konfigurations-Report: {report_file}")
    print(f"⚙️ Konfiguration: {engine.config_path}")
    print(f"🔄 Datei-Wechsel: Einfach in config.yaml 'current_input_file' ändern")
    print("="*90)

if __name__ == "__main__":
    main()