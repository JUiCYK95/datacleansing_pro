#!/usr/bin/env python3
"""
Advanced Flexible Data Cleaning Engine
Hochpräzise automatische Spalten-Erkennung mit Content-basierter Validierung
"""

import pandas as pd
import re
import phonenumbers
from phonenumbers import NumberParseException, PhoneNumberFormat
import json
from datetime import datetime
from collections import Counter, defaultdict
from difflib import SequenceMatcher
from pathlib import Path
import logging
from typing import Dict, List, Optional, Tuple, Set
import numpy as np

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class AdvancedFlexibleDataCleaningEngine:
    """
    Erweiterte Flexible Data Cleaning Engine mit intelligenter Spalten-Erkennung
    """

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.df = None
        self.original_count = 0
        self.column_mapping = {}
        self.categorization_confidence = {}
        self.cleaning_stats = {
            'phone_fixes': 0,
            'mobile_fixes': 0,
            'email_fixes': 0,
            'address_fixes': 0,
            'duplicates_removed': 0,
            'quality_improvements': {},
            'categorization_warnings': [],
            'content_analysis': {}
        }

        # Erweiterte und präzisere Spalten-Erkennungsmuster
        self.column_patterns = {
            'phone_fields': {
                'private_phone': {
                    'include': [r'tel.*privat', r'telefon.*privat', r'phone.*private', r'private.*phone',
                               r'festnetz.*privat', r'privates.*telefon', r'^tel\.\s*privat$'],
                    'exclude': [r'email', r'mail', r'@', r'adresse', r'postleitzahl', r'plz']
                },
                'business_phone': {
                    'include': [r'tel.*geschäft', r'telefon.*geschäft', r'phone.*business', r'business.*phone',
                               r'geschäftlich.*telefon', r'office.*phone', r'work.*phone', r'telefon.*büro',
                               r'büro.*telefon', r'^telefon\s*geschäftlich$'],
                    'exclude': [r'email', r'mail', r'@', r'adresse', r'postleitzahl', r'plz', r'mobil']
                },
                'mobile_phone': {
                    'include': [r'mobil.*telefon', r'^handy$', r'mobile.*phone', r'cell.*phone',
                               r'smartphone', r'^mobil$', r'cellular', r'mobil-telefon'],
                    'exclude': [r'email', r'mail', r'@', r'adresse', r'geschäft']
                },
                'fax': {
                    'include': [r'^fax$', r'faxnummer', r'telefax', r'fax.*nummer'],
                    'exclude': [r'email', r'mail', r'telefon(?!fax)']
                }
            },
            'email_fields': {
                'include': [r'^e.*mail$', r'^email$', r'mail.*adresse', r'elektronische.*post', r'^e.*post$',
                           r'e-mail-adresse', r'email.*adresse'],
                'exclude': [r'postleitzahl', r'plz', r'telefon', r'phone', r'fax', r'strasse', r'straße']
            },
            'address_fields': {
                'street': {
                    'include': [r'^straße$', r'^strasse$', r'^street$', r'straßen.*name'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'postleitzahl', r'plz']
                },
                'house_number': {
                    'include': [r'^hausnummer$', r'^nr\.?$', r'^number$', r'haus.*nr', r'house.*number'],
                    'exclude': [r'telefon', r'phone', r'email', r'mail', r'kunde', r'id']
                },
                'postal_code': {
                    'include': [r'^plz$', r'postleitzahl(?!.*postfach)', r'postal.*code', r'zip.*code', r'^zip$'],
                    'exclude': [r'postfach', r'email', r'mail', r'telefon', r'phone']
                },
                'city': {
                    'include': [r'^ort$', r'^city$', r'^stadt$', r'gemeinde', r'municipality'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'plz', r'postleitzahl']
                },
                'country': {
                    'include': [r'^land$', r'^country$', r'^nation$'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone']
                }
            },
            'name_fields': {
                'first_name': {
                    'include': [r'^vorname$', r'first.*name', r'given.*name', r'christian.*name'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'firma', r'company']
                },
                'last_name': {
                    'include': [r'^nachname$', r'familienname', r'last.*name', r'^surname$', r'family.*name'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone', r'firma', r'company']
                },
                'title': {
                    'include': [r'^titel$', r'^title$', r'anrede', r'salutation'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone']
                },
                'company': {
                    'include': [r'^firma$', r'unternehmen', r'^company$', r'^business$', r'betrieb'],
                    'exclude': [r'email', r'mail', r'telefon', r'phone']
                }
            },
            'date_fields': {
                'include': [r'datum', r'date', r'geboren', r'birth', r'created', r'erstellt',
                           r'geändert', r'modified', r'updated', r'kontakt', r'besuch', r'seit'],
                'exclude': [r'email', r'mail', r'telefon', r'phone']
            },
            'id_fields': {
                'include': [r'^id$', r'nummer', r'number', r'kundennummer', r'customer.*id',
                           r'client.*id', r'referenz', r'reference', r'ust.*id'],
                'exclude': [r'telefon', r'phone', r'email', r'mail', r'hausnummer']
            }
        }

    def load_data(self) -> pd.DataFrame:
        """Lädt die Datei und analysiert die Spaltenstruktur"""
        logger.info(f"📂 Lade Datei: {self.file_path}")

        try:
            if self.file_path.endswith(('.xlsx', '.xls')):
                self.df = pd.read_excel(self.file_path)
            elif self.file_path.endswith('.csv'):
                self.df = self._load_csv_intelligently()
            else:
                raise ValueError(f"Nicht unterstütztes Dateiformat: {self.file_path}")

            self.original_count = len(self.df)
            logger.info(f"✅ {self.original_count:,} Datensätze mit {len(self.df.columns)} Spalten geladen")

            # Erweiterte Spaltenstruktur-Analyse
            self.analyze_column_structure_advanced()
            return self.df

        except Exception as e:
            logger.error(f"❌ Fehler beim Laden der Datei: {e}")
            raise

    def _load_csv_intelligently(self) -> pd.DataFrame:
        """Intelligentes CSV-Laden mit verschiedenen Encodings und Separatoren"""
        encodings = ['utf-8', 'latin1', 'cp1252', 'iso-8859-1']
        separators = [',', ';', '\t', '|']

        for encoding in encodings:
            for sep in separators:
                try:
                    df = pd.read_csv(self.file_path, encoding=encoding, sep=sep)
                    # Validiere ob das Parsing sinnvoll war
                    if len(df.columns) > 1 and len(df) > 0:
                        logger.info(f"✅ CSV geladen: Encoding={encoding}, Separator='{sep}'")
                        return df
                except:
                    continue

        raise ValueError("CSV konnte mit keiner Encoding/Separator-Kombination geladen werden")

    def analyze_column_structure_advanced(self) -> None:
        """Erweiterte Spalten-Analyse mit Content-basierter Validierung"""
        logger.info("🔍 Starte erweiterte Spaltenstruktur-Analyse...")

        self.column_mapping = {
            'phone_fields': {},
            'email_fields': [],
            'address_fields': {},
            'name_fields': {},
            'date_fields': [],
            'id_fields': [],
            'other_fields': []
        }

        self.categorization_confidence = {}

        # Phase 1: Pattern-basierte Vorkategorisierung
        preliminary_mapping = self._pattern_based_categorization()

        # Phase 2: Content-basierte Validierung
        validated_mapping = self._content_based_validation(preliminary_mapping)

        # Phase 3: Konflikt-Auflösung
        self.column_mapping = self._resolve_conflicts(validated_mapping)

        # Phase 4: Qualitätssicherung
        self._validate_final_categorization()

        # Ergebnisse ausgeben
        self._log_advanced_column_mapping()

    def _pattern_based_categorization(self) -> Dict:
        """Pattern-basierte Vorkategorisierung mit Prioritäten"""
        logger.info("🔍 Phase 1: Pattern-basierte Vorkategorisierung...")

        preliminary_mapping = defaultdict(lambda: defaultdict(list))
        used_columns = set()

        # Prioritäts-Reihenfolge (hohe Priorität zuerst)
        priority_order = [
            ('id_fields', self.column_patterns['id_fields']),
            ('email_fields', self.column_patterns['email_fields']),
            ('phone_fields', self.column_patterns['phone_fields']),
            ('address_fields', self.column_patterns['address_fields']),
            ('name_fields', self.column_patterns['name_fields']),
            ('date_fields', self.column_patterns['date_fields'])
        ]

        for column in self.df.columns:
            column_lower = str(column).lower().strip()
            best_match = None
            best_confidence = 0

            for category_name, category_patterns in priority_order:
                if column in used_columns:
                    continue

                match_result = self._advanced_pattern_match(column_lower, category_patterns)
                if match_result['confidence'] > best_confidence:
                    best_match = (category_name, match_result['subcategory'], match_result['confidence'])
                    best_confidence = match_result['confidence']

            if best_match and best_confidence > 0.7:  # Mindest-Confidence
                category, subcategory, confidence = best_match
                if subcategory:
                    preliminary_mapping[category][subcategory].append(column)
                else:
                    preliminary_mapping[category]['default'].append(column)
                used_columns.add(column)
            else:
                preliminary_mapping['other_fields']['default'].append(column)

        return dict(preliminary_mapping)

    def _advanced_pattern_match(self, column_lower: str, patterns: Dict) -> Dict:
        """Erweiterte Pattern-Matching mit Include/Exclude-Logik"""

        if isinstance(patterns, dict) and 'include' in patterns:
            # Einfache Struktur (z.B. email_fields, date_fields, id_fields)
            include_score = self._calculate_pattern_score(column_lower, patterns['include'])
            exclude_score = self._calculate_pattern_score(column_lower, patterns.get('exclude', []))

            confidence = max(0, include_score - exclude_score * 2)  # Exclude hat doppelte Gewichtung
            return {'confidence': confidence, 'subcategory': None}

        elif isinstance(patterns, dict):
            # Verschachtelte Struktur (z.B. phone_fields, address_fields, name_fields)
            best_subcategory = None
            best_confidence = 0

            for subcategory, subpatterns in patterns.items():
                if isinstance(subpatterns, dict) and 'include' in subpatterns:
                    include_score = self._calculate_pattern_score(column_lower, subpatterns['include'])
                    exclude_score = self._calculate_pattern_score(column_lower, subpatterns.get('exclude', []))

                    confidence = max(0, include_score - exclude_score * 2)

                    if confidence > best_confidence:
                        best_confidence = confidence
                        best_subcategory = subcategory

            return {'confidence': best_confidence, 'subcategory': best_subcategory}

        return {'confidence': 0, 'subcategory': None}

    def _calculate_pattern_score(self, text: str, patterns: List[str]) -> float:
        """Berechnet Pattern-Score mit gewichteten Matches"""
        if not patterns:
            return 0

        scores = []
        for pattern in patterns:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                # Exakte Matches bekommen höhere Scores
                if match.group() == text:
                    scores.append(1.0)
                else:
                    # Partieller Match, gewichtet nach Länge des Matches
                    match_ratio = len(match.group()) / len(text)
                    scores.append(match_ratio * 0.8)

        return max(scores) if scores else 0

    def _content_based_validation(self, preliminary_mapping: Dict) -> Dict:
        """Content-basierte Validierung der Kategorisierung"""
        logger.info("🔍 Phase 2: Content-basierte Validierung...")

        validated_mapping = {}

        for category, subcategories in preliminary_mapping.items():
            validated_mapping[category] = {}

            for subcategory, columns in subcategories.items():
                validated_columns = []

                for column in columns:
                    confidence = self._analyze_column_content(column, category, subcategory)

                    self.categorization_confidence[column] = {
                        'category': category,
                        'subcategory': subcategory,
                        'pattern_confidence': 0.8,  # Dummy-Wert, bereits durch Pattern validiert
                        'content_confidence': confidence,
                        'overall_confidence': confidence
                    }

                    # Spezielle Behandlung für exakte Spalten-Namen (Override Content-Validierung)
                    exact_match_override = self._check_exact_column_match(column, category)

                    # Mindest-Content-Confidence für Validierung (mit Override)
                    if confidence > 0.3 or exact_match_override:  # 30% Mindest-Confidence oder exakte Übereinstimmung
                        validated_columns.append(column)
                        if exact_match_override:
                            # Überschreibe niedrige Content-Confidence bei exakten Matches
                            self.categorization_confidence[column]['content_confidence'] = 0.9
                            self.categorization_confidence[column]['overall_confidence'] = 0.9
                    else:
                        # Bei niedriger Confidence als "other" kategorisieren
                        self.cleaning_stats['categorization_warnings'].append({
                            'column': column,
                            'issue': f'Niedrige Content-Confidence ({confidence:.2f}) für Kategorie {category}',
                            'action': 'Moved to other_fields'
                        })

                if validated_columns:
                    validated_mapping[category][subcategory] = validated_columns

        return validated_mapping

    def _check_exact_column_match(self, column: str, category: str) -> bool:
        """Prüft ob ein Spaltenname exakt zu bekannten Standard-Namen passt"""
        exact_matches = {
            'phone_fields': ['Telefon', 'Mobiltelefon', 'Fax', 'Handy'],
            'email_fields': ['eMail', 'Email', 'E-Mail'],
            'address_fields': ['Straße', 'Strasse', 'PLZ', 'Ort', 'Land'],
            'name_fields': ['Vorname', 'Nachname', 'Anrede', 'Titel'],
            'date_fields': ['Geburtstag', 'Geburtsdatum'],
            'id_fields': ['Kundennummer', 'ID', 'Nr']
        }

        if category in exact_matches:
            return column in exact_matches[category]

        return False

    def _analyze_column_content(self, column: str, category: str, subcategory: str) -> float:
        """Analysiert den Spalten-Inhalt zur Validierung der Kategorisierung"""

        if column not in self.df.columns:
            return 0

        # Sample nehmen für Performance
        sample_size = min(200, len(self.df))
        sample = self.df[column].dropna().head(sample_size)

        if len(sample) == 0:
            return 0.1  # Leere Spalten bekommen minimale Confidence

        # Content-Analyse je nach Kategorie
        if category == 'phone_fields':
            return self._analyze_phone_content(sample)
        elif category == 'email_fields':
            return self._analyze_email_content(sample)
        elif category == 'address_fields':
            return self._analyze_address_content(sample, subcategory)
        elif category == 'name_fields':
            return self._analyze_name_content(sample, subcategory)
        elif category == 'date_fields':
            return self._analyze_date_content(sample)
        elif category == 'id_fields':
            return self._analyze_id_content(sample)
        else:
            return 0.5  # Neutrale Confidence für andere Felder

    def _analyze_phone_content(self, sample: pd.Series) -> float:
        """Analysiert ob Spalten-Inhalt tatsächlich Telefonnummern enthält"""
        phone_like_count = 0
        total_count = len(sample)

        phone_patterns = [
            r'^\+?[\d\s\-\(\)\/]{7,}$',      # Grundlegendes Telefonnummer-Muster
            r'^0\d{2,4}[\-\/\s]?\d{4,}$',   # Deutsche Formate
            r'^\+49\s?\d',                   # Deutsche internationale Nummer
            r'^\(\d{3,4}\)\s?\d',            # Mit Klammern
            r'^\d{4,5}\s?\d{4,8}$'           # Einfaches Format
        ]

        for value in sample:
            value_str = str(value).strip()

            # Skip offensichtlich falsche Werte
            if len(value_str) < 5 or len(value_str) > 20:
                continue

            # Prüfe auf Telefonnummer-Muster
            for pattern in phone_patterns:
                if re.match(pattern, value_str):
                    phone_like_count += 1
                    break
            else:
                # Zusätzliche Heuristik: mindestens 60% Ziffern
                digits = sum(1 for c in value_str if c.isdigit())
                if digits >= len(value_str) * 0.6 and len(value_str) >= 7:
                    phone_like_count += 1

        confidence = phone_like_count / total_count

        # Speichere Analyse-Details
        self.cleaning_stats['content_analysis'][f'phone_analysis_{len(self.cleaning_stats["content_analysis"])}'] = {
            'total_samples': total_count,
            'phone_like': phone_like_count,
            'confidence': confidence
        }

        return confidence

    def _analyze_email_content(self, sample: pd.Series) -> float:
        """Analysiert ob Spalten-Inhalt tatsächlich E-Mail-Adressen enthält"""
        email_like_count = 0
        total_count = len(sample)

        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

        for value in sample:
            value_str = str(value).strip().lower()

            if '@' in value_str and '.' in value_str:
                if re.match(email_pattern, value_str):
                    email_like_count += 1

        confidence = email_like_count / total_count

        self.cleaning_stats['content_analysis'][f'email_analysis_{len(self.cleaning_stats["content_analysis"])}'] = {
            'total_samples': total_count,
            'email_like': email_like_count,
            'confidence': confidence
        }

        return confidence

    def _analyze_address_content(self, sample: pd.Series, subcategory: str) -> float:
        """Analysiert Adress-Felder basierend auf Subkategorie"""

        if subcategory == 'postal_code':
            return self._analyze_postal_code_content(sample)
        elif subcategory == 'city':
            return self._analyze_city_content(sample)
        elif subcategory == 'street':
            return self._analyze_street_content(sample)
        else:
            return 0.5  # Default für andere Adress-Felder

    def _analyze_postal_code_content(self, sample: pd.Series) -> float:
        """Analysiert PLZ-Inhalt"""
        plz_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            # Deutsche PLZ: 5 Ziffern
            if re.match(r'^\d{5}$', value_str):
                plz_like_count += 1
            # 4 Ziffern (könnte PLZ ohne führende 0 sein)
            elif re.match(r'^\d{4}$', value_str):
                plz_like_count += 0.8

        return plz_like_count / total_count

    def _analyze_city_content(self, sample: pd.Series) -> float:
        """Analysiert Stadt-Namen"""
        city_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            # Heuristiken für Städte:
            # - Enthält hauptsächlich Buchstaben
            # - Länge zwischen 2 und 50 Zeichen
            # - Kein @-Zeichen (keine E-Mail)
            # - Nicht nur Zahlen

            if (2 <= len(value_str) <= 50 and
                not '@' in value_str and
                not value_str.isdigit() and
                sum(1 for c in value_str if c.isalpha()) >= len(value_str) * 0.5):
                city_like_count += 1

        return city_like_count / total_count

    def _analyze_street_content(self, sample: pd.Series) -> float:
        """Analysiert Straßen-Namen"""
        street_like_count = 0
        total_count = len(sample)

        street_indicators = ['straße', 'strasse', 'str.', 'weg', 'platz', 'gasse', 'allee']

        for value in sample:
            value_str = str(value).strip().lower()

            # Heuristiken für Straßen:
            # - Enthält Straßen-Indikatoren
            # - Oder: Buchstaben + Zahlen (z.B. "Hauptstraße 15")
            # - Kein @-Zeichen

            has_street_indicator = any(indicator in value_str for indicator in street_indicators)
            has_mixed_content = (any(c.isalpha() for c in value_str) and
                               any(c.isdigit() for c in value_str))

            if (has_street_indicator or has_mixed_content) and '@' not in value_str:
                street_like_count += 1

        return street_like_count / total_count

    def _analyze_name_content(self, sample: pd.Series, subcategory: str) -> float:
        """Analysiert Namen-Inhalt"""
        name_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            # Heuristiken für Namen:
            # - Hauptsächlich Buchstaben
            # - Keine E-Mail-Zeichen
            # - Reasonable Länge (2-50 Zeichen)
            # - Keine Zahlen-Dominanz

            if (2 <= len(value_str) <= 50 and
                '@' not in value_str and
                not value_str.replace(' ', '').isdigit() and
                sum(1 for c in value_str if c.isalpha()) >= len(value_str.replace(' ', '')) * 0.7):
                name_like_count += 1

        return name_like_count / total_count

    def _analyze_date_content(self, sample: pd.Series) -> float:
        """Analysiert Datums-Inhalt"""
        date_like_count = 0
        total_count = len(sample)

        date_patterns = [
            r'\d{1,2}[\.\/\-]\d{1,2}[\.\/\-]\d{2,4}',  # DD.MM.YYYY
            r'\d{4}[\.\/\-]\d{1,2}[\.\/\-]\d{1,2}',    # YYYY-MM-DD
            r'\d{1,2}\.\d{1,2}\.\d{4}',                 # DD.MM.YYYY
        ]

        for value in sample:
            value_str = str(value).strip()

            for pattern in date_patterns:
                if re.search(pattern, value_str):
                    date_like_count += 1
                    break

        return date_like_count / total_count

    def _analyze_id_content(self, sample: pd.Series) -> float:
        """Analysiert ID-Inhalt"""
        id_like_count = 0
        total_count = len(sample)

        for value in sample:
            value_str = str(value).strip()

            # Heuristiken für IDs:
            # - Hauptsächlich Zahlen oder Alphanumerisch
            # - Keine Leerzeichen in der Mitte
            # - Reasonable Länge

            if (len(value_str) >= 3 and
                not '@' in value_str and
                (value_str.isdigit() or value_str.replace('-', '').replace('_', '').isalnum())):
                id_like_count += 1

        return id_like_count / total_count

    def _resolve_conflicts(self, validated_mapping: Dict) -> Dict:
        """Löst Konflikte zwischen Kategorisierungen auf"""
        logger.info("🔍 Phase 3: Konflikt-Auflösung...")

        final_mapping = {
            'phone_fields': {},
            'email_fields': [],
            'address_fields': {},
            'name_fields': {},
            'date_fields': [],
            'id_fields': [],
            'other_fields': []
        }

        # Alle Spalten sammeln die mehrfach kategorisiert wurden
        all_categorized_columns = set()
        column_categories = defaultdict(list)

        for category, subcategories in validated_mapping.items():
            if category == 'other_fields':
                continue

            for subcategory, columns in subcategories.items():
                for column in columns:
                    if column in all_categorized_columns:
                        column_categories[column].append((category, subcategory))
                    else:
                        all_categorized_columns.add(column)
                        column_categories[column].append((category, subcategory))

        # Löse Konflikte basierend auf Confidence-Scores
        for column, categories in column_categories.items():
            if len(categories) == 1:
                # Kein Konflikt
                category, subcategory = categories[0]
                self._add_to_final_mapping(final_mapping, column, category, subcategory)
            else:
                # Konflikt: Wähle beste Confidence
                best_category = None
                best_subcategory = None
                best_confidence = 0

                for category, subcategory in categories:
                    confidence = self.categorization_confidence.get(column, {}).get('overall_confidence', 0)
                    if confidence > best_confidence:
                        best_confidence = confidence
                        best_category = category
                        best_subcategory = subcategory

                if best_category:
                    self._add_to_final_mapping(final_mapping, column, best_category, best_subcategory)

                    self.cleaning_stats['categorization_warnings'].append({
                        'column': column,
                        'issue': f'Konflikt zwischen {categories}',
                        'action': f'Gewählt: {best_category}/{best_subcategory} (Confidence: {best_confidence:.2f})'
                    })

        # Füge nicht kategorisierte Spalten zu other_fields hinzu
        for column in self.df.columns:
            if column not in all_categorized_columns:
                final_mapping['other_fields'].append(column)

        return final_mapping

    def _add_to_final_mapping(self, final_mapping: Dict, column: str, category: str, subcategory: str) -> None:
        """Fügt eine Spalte zur finalen Zuordnung hinzu"""
        if category in ['phone_fields', 'address_fields', 'name_fields']:
            final_mapping[category][subcategory] = column
        elif category in ['email_fields', 'date_fields', 'id_fields']:
            final_mapping[category].append(column)

    def _validate_final_categorization(self) -> None:
        """Führt finale Qualitätssicherung der Kategorisierung durch"""
        logger.info("🔍 Phase 4: Finale Qualitätssicherung...")

        validation_warnings = []

        # Prüfe E-Mail-Felder
        for email_field in self.column_mapping['email_fields']:
            sample = self.df[email_field].dropna().head(50)
            actual_emails = sum(1 for x in sample if '@' in str(x))

            if len(sample) > 0 and actual_emails / len(sample) < 0.1:
                validation_warnings.append({
                    'field': email_field,
                    'category': 'email_fields',
                    'issue': f'Nur {actual_emails}/{len(sample)} Einträge sind E-Mails',
                    'severity': 'HIGH'
                })

        # Prüfe Telefon-Felder
        for phone_type, phone_field in self.column_mapping['phone_fields'].items():
            if phone_field:
                sample = self.df[phone_field].dropna().head(50)
                actual_phones = sum(1 for x in sample if re.search(r'[\d\+\-\(\)\s]{5,}', str(x)))

                if len(sample) > 0 and actual_phones / len(sample) < 0.2:
                    validation_warnings.append({
                        'field': phone_field,
                        'category': f'phone_fields/{phone_type}',
                        'issue': f'Nur {actual_phones}/{len(sample)} Einträge sehen wie Telefonnummern aus',
                        'severity': 'MEDIUM'
                    })

        # Warnung ausgeben
        if validation_warnings:
            logger.warning(f"⚠️ {len(validation_warnings)} Kategorisierungs-Warnungen gefunden:")
            for warning in validation_warnings:
                logger.warning(f"   - {warning['field']}: {warning['issue']}")

        self.cleaning_stats['categorization_warnings'].extend(validation_warnings)

    def _log_advanced_column_mapping(self) -> None:
        """Gibt die erweiterte Spalten-Zuordnung aus"""
        logger.info("📋 Finale Spaltenstruktur (mit Confidence-Scores):")

        for category, fields in self.column_mapping.items():
            if fields:
                logger.info(f"   {category}:")

                if isinstance(fields, dict):
                    for field_type, column_name in fields.items():
                        if column_name:
                            confidence = self.categorization_confidence.get(column_name, {}).get('overall_confidence', 0)
                            logger.info(f"     - {field_type}: '{column_name}' (Confidence: {confidence:.2f})")
                elif isinstance(fields, list):
                    for column_name in fields:
                        confidence = self.categorization_confidence.get(column_name, {}).get('overall_confidence', 0)
                        logger.info(f"     - '{column_name}' (Confidence: {confidence:.2f})")

        logger.info(f"📊 Kategorisierungs-Statistiken:")
        logger.info(f"   - Warnungen: {len(self.cleaning_stats['categorization_warnings'])}")
        logger.info(f"   - Analysierte Spalten: {len(self.categorization_confidence)}")

    def clean_phone_numbers_advanced(self) -> pd.DataFrame:
        """Erweiterte Telefonnummer-Bereinigung mit deutschen Formaten"""
        logger.info("📞 Starte erweiterte Telefonnummer-Bereinigung...")

        phone_fields = self.column_mapping['phone_fields']
        if not phone_fields:
            logger.warning("⚠️ Keine Telefonnummer-Felder erkannt")
            return self.df

        def normalize_phone_advanced(phone_str, is_mobile_expected=False):
            """Erweiterte Telefonnummer-Normalisierung"""
            if pd.isna(phone_str) or str(phone_str).strip() in ['', ' ', 'nan', 'None', '0']:
                return {'formatted': '', 'is_mobile': False, 'is_valid': False}

            phone_str = str(phone_str).strip()
            original_phone = phone_str

            # Erweiterte Bereinigung für deutsche Formate
            phone_str = self._preprocess_german_phone(phone_str)

            if not phone_str:
                return {'formatted': '', 'is_mobile': False, 'is_valid': False, 'original': original_phone}

            try:
                # Deutsche Nummer formatieren
                if not phone_str.startswith('+'):
                    if phone_str.startswith('0'):
                        phone_str = '+49' + phone_str[1:]
                    elif phone_str.startswith('49'):
                        phone_str = '+' + phone_str
                    else:
                        phone_str = '+49' + phone_str

                parsed = phonenumbers.parse(phone_str, 'DE')

                if phonenumbers.is_valid_number(parsed):
                    number_type = phonenumbers.number_type(parsed)
                    actual_is_mobile = number_type == phonenumbers.PhoneNumberType.MOBILE

                    formatted = phonenumbers.format_number(parsed, PhoneNumberFormat.INTERNATIONAL)

                    return {
                        'formatted': formatted,
                        'is_mobile': actual_is_mobile,
                        'is_valid': True,
                        'number_type': str(number_type),
                        'original': original_phone
                    }
                else:
                    return {'formatted': '', 'is_mobile': False, 'is_valid': False, 'original': original_phone}

            except NumberParseException as e:
                return {'formatted': '', 'is_mobile': False, 'is_valid': False, 'error': str(e), 'original': original_phone}

        # Verarbeite alle erkannten Telefon-Felder
        phone_stats = {}

        for phone_type, column_name in phone_fields.items():
            if column_name and column_name in self.df.columns:
                logger.info(f"🔧 Bereinige {phone_type}: '{column_name}'")

                is_mobile_expected = 'mobile' in phone_type.lower()
                results = self.df[column_name].apply(lambda x: normalize_phone_advanced(x, is_mobile_expected))

                # Sammle Statistiken
                valid_count = 0
                mobile_count = 0
                landline_count = 0

                # Wende Ergebnisse an
                for idx in range(len(self.df)):
                    result = results.iloc[idx]
                    if isinstance(result, dict) and result['is_valid']:
                        self.df.at[idx, column_name] = result['formatted']
                        valid_count += 1

                        if result['is_mobile']:
                            mobile_count += 1
                            self.cleaning_stats['mobile_fixes'] += 1
                        else:
                            landline_count += 1
                            self.cleaning_stats['phone_fixes'] += 1
                    else:
                        self.df.at[idx, column_name] = ''

                phone_stats[phone_type] = {
                    'column': column_name,
                    'valid_total': valid_count,
                    'mobile_count': mobile_count,
                    'landline_count': landline_count
                }

                logger.info(f"   ✅ {phone_type}: {valid_count:,} gültige Nummern ({mobile_count} mobil, {landline_count} Festnetz)")

        # Gesamtstatistik
        total_valid = sum(stats['valid_total'] for stats in phone_stats.values())
        total_mobile = sum(stats['mobile_count'] for stats in phone_stats.values())
        total_landline = sum(stats['landline_count'] for stats in phone_stats.values())

        self.cleaning_stats['phone_statistics'] = phone_stats
        logger.info(f"✅ Telefonnummern bereinigt: {total_valid:,} gültige Nummern insgesamt ({total_mobile} mobil, {total_landline} Festnetz)")

        return self.df

    def _preprocess_german_phone(self, phone_str: str) -> str:
        """Vorverarbeitung für deutsche Telefonnummer-Formate"""

        # Entferne häufige Störzeichen, aber behalte strukturelle Zeichen
        phone_str = re.sub(r'[^\d\+\-\(\)\s\/]', '', phone_str)

        # Häufige deutsche Formate normalisieren:

        # Format: 030/12345678 -> 03012345678
        phone_str = re.sub(r'^(0\d{2,4})\/(\d+)$', r'\1\2', phone_str)

        # Format: (030) 12345678 -> 03012345678
        phone_str = re.sub(r'^\((\d{3,4})\)\s*(\d+)$', r'\1\2', phone_str)

        # Format: 030-12345678 -> 03012345678
        phone_str = re.sub(r'^(\d+)-(\d+)$', r'\1\2', phone_str)

        # Format: 030 12345678 -> 03012345678 (nur ein Leerzeichen)
        if phone_str.count(' ') == 1:
            phone_str = phone_str.replace(' ', '')

        # Entferne führende/nachgestellte Leerzeichen
        phone_str = phone_str.strip()

        # Validiere minimale Länge für deutsche Nummern
        digits_only = re.sub(r'[^\d]', '', phone_str)
        if len(digits_only) < 6 or len(digits_only) > 12:
            return ''

        return phone_str

    def clean_email_addresses_advanced(self) -> pd.DataFrame:
        """Erweiterte E-Mail-Bereinigung"""
        logger.info("📧 Starte erweiterte E-Mail-Bereinigung...")

        email_fields = self.column_mapping['email_fields']
        if not email_fields:
            logger.warning("⚠️ Keine E-Mail-Felder erkannt")
            return self.df

        def clean_email_advanced(email_str):
            """Erweiterte E-Mail-Bereinigung"""
            if pd.isna(email_str) or str(email_str).strip() == '':
                return ''

            email_str = str(email_str).strip().lower()

            # Entferne häufige Probleme
            email_str = re.sub(r'^[^\w@]+|[^\w@.]+$', '', email_str)  # Führende/nachstehende Sonderzeichen
            email_str = re.sub(r'\s+', '', email_str)  # Leerzeichen entfernen

            # Erweiterte E-Mail-Validierung
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

            if re.match(email_pattern, email_str):
                # Zusätzliche Plausibilitätschecks
                local_part, domain = email_str.split('@')

                # Lokaler Teil sollte nicht zu lang sein
                if len(local_part) > 64:
                    return ''

                # Domain sollte mindestens einen Punkt haben
                if '.' not in domain:
                    return ''

                # Domain sollte nicht mit Punkt beginnen/enden
                if domain.startswith('.') or domain.endswith('.'):
                    return ''

                return email_str
            else:
                return ''

        email_stats = {}

        for email_field in email_fields:
            if email_field in self.df.columns:
                logger.info(f"🔧 Bereinige E-Mail-Feld: '{email_field}'")

                original_count = len(self.df[email_field].dropna())
                self.df[email_field] = self.df[email_field].apply(clean_email_advanced)
                valid_count = sum(1 for x in self.df[email_field] if str(x).strip() != '')

                email_stats[email_field] = {
                    'original_count': original_count,
                    'valid_count': valid_count,
                    'success_rate': (valid_count / original_count * 100) if original_count > 0 else 0
                }

                self.cleaning_stats['email_fixes'] += valid_count
                logger.info(f"   ✅ {valid_count:,} gültige E-Mail-Adressen ({email_stats[email_field]['success_rate']:.1f}% Success Rate)")

        self.cleaning_stats['email_statistics'] = email_stats
        return self.df

    def clean_addresses_advanced(self) -> pd.DataFrame:
        """Erweiterte Adress-Bereinigung"""
        logger.info("🏠 Starte erweiterte Adress-Bereinigung...")

        address_fields = self.column_mapping['address_fields']
        if not address_fields:
            logger.warning("⚠️ Keine Adress-Felder erkannt")
            return self.df

        address_stats = {}

        # Deutsche PLZ-Muster (erweitert)
        def clean_plz_advanced(plz):
            """Erweiterte PLZ-Bereinigung"""
            if pd.isna(plz):
                return ''

            plz_str = str(plz).strip()

            # Entferne alles außer Zahlen
            plz_clean = re.sub(r'[^\d]', '', plz_str)

            if len(plz_clean) == 5 and plz_clean.isdigit():
                # Deutsche PLZ Validierung (grober Check)
                first_digit = int(plz_clean[0])
                if 0 <= first_digit <= 9:  # Deutsche PLZ beginnen mit 0-9
                    return plz_clean
            elif len(plz_clean) == 4 and plz_clean.isdigit():
                # Führende 0 hinzufügen
                return '0' + plz_clean

            return ''

        def clean_text_field_advanced(text):
            """Erweiterte Textfeld-Bereinigung"""
            if pd.isna(text):
                return ''

            text_str = str(text).strip()

            # Entferne führende/nachstehende Sonderzeichen
            text_str = re.sub(r'^[^\w\s]+|[^\w\s]+$', '', text_str)

            # Title Case, aber mit deutschen Besonderheiten
            if text_str:
                # Spezielle Behandlung für deutsche Wörter
                words = text_str.split()
                capitalized_words = []

                for word in words:
                    # Kleine Wörter in Städtenamen (von, am, an, etc.) klein lassen
                    if word.lower() in ['von', 'am', 'an', 'der', 'die', 'das', 'im', 'in', 'auf']:
                        capitalized_words.append(word.lower())
                    else:
                        capitalized_words.append(word.capitalize())

                return ' '.join(capitalized_words)

            return ''

        # PLZ bereinigen
        if 'postal_code' in address_fields and address_fields['postal_code']:
            plz_field = address_fields['postal_code']
            logger.info(f"🔧 Bereinige PLZ: '{plz_field}'")

            original_plz = self.df[plz_field].copy()
            self.df[plz_field] = original_plz.apply(clean_plz_advanced)

            valid_plz = sum(1 for x in self.df[plz_field] if str(x).strip() != '')
            address_stats['postal_code'] = {
                'field': plz_field,
                'valid_count': valid_plz,
                'total_count': len(original_plz.dropna())
            }

        # Stadt bereinigen
        if 'city' in address_fields and address_fields['city']:
            city_field = address_fields['city']
            logger.info(f"🔧 Bereinige Stadt: '{city_field}'")

            original_city = self.df[city_field].copy()
            self.df[city_field] = original_city.apply(clean_text_field_advanced)

            valid_city = sum(1 for x in self.df[city_field] if str(x).strip() != '')
            address_stats['city'] = {
                'field': city_field,
                'valid_count': valid_city,
                'total_count': len(original_city.dropna())
            }

        # Straße bereinigen
        if 'street' in address_fields and address_fields['street']:
            street_field = address_fields['street']
            logger.info(f"🔧 Bereinige Straße: '{street_field}'")

            original_street = self.df[street_field].copy()
            self.df[street_field] = original_street.apply(clean_text_field_advanced)

            valid_street = sum(1 for x in self.df[street_field] if str(x).strip() != '')
            address_stats['street'] = {
                'field': street_field,
                'valid_count': valid_street,
                'total_count': len(original_street.dropna())
            }

        # Vollständige Adressen zählen
        complete_addresses = self._count_complete_addresses_advanced()
        address_stats['complete_addresses'] = complete_addresses

        self.cleaning_stats['address_fixes'] = complete_addresses
        self.cleaning_stats['address_statistics'] = address_stats

        logger.info(f"✅ Adressen bereinigt: {complete_addresses:,} vollständige Adressdaten")

        return self.df

    def _count_complete_addresses_advanced(self) -> int:
        """Erweiterte Zählung vollständiger Adressen"""
        address_fields = self.column_mapping['address_fields']

        required_fields = []
        if address_fields.get('postal_code'):
            required_fields.append(address_fields['postal_code'])
        if address_fields.get('city'):
            required_fields.append(address_fields['city'])

        if not required_fields:
            return 0

        complete_count = 0
        for _, row in self.df.iterrows():
            is_complete = all(
                str(row[field]).strip() not in ['', 'nan', 'None']
                for field in required_fields
            )
            if is_complete:
                complete_count += 1

        return complete_count

    def remove_duplicates_intelligent(self) -> pd.DataFrame:
        """Intelligente Duplikat-Entfernung mit erweiterten Algorithmen"""
        logger.info("🔄 Starte intelligente Duplikat-Entfernung...")

        original_count = len(self.df)

        # Erstelle intelligente Schlüsselfelder
        key_fields = self._create_intelligent_key_fields()

        if not key_fields:
            logger.warning("⚠️ Keine geeigneten Felder für Duplikat-Erkennung gefunden")
            return self.df

        logger.info(f"🔍 Verwende intelligente Schlüsselfelder: {key_fields}")

        # Phase 1: Exakte Duplikate
        logger.info("🔍 Phase 1: Exakte Duplikate entfernen...")
        self.df = self.df.drop_duplicates(subset=key_fields, keep='first')
        exact_removed = original_count - len(self.df)

        # Phase 2: Ähnliche Duplikate mit verbessertem Algorithmus
        logger.info("🔍 Phase 2: Ähnliche Duplikate mit verbessertem Algorithmus...")
        fuzzy_removed = self._remove_fuzzy_duplicates_advanced(key_fields)

        # Phase 3: Domain-spezifische Duplikate (bei E-Mail-basierten Duplikaten)
        logger.info("🔍 Phase 3: Domain-spezifische Duplikat-Analyse...")
        domain_removed = self._remove_domain_duplicates()

        total_removed = exact_removed + fuzzy_removed + domain_removed
        self.cleaning_stats['duplicates_removed'] = total_removed

        duplicate_stats = {
            'exact_removed': exact_removed,
            'fuzzy_removed': fuzzy_removed,
            'domain_removed': domain_removed,
            'total_removed': total_removed,
            'final_count': len(self.df)
        }

        self.cleaning_stats['duplicate_statistics'] = duplicate_stats

        logger.info(f"✅ Intelligente Duplikat-Entfernung: {exact_removed:,} exakte + {fuzzy_removed:,} ähnliche + {domain_removed:,} domain-spezifische = {total_removed:,} gesamt")
        logger.info(f"📊 Verbleibende Datensätze: {len(self.df):,}")

        return self.df

    def _create_intelligent_key_fields(self) -> List[str]:
        """Erstellt intelligente Schlüsselfelder basierend auf verfügbaren Daten"""
        key_fields = []

        # Priorität 1: Namen-Felder
        name_fields = self.column_mapping['name_fields']
        if name_fields.get('first_name'):
            key_fields.append(name_fields['first_name'])
        if name_fields.get('last_name'):
            key_fields.append(name_fields['last_name'])

        # Priorität 2: Eindeutige Kontaktdaten
        # E-Mail (höchste Priorität bei Kontaktdaten)
        if self.column_mapping['email_fields']:
            primary_email = self.column_mapping['email_fields'][0]  # Nehme die erste/beste E-Mail
            key_fields.append(primary_email)

        # Priorität 3: Telefonnummern (nur wenn keine E-Mail verfügbar)
        if not self.column_mapping['email_fields']:
            phone_fields = self.column_mapping['phone_fields']
            for phone_priority in ['private_phone', 'business_phone', 'mobile_phone']:
                if phone_fields.get(phone_priority):
                    key_fields.append(phone_fields[phone_priority])
                    break  # Nur eine Telefonnummer als Schlüssel

        # Priorität 4: Adresse (nur wenn Namen UND Kontakt verfügbar)
        if len(key_fields) >= 2:  # Mindestens Name + Kontakt
            address_fields = self.column_mapping['address_fields']
            if address_fields.get('postal_code'):
                key_fields.append(address_fields['postal_code'])

        # Filtere nur existierende Spalten
        valid_key_fields = [field for field in key_fields if field in self.df.columns]

        return valid_key_fields

    def _remove_fuzzy_duplicates_advanced(self, key_fields: List[str]) -> int:
        """Erweiterte Fuzzy-Duplikat-Entfernung"""
        to_remove = set()

        # Fokussiere auf Kontaktfelder für Fuzzy Matching
        contact_fields = []

        # E-Mail-Felder hinzufügen
        contact_fields.extend(self.column_mapping['email_fields'])

        # Telefon-Felder hinzufügen
        for phone_field in self.column_mapping['phone_fields'].values():
            if phone_field:
                contact_fields.append(phone_field)

        contact_fields = [field for field in contact_fields if field in self.df.columns]

        def advanced_similarity(a, b, threshold=0.90):
            """Erweiterte Ähnlichkeitsmessung"""
            if pd.isna(a) or pd.isna(b):
                return False

            a_str = str(a).lower().strip()
            b_str = str(b).lower().strip()

            # Exakte Übereinstimmung
            if a_str == b_str:
                return True

            # Levenshtein-Ähnlichkeit
            similarity = SequenceMatcher(None, a_str, b_str).ratio()
            return similarity > threshold

        # Gruppiere nach Kontaktfeldern und prüfe auf ähnliche Namen
        for contact_field in contact_fields:
            unique_values = self.df[contact_field].dropna().unique()

            for contact_value in unique_values:
                if str(contact_value).strip() == '':
                    continue

                same_contact_group = self.df[self.df[contact_field] == contact_value]
                if len(same_contact_group) <= 1:
                    continue

                # Prüfe auf ähnliche Namen innerhalb der Kontakt-Gruppe
                name_fields = self.column_mapping['name_fields']
                if name_fields.get('first_name') and name_fields.get('last_name'):
                    first_name_field = name_fields['first_name']
                    last_name_field = name_fields['last_name']

                    rows_list = list(same_contact_group.iterrows())
                    for i, (idx1, row1) in enumerate(rows_list):
                        for j, (idx2, row2) in enumerate(rows_list[i+1:], start=i+1):
                            if idx1 in to_remove or idx2 in to_remove:
                                continue

                            # Vergleiche Namen
                            first1 = str(row1.get(first_name_field, ''))
                            last1 = str(row1.get(last_name_field, ''))
                            first2 = str(row2.get(first_name_field, ''))
                            last2 = str(row2.get(last_name_field, ''))

                            name1 = f"{first1} {last1}".strip()
                            name2 = f"{first2} {last2}".strip()

                            if advanced_similarity(name1, name2, 0.85):
                                # Entscheide welchen Datensatz zu behalten
                                score1 = self._calculate_record_completeness_score(row1)
                                score2 = self._calculate_record_completeness_score(row2)

                                if score1 >= score2:
                                    to_remove.add(idx2)
                                else:
                                    to_remove.add(idx1)

        # Entferne ähnliche Duplikate
        if to_remove:
            self.df = self.df.drop(index=list(to_remove)).reset_index(drop=True)

        return len(to_remove)

    def _calculate_record_completeness_score(self, row: pd.Series) -> float:
        """Berechnet einen Vollständigkeits-Score für einen Datensatz"""
        total_fields = len(row)
        filled_fields = sum(1 for val in row if pd.notna(val) and str(val).strip() not in ['', 'nan', 'None'])

        base_score = filled_fields / total_fields

        # Bonus für wichtige Felder
        bonus = 0

        # E-Mail-Bonus
        for email_field in self.column_mapping['email_fields']:
            if email_field in row.index and '@' in str(row[email_field]):
                bonus += 0.1

        # Telefon-Bonus
        for phone_field in self.column_mapping['phone_fields'].values():
            if phone_field and phone_field in row.index and str(row[phone_field]).strip():
                bonus += 0.05

        # Adress-Bonus
        address_fields = self.column_mapping['address_fields']
        if (address_fields.get('postal_code') and
            address_fields['postal_code'] in row.index and
            str(row[address_fields['postal_code']]).strip()):
            bonus += 0.05

        return min(1.0, base_score + bonus)

    def _remove_domain_duplicates(self) -> int:
        """Entfernt domain-spezifische Duplikate (z.B. private vs. geschäftliche E-Mails)"""
        to_remove = set()

        email_fields = self.column_mapping['email_fields']
        if len(email_fields) < 2:
            return 0  # Brauche mindestens 2 E-Mail-Felder

        name_fields = self.column_mapping['name_fields']
        if not (name_fields.get('first_name') and name_fields.get('last_name')):
            return 0  # Brauche Namen für Vergleich

        first_name_field = name_fields['first_name']
        last_name_field = name_fields['last_name']

        # Erstelle Name-zu-Emails Mapping
        name_email_map = defaultdict(list)

        for idx, row in self.df.iterrows():
            first_name = str(row.get(first_name_field, '')).strip()
            last_name = str(row.get(last_name_field, '')).strip()

            if first_name and last_name:
                full_name = f"{first_name} {last_name}".lower()

                # Sammle alle E-Mails für diese Person
                emails = []
                for email_field in email_fields:
                    email = str(row.get(email_field, '')).strip()
                    if email and '@' in email:
                        emails.append(email.lower())

                if emails:
                    name_email_map[full_name].append({
                        'index': idx,
                        'emails': emails,
                        'row': row
                    })

        # Finde Duplikate basierend auf Namen mit verschiedenen E-Mails
        for full_name, records in name_email_map.items():
            if len(records) <= 1:
                continue

            # Prüfe ob es sich um die gleiche Person mit verschiedenen E-Mails handelt
            all_emails = set()
            for record in records:
                all_emails.update(record['emails'])

            # Wenn alle E-Mails zu ähnlichen Domains gehören, könnte es sich um Duplikate handeln
            domains = [email.split('@')[1] for email in all_emails]

            # Einfache Heuristik: Gleicher Domänen-Stamm (z.B. gmail.com vs. googlemail.com)
            domain_groups = defaultdict(list)
            for i, record in enumerate(records):
                primary_domain = record['emails'][0].split('@')[1] if record['emails'] else 'unknown'
                domain_groups[primary_domain].append((i, record))

            # Behalte nur den vollständigsten Datensatz pro Domain-Gruppe
            for domain, domain_records in domain_groups.items():
                if len(domain_records) > 1:
                    best_record = max(domain_records, key=lambda x: self._calculate_record_completeness_score(x[1]['row']))

                    for i, record in domain_records:
                        if record['index'] != best_record[1]['index']:
                            to_remove.add(record['index'])

        # Entferne Domain-Duplikate
        if to_remove:
            self.df = self.df.drop(index=list(to_remove)).reset_index(drop=True)

        return len(to_remove)

    def calculate_advanced_quality_score(self) -> Dict:
        """Berechnet einen erweiterten Datenqualitäts-Score mit detaillierter Analyse"""
        logger.info("📊 Berechne erweiterten Datenqualitäts-Score...")

        total_records = len(self.df)
        total_fields = len(self.df.columns)

        if total_records == 0:
            return {'overall_score': 0, 'total_records': 0}

        # Erweiterte Qualitäts-Metriken
        metrics = {}

        # 1. Basis-Vollständigkeit
        metrics['completeness'] = (self.df.count().sum() / (total_records * total_fields)) * 100

        # 2. Kategorien-spezifische Qualität
        metrics['phone_validity'] = self._calculate_phone_validity_advanced()
        metrics['email_validity'] = self._calculate_email_validity_advanced()
        metrics['address_completeness'] = self._calculate_address_completeness_advanced()
        metrics['name_completeness'] = self._calculate_name_completeness_advanced()
        metrics['data_consistency'] = self._calculate_data_consistency()

        # 3. Erweiterte Metriken
        metrics['categorization_accuracy'] = self._calculate_categorization_accuracy()
        metrics['duplicate_cleanliness'] = self._calculate_duplicate_cleanliness()

        # 4. Gewichteter Gesamt-Score (erweiterte Gewichtung)
        weights = {
            'completeness': 0.20,
            'phone_validity': 0.15,
            'email_validity': 0.15,
            'address_completeness': 0.15,
            'name_completeness': 0.10,
            'data_consistency': 0.10,
            'categorization_accuracy': 0.10,
            'duplicate_cleanliness': 0.05
        }

        overall_score = sum(
            metrics[metric] * weight
            for metric, weight in weights.items()
        )

        # Finale Qualitäts-Metriken
        quality_metrics = {
            'overall_score': round(overall_score, 1),
            'completeness_rate': round(metrics['completeness'], 1),
            'phone_validity_rate': round(metrics['phone_validity'], 1),
            'email_validity_rate': round(metrics['email_validity'], 1),
            'address_completeness_rate': round(metrics['address_completeness'], 1),
            'name_completeness_rate': round(metrics['name_completeness'], 1),
            'data_consistency_rate': round(metrics['data_consistency'], 1),
            'categorization_accuracy_rate': round(metrics['categorization_accuracy'], 1),
            'duplicate_cleanliness_rate': round(metrics['duplicate_cleanliness'], 1),
            'total_records': total_records,
            'total_fields': total_fields,
            'field_distribution': self._get_field_distribution(),
            'categorization_confidence': self._get_average_categorization_confidence()
        }

        self.cleaning_stats['quality_improvements'] = quality_metrics

        # Detaillierte Ausgabe
        logger.info(f"📈 Erweiterter Datenqualitäts-Score: {overall_score:.1f}/100")
        logger.info(f"   - Vollständigkeit: {metrics['completeness']:.1f}%")
        logger.info(f"   - Telefon-Validität: {metrics['phone_validity']:.1f}%")
        logger.info(f"   - E-Mail-Validität: {metrics['email_validity']:.1f}%")
        logger.info(f"   - Adress-Vollständigkeit: {metrics['address_completeness']:.1f}%")
        logger.info(f"   - Namen-Vollständigkeit: {metrics['name_completeness']:.1f}%")
        logger.info(f"   - Daten-Konsistenz: {metrics['data_consistency']:.1f}%")
        logger.info(f"   - Kategorisierungs-Genauigkeit: {metrics['categorization_accuracy']:.1f}%")
        logger.info(f"   - Duplikat-Sauberkeit: {metrics['duplicate_cleanliness']:.1f}%")

        return quality_metrics

    def _calculate_phone_validity_advanced(self) -> float:
        """Erweiterte Telefon-Validitäts-Berechnung"""
        phone_fields = self.column_mapping['phone_fields']
        if not phone_fields:
            return 0

        total_valid = 0
        total_entries = 0

        for phone_type, field_name in phone_fields.items():
            if field_name and field_name in self.df.columns:
                non_empty = self.df[field_name].dropna()
                non_empty = non_empty[non_empty.astype(str).str.strip() != '']

                # Zähle gültige Telefonnummern (mit internationaler Formatierung)
                valid_count = sum(1 for x in non_empty if str(x).startswith('+') and len(str(x)) >= 10)

                total_valid += valid_count
                total_entries += len(non_empty)

        return (total_valid / max(total_entries, 1)) * 100

    def _calculate_email_validity_advanced(self) -> float:
        """Erweiterte E-Mail-Validitäts-Berechnung"""
        email_fields = self.column_mapping['email_fields']
        if not email_fields:
            return 0

        total_valid = 0
        total_entries = 0

        email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

        for email_field in email_fields:
            if email_field in self.df.columns:
                non_empty = self.df[email_field].dropna()
                non_empty = non_empty[non_empty.astype(str).str.strip() != '']

                valid_count = sum(1 for x in non_empty if re.match(email_pattern, str(x)))

                total_valid += valid_count
                total_entries += len(non_empty)

        return (total_valid / max(total_entries, 1)) * 100

    def _calculate_address_completeness_advanced(self) -> float:
        """Erweiterte Adress-Vollständigkeits-Berechnung"""
        return (self._count_complete_addresses_advanced() / max(len(self.df), 1)) * 100

    def _calculate_name_completeness_advanced(self) -> float:
        """Erweiterte Namen-Vollständigkeits-Berechnung"""
        name_fields = self.column_mapping['name_fields']
        if not name_fields:
            return 0

        complete_names = 0
        total_records = len(self.df)

        first_name_field = name_fields.get('first_name')
        last_name_field = name_fields.get('last_name')

        if first_name_field and last_name_field:
            for _, row in self.df.iterrows():
                first_valid = str(row.get(first_name_field, '')).strip() not in ['', 'nan', 'None']
                last_valid = str(row.get(last_name_field, '')).strip() not in ['', 'nan', 'None']

                if first_valid and last_valid:
                    complete_names += 1
        elif first_name_field or last_name_field:
            name_field = first_name_field or last_name_field
            complete_names = sum(1 for x in self.df[name_field]
                               if str(x).strip() not in ['', 'nan', 'None'])

        return (complete_names / max(total_records, 1)) * 100

    def _calculate_data_consistency(self) -> float:
        """Berechnet Daten-Konsistenz zwischen verwandten Feldern"""
        consistency_scores = []

        # Namen-Konsistenz (Vor- und Nachname sollten beide gefüllt oder beide leer sein)
        name_fields = self.column_mapping['name_fields']
        if name_fields.get('first_name') and name_fields.get('last_name'):
            first_field = name_fields['first_name']
            last_field = name_fields['last_name']

            consistent_count = 0
            for _, row in self.df.iterrows():
                first_filled = str(row.get(first_field, '')).strip() not in ['', 'nan', 'None']
                last_filled = str(row.get(last_field, '')).strip() not in ['', 'nan', 'None']

                if first_filled == last_filled:  # Beide gefüllt oder beide leer
                    consistent_count += 1

            consistency_scores.append(consistent_count / len(self.df))

        # Adress-Konsistenz (PLZ und Ort)
        address_fields = self.column_mapping['address_fields']
        if address_fields.get('postal_code') and address_fields.get('city'):
            plz_field = address_fields['postal_code']
            city_field = address_fields['city']

            consistent_count = 0
            for _, row in self.df.iterrows():
                plz_filled = str(row.get(plz_field, '')).strip() not in ['', 'nan', 'None']
                city_filled = str(row.get(city_field, '')).strip() not in ['', 'nan', 'None']

                if plz_filled == city_filled:
                    consistent_count += 1

            consistency_scores.append(consistent_count / len(self.df))

        # Kontakt-Konsistenz (Mindestens ein Kontaktmittel sollte vorhanden sein)
        contact_fields = []
        contact_fields.extend(self.column_mapping['email_fields'])
        contact_fields.extend([field for field in self.column_mapping['phone_fields'].values() if field])

        if contact_fields:
            contact_available_count = 0
            for _, row in self.df.iterrows():
                has_contact = any(
                    str(row.get(field, '')).strip() not in ['', 'nan', 'None']
                    for field in contact_fields
                )
                if has_contact:
                    contact_available_count += 1

            consistency_scores.append(contact_available_count / len(self.df))

        return (sum(consistency_scores) / max(len(consistency_scores), 1)) * 100

    def _calculate_categorization_accuracy(self) -> float:
        """Berechnet die Genauigkeit der Spalten-Kategorisierung"""
        if not self.categorization_confidence:
            return 50  # Neutral score wenn keine Confidence-Daten

        total_confidence = sum(
            data.get('overall_confidence', 0)
            for data in self.categorization_confidence.values()
        )

        avg_confidence = total_confidence / len(self.categorization_confidence)
        return avg_confidence * 100

    def _calculate_duplicate_cleanliness(self) -> float:
        """Berechnet wie gut die Duplikat-Bereinigung war"""
        duplicate_stats = self.cleaning_stats.get('duplicate_statistics', {})

        original_count = self.original_count
        removed_count = duplicate_stats.get('total_removed', 0)

        if original_count == 0:
            return 100

        # Schätze erwartete Duplikat-Rate basierend auf Datensatz-Größe
        expected_duplicate_rate = min(0.15, 100 / original_count)  # Max 15% oder 1 pro 100 Datensätze
        expected_duplicates = original_count * expected_duplicate_rate

        # Score basierend darauf wie viele Duplikate gefunden wurden
        if removed_count >= expected_duplicates:
            return 100  # Gute Bereinigung
        else:
            return (removed_count / max(expected_duplicates, 1)) * 100

    def _get_field_distribution(self) -> Dict:
        """Gibt die Verteilung der erkannten Feldtypen zurück"""
        distribution = {}

        for category, fields in self.column_mapping.items():
            if isinstance(fields, dict):
                distribution[category] = len([f for f in fields.values() if f])
            elif isinstance(fields, list):
                distribution[category] = len(fields)
            else:
                distribution[category] = 1 if fields else 0

        return distribution

    def _get_average_categorization_confidence(self) -> float:
        """Berechnet die durchschnittliche Kategorisierungs-Confidence"""
        if not self.categorization_confidence:
            return 0

        total_confidence = sum(
            data.get('overall_confidence', 0)
            for data in self.categorization_confidence.values()
        )

        return total_confidence / len(self.categorization_confidence)

    def save_cleaned_data_advanced(self, output_file: Optional[str] = None) -> Tuple[str, str]:
        """Speichert die bereinigten Daten mit erweiterten Metadaten"""
        if output_file is None:
            filename = Path(self.file_path).stem
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = f"{filename}_ADVANCED_CLEANED_{timestamp}.xlsx"

        logger.info(f"💾 Speichere erweiterte bereinigte Daten: {output_file}")
        self.df.to_excel(output_file, index=False)

        # Erweiterten Cleaning-Report speichern
        report_file = output_file.replace('.xlsx', '_ADVANCED_REPORT.json')

        cleaning_report = {
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'engine_version': 'Advanced Flexible v2.0',
                'processing_time': 'calculated_during_runtime'
            },
            'file_info': {
                'original_file': str(self.file_path),
                'cleaned_file': output_file,
                'original_size_mb': Path(self.file_path).stat().st_size / (1024*1024) if Path(self.file_path).exists() else 0,
                'cleaned_size_mb': Path(output_file).stat().st_size / (1024*1024) if Path(output_file).exists() else 0
            },
            'data_summary': {
                'original_record_count': self.original_count,
                'cleaned_record_count': len(self.df),
                'records_removed': self.original_count - len(self.df),
                'total_columns': len(self.df.columns)
            },
            'categorization_results': {
                'column_mapping': self.column_mapping,
                'categorization_confidence': self.categorization_confidence,
                'categorization_warnings': self.cleaning_stats.get('categorization_warnings', [])
            },
            'cleaning_statistics': self.cleaning_stats,
            'quality_analysis': self.cleaning_stats.get('quality_improvements', {}),
            'recommendations': self._generate_improvement_recommendations()
        }

        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(cleaning_report, f, indent=2, ensure_ascii=False, default=str)

        logger.info(f"📋 Erweiterten Cleaning-Report gespeichert: {report_file}")
        return output_file, report_file

    def _generate_improvement_recommendations(self) -> List[Dict]:
        """Generiert Verbesserungsempfehlungen basierend auf der Analyse"""
        recommendations = []

        quality_metrics = self.cleaning_stats.get('quality_improvements', {})

        # Telefon-Empfehlungen
        phone_validity = quality_metrics.get('phone_validity_rate', 0)
        if phone_validity < 70:
            recommendations.append({
                'category': 'phone_quality',
                'priority': 'HIGH',
                'issue': f'Telefon-Validität nur {phone_validity:.1f}%',
                'recommendation': 'Implementierung von Echtzeit-Telefonnummer-Validierung',
                'expected_improvement': '15-25 Qualitätspunkte'
            })

        # E-Mail-Empfehlungen
        email_validity = quality_metrics.get('email_validity_rate', 0)
        if email_validity < 80:
            recommendations.append({
                'category': 'email_quality',
                'priority': 'MEDIUM',
                'issue': f'E-Mail-Validität nur {email_validity:.1f}%',
                'recommendation': 'E-Mail-Deliverability-Checks implementieren',
                'expected_improvement': '5-10 Qualitätspunkte'
            })

        # Vollständigkeits-Empfehlungen
        completeness = quality_metrics.get('completeness_rate', 0)
        if completeness < 60:
            recommendations.append({
                'category': 'data_completeness',
                'priority': 'HIGH',
                'issue': f'Daten-Vollständigkeit nur {completeness:.1f}%',
                'recommendation': 'Externe Datenquellen für Anreicherung nutzen',
                'expected_improvement': '10-20 Qualitätspunkte'
            })

        # Kategorisierungs-Empfehlungen
        if self.cleaning_stats.get('categorization_warnings'):
            recommendations.append({
                'category': 'categorization',
                'priority': 'MEDIUM',
                'issue': f'{len(self.cleaning_stats["categorization_warnings"])} Kategorisierungs-Warnungen',
                'recommendation': 'Manuelle Überprüfung der Spalten-Zuordnungen',
                'expected_improvement': '3-8 Qualitätspunkte'
            })

        return recommendations

    def run_full_advanced_cleaning(self) -> Tuple[str, str, Dict]:
        """Führt die komplette erweiterte flexible Datenbereinigung durch"""
        start_time = datetime.now()
        logger.info("🚀 Starte erweiterte flexible Datenbereinigung...")

        try:
            # Phase 1: Daten laden und intelligente Struktur-Analyse
            self.load_data()

            # Phase 2: Erweiterte Bereinigungsphasen
            self.clean_phone_numbers_advanced()
            self.clean_email_addresses_advanced()
            self.clean_addresses_advanced()
            self.remove_duplicates_intelligent()

            # Phase 3: Erweiterte Qualitäts-Score Berechnung
            quality_score = self.calculate_advanced_quality_score()

            # Phase 4: Speichere Ergebnisse mit erweiterten Metadaten
            cleaned_file, report_file = self.save_cleaned_data_advanced()

            # Verarbeitungszeit berechnen
            processing_time = datetime.now() - start_time
            logger.info(f"✅ Erweiterte flexible Datenbereinigung abgeschlossen in {processing_time.total_seconds():.1f} Sekunden!")

            return cleaned_file, report_file, quality_score

        except Exception as e:
            logger.error(f"❌ Fehler bei der erweiterten Datenbereinigung: {e}")
            raise

def main():
    """Hauptfunktion für erweiterte flexible Bereinigung"""
    file_path = '/Users/justin/Desktop/Kundendaten/Kundendatenabgleich_202507251500.xls'

    engine = AdvancedFlexibleDataCleaningEngine(file_path)
    cleaned_file, report_file, quality_score = engine.run_full_advanced_cleaning()

    print("\n" + "="*80)
    print("🎯 ERWEITERTE FLEXIBLE DATENBEREINIGUNG ABGESCHLOSSEN")
    print("="*80)
    print(f"📁 Bereinigte Datei: {cleaned_file}")
    print(f"📊 Erweiterte Quality-Score: {quality_score['overall_score']}/100")
    print(f"📋 Erweiterte Analyse-Report: {report_file}")
    print(f"🔍 Kategorisierte Spalten: {sum(quality_score['field_distribution'].values())}")
    print(f"⚡ Kategorisierungs-Confidence: {quality_score['categorization_confidence']:.1f}")
    print(f"🧠 Intelligente Spalten-Erkennung mit Content-Validierung")
    print(f"🚀 Verbesserung durch erweiterte Algorithmen und Qualitätssicherung")
    print("="*80)

if __name__ == "__main__":
    main()