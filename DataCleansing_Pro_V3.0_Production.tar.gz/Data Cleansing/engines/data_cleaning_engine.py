#!/usr/bin/env python3
"""
Data Cleaning Engine für Kundendatenabgleich_202507251500.xls
Phase 1: Telefonnummer-Bereinigung, Adress-Korrektur, Duplikat-Management
"""

import pandas as pd
import re
import phonenumbers
from phonenumbers import NumberParseException, PhoneNumberFormat
import json
from datetime import datetime
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path
import logging

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class DataCleaningEngine:
    def __init__(self, file_path: str):
        self.file_path = file_path
        self.df = None
        self.original_count = 0
        self.cleaning_stats = {
            'phone_fixes': 0,
            'mobile_fixes': 0,
            'email_fixes': 0,
            'address_fixes': 0,
            'duplicates_removed': 0,
            'quality_improvements': {}
        }
    
    def load_data(self):
        """Lädt die Excel-Datei"""
        logger.info(f"📂 Lade Datei: {self.file_path}")
        self.df = pd.read_excel(self.file_path)
        self.original_count = len(self.df)
        logger.info(f"✅ {self.original_count:,} Datensätze geladen")
        return self.df
    
    def clean_phone_numbers(self):
        """Bereinigt und normalisiert Telefonnummern"""
        logger.info("📞 Starte Telefonnummer-Bereinigung...")
        
        def normalize_phone(phone_str, is_mobile=False):
            if pd.isna(phone_str) or str(phone_str).strip() in ['', ' ', 'nan', 'None', '0']:
                return ''
            
            phone_str = str(phone_str).strip()
            
            # Entferne häufige ungültige Zeichen
            phone_str = re.sub(r'[^\d\+\-\(\)\s]', '', phone_str)
            
            try:
                # Parse deutsche Nummer
                if not phone_str.startswith('+'):
                    if phone_str.startswith('0'):
                        phone_str = '+49' + phone_str[1:]
                    else:
                        phone_str = '+49' + phone_str
                
                parsed = phonenumbers.parse(phone_str, 'DE')
                
                if phonenumbers.is_valid_number(parsed):
                    # Prüfe ob es eine Mobilnummer ist
                    number_type = phonenumbers.number_type(parsed)
                    actual_is_mobile = number_type == phonenumbers.PhoneNumberType.MOBILE
                    
                    # Formatiere im internationalen Format
                    formatted = phonenumbers.format_number(parsed, PhoneNumberFormat.INTERNATIONAL)
                    
                    return {
                        'formatted': formatted,
                        'is_mobile': actual_is_mobile,
                        'is_valid': True
                    }
                else:
                    return {
                        'formatted': '',
                        'is_mobile': False,
                        'is_valid': False
                    }
                    
            except NumberParseException:
                return {
                    'formatted': '',
                    'is_mobile': False,
                    'is_valid': False
                }
        
        # Finde die verfügbaren Telefonspalten
        self.phone_columns = {
            'private_phone': None,
            'business_phone': None,
            'mobile_phone': None
        }

        for col in self.df.columns:
            col_lower = col.lower()
            if 'tel. privat' in col_lower or 'telefon privat' in col_lower:
                self.phone_columns['private_phone'] = col
            elif 'telefon geschäft' in col_lower or 'geschäft' in col_lower:
                self.phone_columns['business_phone'] = col
            elif 'mobil' in col_lower and 'telefon' in col_lower:
                self.phone_columns['mobile_phone'] = col

        logger.info(f"🔍 Gefundene Telefonspalten: {self.phone_columns}")

        # Telefonnummern bereinigen
        if self.phone_columns['private_phone']:
            logger.info("🔧 Bereinige private Telefonnummern...")
            phone_results = self.df[self.phone_columns['private_phone']].apply(lambda x: normalize_phone(x, False))
        else:
            phone_results = pd.Series([{'formatted': '', 'is_mobile': False, 'is_valid': False}] * len(self.df))

        if self.phone_columns['business_phone']:
            logger.info("🔧 Bereinige geschäftliche Telefonnummern...")
            business_results = self.df[self.phone_columns['business_phone']].apply(lambda x: normalize_phone(x, False))
        else:
            business_results = pd.Series([{'formatted': '', 'is_mobile': False, 'is_valid': False}] * len(self.df))

        if self.phone_columns['mobile_phone']:
            logger.info("🔧 Bereinige Mobilnummern...")
            mobile_results = self.df[self.phone_columns['mobile_phone']].apply(lambda x: normalize_phone(x, True))
        else:
            mobile_results = pd.Series([{'formatted': '', 'is_mobile': False, 'is_valid': False}] * len(self.df))
        
        # Ergebnisse anwenden und intelligente Zuordnung
        for idx in range(len(self.df)):
            phone_result = phone_results.iloc[idx]
            business_result = business_results.iloc[idx] if 'business_results' in locals() else {'formatted': '', 'is_mobile': False, 'is_valid': False}
            mobile_result = mobile_results.iloc[idx]

            # Private Telefonnummer verarbeiten
            if self.phone_columns['private_phone']:
                if isinstance(phone_result, dict) and phone_result['is_valid']:
                    self.df.at[idx, self.phone_columns['private_phone']] = phone_result['formatted']
                    self.cleaning_stats['phone_fixes'] += 1
                else:
                    self.df.at[idx, self.phone_columns['private_phone']] = ''

            # Geschäftliche Telefonnummer verarbeiten
            if self.phone_columns['business_phone']:
                if isinstance(business_result, dict) and business_result['is_valid']:
                    self.df.at[idx, self.phone_columns['business_phone']] = business_result['formatted']
                    self.cleaning_stats['phone_fixes'] += 1
                else:
                    self.df.at[idx, self.phone_columns['business_phone']] = ''

            # Mobilnummer verarbeiten
            if self.phone_columns['mobile_phone']:
                if isinstance(mobile_result, dict) and mobile_result['is_valid']:
                    self.df.at[idx, self.phone_columns['mobile_phone']] = mobile_result['formatted']
                    self.cleaning_stats['mobile_fixes'] += 1
                else:
                    self.df.at[idx, self.phone_columns['mobile_phone']] = ''

        # Statistiken
        valid_private = 0
        valid_business = 0
        valid_mobiles = 0

        if self.phone_columns['private_phone']:
            valid_private = sum(1 for x in self.df[self.phone_columns['private_phone']] if str(x).strip() != '')
        if self.phone_columns['business_phone']:
            valid_business = sum(1 for x in self.df[self.phone_columns['business_phone']] if str(x).strip() != '')
        if self.phone_columns['mobile_phone']:
            valid_mobiles = sum(1 for x in self.df[self.phone_columns['mobile_phone']] if str(x).strip() != '')

        logger.info(f"✅ Telefonnummern bereinigt: {valid_private:,} private, {valid_business:,} geschäftliche, {valid_mobiles:,} mobile")
        return self.df
    
    def clean_addresses(self):
        """Bereinigt und standardisiert Adressen"""
        logger.info("🏠 Starte Adress-Bereinigung...")
        
        # Deutsche PLZ-Muster
        plz_pattern = re.compile(r'^[0-9]{5}$')
        
        # PLZ bereinigen
        def clean_plz(plz):
            if pd.isna(plz):
                return ''
            plz_str = str(plz).strip()
            # Entferne alles außer Zahlen
            plz_clean = re.sub(r'[^\d]', '', plz_str)
            if len(plz_clean) == 5 and plz_pattern.match(plz_clean):
                return plz_clean
            elif len(plz_clean) == 4:  # Führende 0 ergänzen
                return '0' + plz_clean
            else:
                return ''
        
        # Ortsnamen standardisieren
        def clean_city(city):
            if pd.isna(city):
                return ''
            city_str = str(city).strip()
            # Erste Buchstaben groß, Rest klein
            return city_str.title() if city_str else ''
        
        # Straßen standardisieren
        def clean_street(street):
            if pd.isna(street):
                return ''
            street_str = str(street).strip()
            return street_str.title() if street_str else ''
        
        # Finde die verfügbaren Adress-Spalten
        self.address_columns = {}
        for col in self.df.columns:
            col_lower = col.lower()
            if 'postleitzahl' in col_lower or 'plz' in col_lower:
                if 'postfach' not in col_lower:  # Normale PLZ, nicht Postfach-PLZ
                    self.address_columns['plz'] = col
            elif col_lower == 'ort':
                self.address_columns['city'] = col
            elif 'strasse' in col_lower or 'straße' in col_lower:
                self.address_columns['street'] = col

        logger.info(f"🔍 Gefundene Adress-Spalten: {self.address_columns}")

        if 'plz' in self.address_columns:
            self.df[self.address_columns['plz']] = self.df[self.address_columns['plz']].apply(clean_plz)
        if 'city' in self.address_columns:
            self.df[self.address_columns['city']] = self.df[self.address_columns['city']].apply(clean_city)
        if 'street' in self.address_columns:
            self.df[self.address_columns['street']] = self.df[self.address_columns['street']].apply(clean_street)
        
        # PLZ-Ort-Konsistenz prüfen (vereinfacht)
        valid_addresses = 0
        if 'plz' in self.address_columns and 'city' in self.address_columns:
            valid_addresses = sum(1 for i, row in self.df.iterrows()
                                if str(row[self.address_columns['plz']]).strip() != '' and str(row[self.address_columns['city']]).strip() != '')
        
        self.cleaning_stats['address_fixes'] = valid_addresses
        logger.info(f"✅ Adressen bereinigt: {valid_addresses:,} vollständige Adressdaten")
        return self.df
    
    def remove_duplicates(self):
        """Entfernt Duplikate basierend auf mehreren Kriterien"""
        logger.info("🔄 Starte Duplikat-Entfernung...")
        
        original_count = len(self.df)
        
        # Mehrstufige Duplikat-Erkennung
        # 1. Exakte Duplikate (alle relevanten Felder identisch)
        key_columns = ['Vorname', 'Nachname', 'e-mail-Adresse']
        # Füge verfügbare Telefon- und Adress-Spalten hinzu
        if 'plz' in locals() and hasattr(self, 'address_columns'):
            key_columns.extend([col for col in [self.address_columns.get('plz'), self.address_columns.get('city')] if col])

        available_columns = [col for col in key_columns if col and col in self.df.columns]
        
        logger.info("🔍 Entferne exakte Duplikate...")
        self.df = self.df.drop_duplicates(subset=available_columns, keep='first')
        
        exact_removed = original_count - len(self.df)
        
        # 2. Ähnliche Duplikate (Fuzzy Matching für Namen + gleiche Kontaktdaten)
        logger.info("🔍 Suche ähnliche Duplikate...")
        
        def similar_strings(a, b, threshold=0.9):
            if pd.isna(a) or pd.isna(b):
                return False
            return SequenceMatcher(None, str(a).lower(), str(b).lower()).ratio() > threshold
        
        # Gruppiere nach E-Mail oder Telefon
        to_remove = set()

        contact_fields = ['e-mail-Adresse']
        # Füge verfügbare Telefon-Spalten hinzu
        if hasattr(self, 'phone_columns'):
            for phone_col in self.phone_columns.values():
                if phone_col:
                    contact_fields.append(phone_col)

        for contact_field in contact_fields:
            if contact_field not in self.df.columns:
                continue
                
            for contact_value in self.df[contact_field].unique():
                if pd.isna(contact_value) or str(contact_value).strip() == '':
                    continue
                    
                same_contact = self.df[self.df[contact_field] == contact_value]
                if len(same_contact) > 1:
                    # Prüfe auf ähnliche Namen
                    for i, row1 in same_contact.iterrows():
                        for j, row2 in same_contact.iterrows():
                            if i >= j or i in to_remove or j in to_remove:
                                continue
                                
                            name1 = f"{row1.get('Vorname', '')} {row1.get('Nachname', '')}"
                            name2 = f"{row2.get('Vorname', '')} {row2.get('Nachname', '')}"
                            
                            if similar_strings(name1, name2, 0.85):
                                # Behalte den mit mehr ausgefüllten Feldern
                                filled1 = sum(1 for val in row1 if pd.notna(val) and str(val).strip() != '')
                                filled2 = sum(1 for val in row2 if pd.notna(val) and str(val).strip() != '')
                                
                                if filled1 >= filled2:
                                    to_remove.add(j)
                                else:
                                    to_remove.add(i)
        
        if to_remove:
            self.df = self.df.drop(index=list(to_remove)).reset_index(drop=True)
        
        fuzzy_removed = len(to_remove)
        total_removed = exact_removed + fuzzy_removed
        
        self.cleaning_stats['duplicates_removed'] = total_removed
        logger.info(f"✅ Duplikate entfernt: {exact_removed:,} exakte + {fuzzy_removed:,} ähnliche = {total_removed:,} gesamt")
        logger.info(f"📊 Verbleibende Datensätze: {len(self.df):,}")
        
        return self.df
    
    def calculate_quality_score(self):
        """Berechnet den aktuellen Datenqualitäts-Score"""
        logger.info("📊 Berechne Datenqualitäts-Score...")
        
        total_records = len(self.df)
        total_fields = len(self.df.columns)
        
        # Vollständigkeits-Rate
        completeness = (self.df.count().sum() / (total_records * total_fields)) * 100
        
        # Telefon-Validität
        valid_phones_total = 0
        phone_fields_count = 0

        for phone_field in self.phone_columns.values():
            if phone_field:
                valid_phones_total += sum(1 for x in self.df[phone_field] if str(x).strip() not in ['', 'nan', 'None'])
                phone_fields_count += 1

        phone_validity = ((valid_phones_total / max(phone_fields_count * total_records, 1)) * 100) if phone_fields_count > 0 else 0

        # E-Mail-Validität (vereinfacht)
        email_field = 'e-mail-Adresse' if 'e-mail-Adresse' in self.df.columns else None
        valid_emails = 0
        if email_field:
            valid_emails = sum(1 for x in self.df[email_field] if str(x).strip() not in ['', 'nan', 'None'] and '@' in str(x))
        email_validity = (valid_emails / total_records) * 100

        # Adress-Vollständigkeit
        valid_addresses = 0
        if 'plz' in self.address_columns and 'city' in self.address_columns:
            valid_addresses = sum(1 for i, row in self.df.iterrows()
                                if str(row[self.address_columns['plz']]).strip() not in ['', 'nan', 'None']
                                and str(row[self.address_columns['city']]).strip() not in ['', 'nan', 'None'])
        address_completeness = (valid_addresses / total_records) * 100
        
        # Gesamt-Score (gewichtet)
        overall_score = (
            completeness * 0.35 +
            phone_validity * 0.25 + 
            email_validity * 0.25 +
            address_completeness * 0.15
        )
        
        quality_metrics = {
            'overall_score': round(overall_score, 1),
            'completeness_rate': round(completeness, 1),
            'phone_validity_rate': round(phone_validity, 1),
            'email_validity_rate': round(email_validity, 1),
            'address_completeness_rate': round(address_completeness, 1),
            'total_records': total_records,
            'valid_phones_total': valid_phones_total,
            'valid_emails': valid_emails,
            'valid_addresses': valid_addresses
        }
        
        self.cleaning_stats['quality_improvements'] = quality_metrics
        
        logger.info(f"📈 Datenqualitäts-Score: {overall_score:.1f}/100")
        logger.info(f"   - Vollständigkeit: {completeness:.1f}%")
        logger.info(f"   - Telefon-Validität: {phone_validity:.1f}%") 
        logger.info(f"   - E-Mail-Validität: {email_validity:.1f}%")
        logger.info(f"   - Adress-Vollständigkeit: {address_completeness:.1f}%")
        
        return quality_metrics
    
    def save_cleaned_data(self, output_file: str = None):
        """Speichert die bereinigten Daten"""
        if output_file is None:
            # Generiere Output-Pfad im Arbeitsverzeichnis
            filename = Path(self.file_path).stem
            output_file = f"{filename}_CLEANED.xlsx"
        
        logger.info(f"💾 Speichere bereinigte Daten: {output_file}")
        self.df.to_excel(output_file, index=False)
        
        # Speichere Cleaning-Report
        report_file = output_file.replace('.xlsx', '_CLEANING_REPORT.json')
        cleaning_report = {
            'timestamp': datetime.now().isoformat(),
            'original_file': self.file_path,
            'cleaned_file': output_file,
            'original_record_count': self.original_count,
            'cleaned_record_count': len(self.df),
            'cleaning_statistics': self.cleaning_stats
        }
        
        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(cleaning_report, f, indent=2, ensure_ascii=False)
        
        logger.info(f"📋 Cleaning-Report gespeichert: {report_file}")
        return output_file, report_file
    
    def run_full_cleaning(self):
        """Führt die komplette Datenbereinigung durch"""
        logger.info("🚀 Starte vollständige Datenbereinigung...")
        
        # Lade Daten
        self.load_data()
        
        # Phase 1: Bereinigung
        self.clean_phone_numbers()
        self.clean_addresses()
        self.remove_duplicates()
        
        # Qualitäts-Score berechnen
        quality_score = self.calculate_quality_score()
        
        # Speichere Ergebnisse
        cleaned_file, report_file = self.save_cleaned_data()
        
        logger.info("✅ Datenbereinigung abgeschlossen!")
        return cleaned_file, report_file, quality_score

def main():
    """Hauptfunktion"""
    file_path = '/Users/justin/Desktop/Kundendaten/Kunden9725.xlsx'
    
    engine = DataCleaningEngine(file_path)
    cleaned_file, report_file, quality_score = engine.run_full_cleaning()
    
    print("\n" + "="*60)
    print("🎯 DATENBEREINIGUNG ABGESCHLOSSEN")
    print("="*60)
    print(f"📁 Bereinigte Datei: {cleaned_file}")
    print(f"📊 Neuer Quality-Score: {quality_score['overall_score']}/100")
    print(f"📈 Verbesserung: Von ~49.7 auf {quality_score['overall_score']}")
    print(f"📋 Detailbericht: {report_file}")
    print("="*60)

if __name__ == "__main__":
    main()