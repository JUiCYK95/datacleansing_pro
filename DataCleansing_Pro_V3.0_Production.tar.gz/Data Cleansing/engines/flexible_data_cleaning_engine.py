#!/usr/bin/env python3
"""
Flexible Data Cleaning Engine
Automatische Erkennung und Anpassung an verschiedene Spaltenstrukturen
"""

import pandas as pd
import re
import phonenumbers
from phonenumbers import NumberParseException, PhoneNumberFormat
import json
from datetime import datetime
from collections import Counter
from difflib import SequenceMatcher
from pathlib import Path
import logging
from typing import Dict, List, Optional, Tuple

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class FlexibleDataCleaningEngine:
    """
    Flexible Data Cleaning Engine mit automatischer Spalten-Erkennung
    """

    def __init__(self, file_path: str):
        self.file_path = file_path
        self.df = None
        self.original_count = 0
        self.column_mapping = {}
        self.cleaning_stats = {
            'phone_fixes': 0,
            'mobile_fixes': 0,
            'email_fixes': 0,
            'address_fixes': 0,
            'duplicates_removed': 0,
            'quality_improvements': {}
        }

        # Spalten-Erkennungsmuster
        self.column_patterns = {
            'phone_fields': {
                'private_phone': [
                    r'tel.*privat', r'telefon.*privat', r'phone.*private',
                    r'private.*phone', r'festnetz.*privat', r'privates.*telefon'
                ],
                'business_phone': [
                    r'tel.*geschäft', r'telefon.*geschäft', r'phone.*business',
                    r'business.*phone', r'geschäftlich.*telefon', r'office.*phone',
                    r'work.*phone', r'telefon.*büro', r'büro.*telefon'
                ],
                'mobile_phone': [
                    r'mobil.*telefon', r'handy', r'mobile.*phone', r'cell.*phone',
                    r'smartphone', r'mobil', r'cellular'
                ],
                'fax': [
                    r'fax', r'telefax', r'faxnummer'
                ]
            },
            'email_fields': [
                r'e.*mail', r'email', r'mail.*adresse', r'elektronische.*post',
                r'e.*post'
            ],
            'address_fields': {
                'street': [
                    r'straße', r'strasse', r'street', r'adresse', r'address'
                ],
                'house_number': [
                    r'hausnummer', r'nr', r'number', r'haus.*nr'
                ],
                'postal_code': [
                    r'plz', r'postleitzahl', r'postal.*code', r'zip.*code', r'zip'
                ],
                'city': [
                    r'^ort$', r'^city$', r'stadt', r'gemeinde', r'municipality'
                ],
                'country': [
                    r'land', r'country', r'nation'
                ]
            },
            'name_fields': {
                'first_name': [
                    r'vorname', r'first.*name', r'given.*name', r'christian.*name'
                ],
                'last_name': [
                    r'nachname', r'familienname', r'last.*name', r'surname', r'family.*name'
                ],
                'title': [
                    r'titel', r'title', r'anrede', r'salutation'
                ],
                'company': [
                    r'firma', r'unternehmen', r'company', r'business', r'betrieb'
                ]
            },
            'date_fields': [
                r'datum', r'date', r'geboren', r'birth', r'created', r'erstellt',
                r'geändert', r'modified', r'updated', r'kontakt', r'besuch'
            ],
            'id_fields': [
                r'id', r'nummer', r'number', r'kundennummer', r'customer.*id',
                r'client.*id', r'referenz', r'reference'
            ]
        }

    def load_data(self) -> pd.DataFrame:
        """Lädt die Excel-Datei und analysiert die Spaltenstruktur"""
        logger.info(f"📂 Lade Datei: {self.file_path}")

        try:
            if self.file_path.endswith(('.xlsx', '.xls')):
                self.df = pd.read_excel(self.file_path)
            elif self.file_path.endswith('.csv'):
                # Versuche verschiedene Encodings und Trennzeichen
                encodings = ['utf-8', 'latin1', 'cp1252', 'iso-8859-1']
                separators = [',', ';', '\t']

                for encoding in encodings:
                    for sep in separators:
                        try:
                            self.df = pd.read_csv(self.file_path, encoding=encoding, sep=sep)
                            logger.info(f"✅ CSV geladen mit Encoding: {encoding}, Separator: '{sep}'")
                            break
                        except:
                            continue
                    if self.df is not None:
                        break

                if self.df is None:
                    raise ValueError("CSV konnte mit keiner Encoding/Separator-Kombination geladen werden")

            else:
                raise ValueError(f"Nicht unterstütztes Dateiformat: {self.file_path}")

            self.original_count = len(self.df)
            logger.info(f"✅ {self.original_count:,} Datensätze mit {len(self.df.columns)} Spalten geladen")

            # Spaltenstruktur analysieren
            self.analyze_column_structure()
            return self.df

        except Exception as e:
            logger.error(f"❌ Fehler beim Laden der Datei: {e}")
            raise

    def analyze_column_structure(self) -> None:
        """Analysiert und kategorisiert alle Spalten automatisch"""
        logger.info("🔍 Analysiere Spaltenstruktur...")

        self.column_mapping = {
            'phone_fields': {},
            'email_fields': [],
            'address_fields': {},
            'name_fields': {},
            'date_fields': [],
            'id_fields': [],
            'other_fields': []
        }

        for column in self.df.columns:
            column_lower = str(column).lower().strip()
            categorized = False

            # Telefon-Felder prüfen
            for phone_type, patterns in self.column_patterns['phone_fields'].items():
                if self._matches_patterns(column_lower, patterns):
                    self.column_mapping['phone_fields'][phone_type] = column
                    categorized = True
                    break

            if categorized:
                continue

            # E-Mail-Felder prüfen
            if self._matches_patterns(column_lower, self.column_patterns['email_fields']):
                self.column_mapping['email_fields'].append(column)
                categorized = True

            if categorized:
                continue

            # Adress-Felder prüfen
            for addr_type, patterns in self.column_patterns['address_fields'].items():
                if self._matches_patterns(column_lower, patterns):
                    self.column_mapping['address_fields'][addr_type] = column
                    categorized = True
                    break

            if categorized:
                continue

            # Namen-Felder prüfen
            for name_type, patterns in self.column_patterns['name_fields'].items():
                if self._matches_patterns(column_lower, patterns):
                    self.column_mapping['name_fields'][name_type] = column
                    categorized = True
                    break

            if categorized:
                continue

            # Datums-Felder prüfen
            if self._matches_patterns(column_lower, self.column_patterns['date_fields']):
                self.column_mapping['date_fields'].append(column)
                categorized = True

            if categorized:
                continue

            # ID-Felder prüfen
            if self._matches_patterns(column_lower, self.column_patterns['id_fields']):
                self.column_mapping['id_fields'].append(column)
                categorized = True

            if not categorized:
                self.column_mapping['other_fields'].append(column)

        # Erkannte Struktur ausgeben
        self._log_column_mapping()

    def _matches_patterns(self, text: str, patterns: List[str]) -> bool:
        """Prüft, ob ein Text zu einem der Muster passt"""
        for pattern in patterns:
            if re.search(pattern, text, re.IGNORECASE):
                return True
        return False

    def _log_column_mapping(self) -> None:
        """Gibt die erkannte Spalten-Zuordnung aus"""
        logger.info("📋 Erkannte Spaltenstruktur:")

        for category, fields in self.column_mapping.items():
            if fields:
                if isinstance(fields, dict):
                    logger.info(f"   {category}:")
                    for field_type, column_name in fields.items():
                        logger.info(f"     - {field_type}: '{column_name}'")
                elif isinstance(fields, list):
                    if fields:
                        logger.info(f"   {category}: {fields}")
                else:
                    logger.info(f"   {category}: {fields}")

    def clean_phone_numbers(self) -> pd.DataFrame:
        """Bereinigt und normalisiert alle erkannten Telefonnummer-Felder"""
        logger.info("📞 Starte flexible Telefonnummer-Bereinigung...")

        phone_fields = self.column_mapping['phone_fields']
        if not phone_fields:
            logger.warning("⚠️ Keine Telefonnummer-Felder erkannt")
            return self.df

        def normalize_phone(phone_str, is_mobile_expected=False):
            """Normalisiert eine Telefonnummer"""
            if pd.isna(phone_str) or str(phone_str).strip() in ['', ' ', 'nan', 'None', '0']:
                return {'formatted': '', 'is_mobile': False, 'is_valid': False}

            phone_str = str(phone_str).strip()

            # Entferne häufige ungültige Zeichen, behalte aber Klammern und Bindestriche
            phone_str = re.sub(r'[^\d\+\-\(\)\s\/]', '', phone_str)

            try:
                # Deutsche Nummer formatieren
                if not phone_str.startswith('+'):
                    if phone_str.startswith('0'):
                        phone_str = '+49' + phone_str[1:]
                    elif phone_str.startswith('49'):
                        phone_str = '+' + phone_str
                    else:
                        phone_str = '+49' + phone_str

                parsed = phonenumbers.parse(phone_str, 'DE')

                if phonenumbers.is_valid_number(parsed):
                    number_type = phonenumbers.number_type(parsed)
                    actual_is_mobile = number_type == phonenumbers.PhoneNumberType.MOBILE

                    formatted = phonenumbers.format_number(parsed, PhoneNumberFormat.INTERNATIONAL)

                    return {
                        'formatted': formatted,
                        'is_mobile': actual_is_mobile,
                        'is_valid': True,
                        'number_type': str(number_type)
                    }
                else:
                    return {'formatted': '', 'is_mobile': False, 'is_valid': False}

            except NumberParseException as e:
                return {'formatted': '', 'is_mobile': False, 'is_valid': False, 'error': str(e)}

        # Verarbeite alle erkannten Telefon-Felder
        for phone_type, column_name in phone_fields.items():
            if column_name and column_name in self.df.columns:
                logger.info(f"🔧 Bereinige {phone_type}: '{column_name}'")

                is_mobile_expected = 'mobile' in phone_type.lower()
                results = self.df[column_name].apply(lambda x: normalize_phone(x, is_mobile_expected))

                # Wende Ergebnisse an
                for idx in range(len(self.df)):
                    result = results.iloc[idx]
                    if isinstance(result, dict) and result['is_valid']:
                        self.df.at[idx, column_name] = result['formatted']
                        if result['is_mobile']:
                            self.cleaning_stats['mobile_fixes'] += 1
                        else:
                            self.cleaning_stats['phone_fixes'] += 1
                    else:
                        self.df.at[idx, column_name] = ''

        # Statistiken berechnen
        total_valid = 0
        for phone_type, column_name in phone_fields.items():
            if column_name:
                valid_count = sum(1 for x in self.df[column_name] if str(x).strip() != '')
                total_valid += valid_count
                logger.info(f"   ✅ {phone_type}: {valid_count:,} gültige Nummern")

        logger.info(f"✅ Telefonnummern bereinigt: {total_valid:,} gültige Nummern insgesamt")
        return self.df

    def clean_email_addresses(self) -> pd.DataFrame:
        """Bereinigt und validiert E-Mail-Adressen"""
        logger.info("📧 Starte E-Mail-Bereinigung...")

        email_fields = self.column_mapping['email_fields']
        if not email_fields:
            logger.warning("⚠️ Keine E-Mail-Felder erkannt")
            return self.df

        def clean_email(email_str):
            """Bereinigt eine E-Mail-Adresse"""
            if pd.isna(email_str) or str(email_str).strip() == '':
                return ''

            email_str = str(email_str).strip().lower()

            # Grundlegende E-Mail-Validierung
            email_pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'

            if re.match(email_pattern, email_str):
                return email_str
            else:
                # Versuche häufige Probleme zu beheben
                # Entferne führende/nachstehende Sonderzeichen
                email_str = re.sub(r'^[^a-zA-Z0-9]+|[^a-zA-Z0-9]+$', '', email_str)

                if re.match(email_pattern, email_str):
                    return email_str
                else:
                    return ''  # Ungültige E-Mail

        for email_field in email_fields:
            if email_field in self.df.columns:
                logger.info(f"🔧 Bereinige E-Mail-Feld: '{email_field}'")

                self.df[email_field] = self.df[email_field].apply(clean_email)

                valid_emails = sum(1 for x in self.df[email_field] if str(x).strip() != '')
                self.cleaning_stats['email_fixes'] += valid_emails
                logger.info(f"   ✅ {valid_emails:,} gültige E-Mail-Adressen")

        return self.df

    def clean_addresses(self) -> pd.DataFrame:
        """Bereinigt und standardisiert Adressdaten"""
        logger.info("🏠 Starte Adress-Bereinigung...")

        address_fields = self.column_mapping['address_fields']
        if not address_fields:
            logger.warning("⚠️ Keine Adress-Felder erkannt")
            return self.df

        # Deutsche PLZ-Muster
        plz_pattern = re.compile(r'^[0-9]{5}$')

        def clean_plz(plz):
            """Bereinigt deutsche Postleitzahlen"""
            if pd.isna(plz):
                return ''
            plz_str = str(plz).strip()
            plz_clean = re.sub(r'[^0-9]', '', plz_str)

            if len(plz_clean) == 5 and plz_pattern.match(plz_clean):
                return plz_clean
            elif len(plz_clean) == 4:
                return '0' + plz_clean
            else:
                return ''

        def clean_text_field(text):
            """Standardisiert Textfelder (Stadt, Straße)"""
            if pd.isna(text):
                return ''
            text_str = str(text).strip()
            return text_str.title() if text_str else ''

        # PLZ bereinigen
        if 'postal_code' in address_fields and address_fields['postal_code']:
            plz_field = address_fields['postal_code']
            logger.info(f"🔧 Bereinige PLZ: '{plz_field}'")
            self.df[plz_field] = self.df[plz_field].apply(clean_plz)

        # Stadt bereinigen
        if 'city' in address_fields and address_fields['city']:
            city_field = address_fields['city']
            logger.info(f"🔧 Bereinige Stadt: '{city_field}'")
            self.df[city_field] = self.df[city_field].apply(clean_text_field)

        # Straße bereinigen
        if 'street' in address_fields and address_fields['street']:
            street_field = address_fields['street']
            logger.info(f"🔧 Bereinige Straße: '{street_field}'")
            self.df[street_field] = self.df[street_field].apply(clean_text_field)

        # Vollständige Adressen zählen
        valid_addresses = self._count_complete_addresses()
        self.cleaning_stats['address_fixes'] = valid_addresses
        logger.info(f"✅ Adressen bereinigt: {valid_addresses:,} vollständige Adressdaten")

        return self.df

    def _count_complete_addresses(self) -> int:
        """Zählt vollständige Adressen"""
        address_fields = self.column_mapping['address_fields']

        # Mindestanforderungen für vollständige Adresse
        required_fields = []
        if address_fields.get('postal_code'):
            required_fields.append(address_fields['postal_code'])
        if address_fields.get('city'):
            required_fields.append(address_fields['city'])

        if not required_fields:
            return 0

        complete_count = 0
        for _, row in self.df.iterrows():
            is_complete = all(
                str(row[field]).strip() not in ['', 'nan', 'None']
                for field in required_fields
            )
            if is_complete:
                complete_count += 1

        return complete_count

    def remove_duplicates(self) -> pd.DataFrame:
        """Intelligente Duplikat-Entfernung basierend auf erkannten Feldern"""
        logger.info("🔄 Starte intelligente Duplikat-Entfernung...")

        original_count = len(self.df)

        # Erstelle dynamische Schlüsselfelder basierend auf verfügbaren Daten
        key_fields = []

        # Namen-Felder hinzufügen
        name_fields = self.column_mapping['name_fields']
        if name_fields.get('first_name'):
            key_fields.append(name_fields['first_name'])
        if name_fields.get('last_name'):
            key_fields.append(name_fields['last_name'])

        # E-Mail hinzufügen
        if self.column_mapping['email_fields']:
            key_fields.append(self.column_mapping['email_fields'][0])

        # Haupttelefonnummer hinzufügen
        phone_fields = self.column_mapping['phone_fields']
        for phone_type in ['private_phone', 'business_phone', 'mobile_phone']:
            if phone_fields.get(phone_type):
                key_fields.append(phone_fields[phone_type])
                break

        # PLZ/Stadt hinzufügen
        address_fields = self.column_mapping['address_fields']
        if address_fields.get('postal_code'):
            key_fields.append(address_fields['postal_code'])

        # Filtere nur existierende Spalten
        available_key_fields = [field for field in key_fields if field in self.df.columns]

        if not available_key_fields:
            logger.warning("⚠️ Keine geeigneten Felder für Duplikat-Erkennung gefunden")
            return self.df

        logger.info(f"🔍 Verwende Schlüsselfelder für Duplikat-Erkennung: {available_key_fields}")

        # 1. Exakte Duplikate entfernen
        logger.info("🔍 Entferne exakte Duplikate...")
        self.df = self.df.drop_duplicates(subset=available_key_fields, keep='first')
        exact_removed = original_count - len(self.df)

        # 2. Ähnliche Duplikate (Fuzzy Matching)
        logger.info("🔍 Suche ähnliche Duplikate...")
        fuzzy_removed = self._remove_fuzzy_duplicates(available_key_fields)

        total_removed = exact_removed + fuzzy_removed
        self.cleaning_stats['duplicates_removed'] = total_removed

        logger.info(f"✅ Duplikate entfernt: {exact_removed:,} exakte + {fuzzy_removed:,} ähnliche = {total_removed:,} gesamt")
        logger.info(f"📊 Verbleibende Datensätze: {len(self.df):,}")

        return self.df

    def _remove_fuzzy_duplicates(self, key_fields: List[str]) -> int:
        """Entfernt ähnliche Duplikate mittels Fuzzy Matching"""
        to_remove = set()

        # Nur bei Kontaktfeldern (E-Mail, Telefon) Fuzzy Matching anwenden
        contact_fields = []

        if self.column_mapping['email_fields']:
            contact_fields.extend(self.column_mapping['email_fields'])

        for phone_type, phone_field in self.column_mapping['phone_fields'].items():
            if phone_field:
                contact_fields.append(phone_field)

        contact_fields = [field for field in contact_fields if field in self.df.columns]

        def similar_strings(a, b, threshold=0.85):
            if pd.isna(a) or pd.isna(b):
                return False
            return SequenceMatcher(None, str(a).lower(), str(b).lower()).ratio() > threshold

        # Gruppiere nach Kontaktfeldern und prüfe auf ähnliche Namen
        for contact_field in contact_fields:
            for contact_value in self.df[contact_field].dropna().unique():
                if str(contact_value).strip() == '':
                    continue

                same_contact = self.df[self.df[contact_field] == contact_value]
                if len(same_contact) <= 1:
                    continue

                # Prüfe auf ähnliche Namen
                name_fields = self.column_mapping['name_fields']
                if name_fields.get('first_name') and name_fields.get('last_name'):
                    first_name_field = name_fields['first_name']
                    last_name_field = name_fields['last_name']

                    for i, row1 in same_contact.iterrows():
                        for j, row2 in same_contact.iterrows():
                            if i >= j or i in to_remove or j in to_remove:
                                continue

                            name1 = f"{row1.get(first_name_field, '')} {row1.get(last_name_field, '')}"
                            name2 = f"{row2.get(first_name_field, '')} {row2.get(last_name_field, '')}"

                            if similar_strings(name1, name2):
                                # Behalte den Datensatz mit mehr ausgefüllten Feldern
                                filled1 = sum(1 for val in row1 if pd.notna(val) and str(val).strip() != '')
                                filled2 = sum(1 for val in row2 if pd.notna(val) and str(val).strip() != '')

                                if filled1 >= filled2:
                                    to_remove.add(j)
                                else:
                                    to_remove.add(i)

        # Entferne ähnliche Duplikate
        if to_remove:
            self.df = self.df.drop(index=list(to_remove)).reset_index(drop=True)

        return len(to_remove)

    def calculate_quality_score(self) -> Dict:
        """Berechnet einen umfassenden Datenqualitäts-Score"""
        logger.info("📊 Berechne flexiblen Datenqualitäts-Score...")

        total_records = len(self.df)
        total_fields = len(self.df.columns)

        if total_records == 0:
            return {'overall_score': 0, 'total_records': 0}

        # 1. Vollständigkeits-Rate
        completeness = (self.df.count().sum() / (total_records * total_fields)) * 100

        # 2. Telefon-Validität
        phone_validity = self._calculate_phone_validity()

        # 3. E-Mail-Validität
        email_validity = self._calculate_email_validity()

        # 4. Adress-Vollständigkeit
        address_completeness = self._calculate_address_completeness()

        # 5. Namen-Vollständigkeit
        name_completeness = self._calculate_name_completeness()

        # Gewichteter Gesamt-Score
        weights = {
            'completeness': 0.25,
            'phone_validity': 0.20,
            'email_validity': 0.20,
            'address_completeness': 0.20,
            'name_completeness': 0.15
        }

        overall_score = (
            completeness * weights['completeness'] +
            phone_validity * weights['phone_validity'] +
            email_validity * weights['email_validity'] +
            address_completeness * weights['address_completeness'] +
            name_completeness * weights['name_completeness']
        )

        quality_metrics = {
            'overall_score': round(overall_score, 1),
            'completeness_rate': round(completeness, 1),
            'phone_validity_rate': round(phone_validity, 1),
            'email_validity_rate': round(email_validity, 1),
            'address_completeness_rate': round(address_completeness, 1),
            'name_completeness_rate': round(name_completeness, 1),
            'total_records': total_records,
            'total_fields': total_fields,
            'field_distribution': self._get_field_distribution()
        }

        self.cleaning_stats['quality_improvements'] = quality_metrics

        # Detaillierte Ausgabe
        logger.info(f"📈 Flexibler Datenqualitäts-Score: {overall_score:.1f}/100")
        logger.info(f"   - Vollständigkeit: {completeness:.1f}%")
        logger.info(f"   - Telefon-Validität: {phone_validity:.1f}%")
        logger.info(f"   - E-Mail-Validität: {email_validity:.1f}%")
        logger.info(f"   - Adress-Vollständigkeit: {address_completeness:.1f}%")
        logger.info(f"   - Namen-Vollständigkeit: {name_completeness:.1f}%")

        return quality_metrics

    def _calculate_phone_validity(self) -> float:
        """Berechnet die Telefon-Validität"""
        phone_fields = self.column_mapping['phone_fields']
        if not phone_fields:
            return 0

        total_valid = 0
        total_fields = 0

        for phone_type, field_name in phone_fields.items():
            if field_name and field_name in self.df.columns:
                valid_count = sum(1 for x in self.df[field_name]
                                if str(x).strip() not in ['', 'nan', 'None'])
                total_valid += valid_count
                total_fields += len(self.df)

        return (total_valid / max(total_fields, 1)) * 100

    def _calculate_email_validity(self) -> float:
        """Berechnet die E-Mail-Validität"""
        email_fields = self.column_mapping['email_fields']
        if not email_fields:
            return 0

        total_valid = 0
        total_records = len(self.df)

        for email_field in email_fields:
            if email_field in self.df.columns:
                valid_count = sum(1 for x in self.df[email_field]
                                if str(x).strip() not in ['', 'nan', 'None'] and '@' in str(x))
                total_valid += valid_count

        # Verwende nur ein E-Mail-Feld für die Berechnung (um nicht zu übergewichten)
        return (total_valid / max(total_records, 1)) * 100

    def _calculate_address_completeness(self) -> float:
        """Berechnet die Adress-Vollständigkeit"""
        return (self._count_complete_addresses() / max(len(self.df), 1)) * 100

    def _calculate_name_completeness(self) -> float:
        """Berechnet die Namen-Vollständigkeit"""
        name_fields = self.column_mapping['name_fields']
        if not name_fields:
            return 0

        complete_names = 0
        total_records = len(self.df)

        # Prüfe ob Vor- und Nachname vorhanden sind
        first_name_field = name_fields.get('first_name')
        last_name_field = name_fields.get('last_name')

        if first_name_field and last_name_field:
            for _, row in self.df.iterrows():
                first_valid = str(row.get(first_name_field, '')).strip() not in ['', 'nan', 'None']
                last_valid = str(row.get(last_name_field, '')).strip() not in ['', 'nan', 'None']

                if first_valid and last_valid:
                    complete_names += 1
        elif first_name_field or last_name_field:
            # Wenn nur ein Namen-Feld vorhanden ist
            name_field = first_name_field or last_name_field
            complete_names = sum(1 for x in self.df[name_field]
                               if str(x).strip() not in ['', 'nan', 'None'])

        return (complete_names / max(total_records, 1)) * 100

    def _get_field_distribution(self) -> Dict:
        """Gibt die Verteilung der erkannten Feldtypen zurück"""
        distribution = {}

        for category, fields in self.column_mapping.items():
            if isinstance(fields, dict):
                distribution[category] = len([f for f in fields.values() if f])
            elif isinstance(fields, list):
                distribution[category] = len(fields)
            else:
                distribution[category] = 1 if fields else 0

        return distribution

    def save_cleaned_data(self, output_file: Optional[str] = None) -> Tuple[str, str]:
        """Speichert die bereinigten Daten mit flexiblem Dateinamen"""
        if output_file is None:
            filename = Path(self.file_path).stem
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            output_file = f"{filename}_FLEXIBLE_CLEANED_{timestamp}.xlsx"

        logger.info(f"💾 Speichere bereinigte Daten: {output_file}")
        self.df.to_excel(output_file, index=False)

        # Speichere erweiterten Cleaning-Report
        report_file = output_file.replace('.xlsx', '_REPORT.json')
        cleaning_report = {
            'timestamp': datetime.now().isoformat(),
            'original_file': str(self.file_path),
            'cleaned_file': output_file,
            'original_record_count': self.original_count,
            'cleaned_record_count': len(self.df),
            'records_removed': self.original_count - len(self.df),
            'column_mapping': self.column_mapping,
            'cleaning_statistics': self.cleaning_stats,
            'file_info': {
                'original_size_mb': Path(self.file_path).stat().st_size / (1024*1024) if Path(self.file_path).exists() else 0,
                'cleaned_size_mb': Path(output_file).stat().st_size / (1024*1024) if Path(output_file).exists() else 0
            }
        }

        with open(report_file, 'w', encoding='utf-8') as f:
            json.dump(cleaning_report, f, indent=2, ensure_ascii=False, default=str)

        logger.info(f"📋 Erweiterter Cleaning-Report gespeichert: {report_file}")
        return output_file, report_file

    def run_full_cleaning(self) -> Tuple[str, str, Dict]:
        """Führt die komplette flexible Datenbereinigung durch"""
        logger.info("🚀 Starte flexible vollständige Datenbereinigung...")

        # 1. Daten laden und Struktur analysieren
        self.load_data()

        # 2. Bereinigungsphasen
        self.clean_phone_numbers()
        self.clean_email_addresses()
        self.clean_addresses()
        self.remove_duplicates()

        # 3. Qualitäts-Score berechnen
        quality_score = self.calculate_quality_score()

        # 4. Speichere Ergebnisse
        cleaned_file, report_file = self.save_cleaned_data()

        logger.info("✅ Flexible Datenbereinigung abgeschlossen!")
        return cleaned_file, report_file, quality_score

def main():
    """Hauptfunktion für flexible Bereinigung"""
    file_path = '/Users/justin/Desktop/Kundendaten/Kunden9725.xlsx'

    engine = FlexibleDataCleaningEngine(file_path)
    cleaned_file, report_file, quality_score = engine.run_full_cleaning()

    print("\n" + "="*70)
    print("🎯 FLEXIBLE DATENBEREINIGUNG ABGESCHLOSSEN")
    print("="*70)
    print(f"📁 Bereinigte Datei: {cleaned_file}")
    print(f"📊 Flexibler Quality-Score: {quality_score['overall_score']}/100")
    print(f"📋 Detailbericht: {report_file}")
    print(f"🔍 Erkannte Spaltentypen: {sum(quality_score['field_distribution'].values())}")
    print(f"📈 Verbesserung durch intelligente Spalten-Erkennung")
    print("="*70)

if __name__ == "__main__":
    main()