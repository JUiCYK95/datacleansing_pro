#!/usr/bin/env python3
"""
Comprehensive System Validation and Testing Script
Prüft alle Komponenten des Advanced Data Cleansing Systems auf Fehler und Bugs
"""

import pandas as pd
import numpy as np
import sys
import traceback
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Import der Hauptmodule
try:
    from cost_free_data_analysis import CostFreeDataAnalyzer
    print("✅ Hauptmodul erfolgreich importiert")
except ImportError as e:
    print(f"❌ KRITISCHER FEHLER: Hauptmodul konnte nicht importiert werden: {e}")
    sys.exit(1)

class SystemValidator:
    """Umfassende System-Validierung und Test-Suite"""

    def __init__(self):
        self.test_results = {}
        self.errors_found = []
        self.warnings_found = []
        self.test_data = None

    def create_test_data(self):
        """Erstelle realistische Test-Daten"""
        print("\n🔧 Erstelle Test-Daten...")

        try:
            # Realistische deutsche Test-Daten
            test_data = {
                'Vorname': ['Max', 'Maria', 'Dr. Klaus', 'Anna-Lisa', None, 'PETER', 'julia'],
                'Nachname': ['Mustermann', 'Schmidt', 'Weber', 'Müller-Heinrich', '', 'MEYER', 'koch'],
                'Email': ['max@test.de', 'invalid-email', 'maria.schmidt@company.com',
                         'test@domain', None, 'CAPS@DOMAIN.DE', 'valid@test.org'],
                'Telefon': ['030-1234567', '+49-30-9876543', '0151/12345678', 'invalid',
                           None, '+4915112345678', '030 123 456'],
                'Mobiltelefon': ['+49151987654321', '0172/123456', None, '030-1234567',
                                '', '+49-172-9876543', 'invalid'],
                'Firma': ['Test GmbH', 'ACME Company', 'Schmidt & Co.', 'Weber AG',
                         None, 'startup gmbh', 'Big Corp Inc.'],
                'Straße': ['Musterstraße 123', 'Testweg 45a', None, 'Hauptstraße 1-3',
                          '', 'Am Ring 89', 'Berliner Platz 12'],
                'PLZ': ['12345', '54321', '1234', None, '123456', '98765', ''],
                'Ort': ['Berlin', 'Hamburg', 'München', None, 'KÖLN', 'frankfurt', 'Stuttgart'],
                'Bemerkungen': ['Wichtiger Kunde', None, 'B2B Kontakt', '',
                               'Automotive Branche', 'Privatkunde', 'Finance Sektor']
            }

            self.test_data = pd.DataFrame(test_data)
            print(f"   ✅ Test-Daten erstellt: {len(self.test_data)} Datensätze")
            return True

        except Exception as e:
            self.errors_found.append(f"Test-Daten-Erstellung fehlgeschlagen: {e}")
            return False

    def test_basic_functionality(self):
        """Teste Grundfunktionalitäten"""
        print("\n🧪 Teste Grundfunktionalitäten...")

        test_results = {'basic_tests': {}}

        try:
            # 1. Analyzer-Initialisierung
            analyzer = CostFreeDataAnalyzer('test_data.xlsx')
            analyzer.df = self.test_data.copy()
            test_results['basic_tests']['initialization'] = 'PASS'

            # 2. Data Structure Analysis
            try:
                structure_result = analyzer.analyze_data_structure()
                if isinstance(structure_result, dict) and 'total_records' in structure_result:
                    test_results['basic_tests']['data_structure'] = 'PASS'
                else:
                    test_results['basic_tests']['data_structure'] = 'FAIL'
                    self.errors_found.append("Data Structure Analysis returned invalid format")
            except Exception as e:
                test_results['basic_tests']['data_structure'] = 'FAIL'
                self.errors_found.append(f"Data Structure Analysis failed: {e}")

            # 3. Contact Quality Analysis
            try:
                contact_result = analyzer.analyze_contact_quality_free()
                if isinstance(contact_result, dict):
                    test_results['basic_tests']['contact_quality'] = 'PASS'
                else:
                    test_results['basic_tests']['contact_quality'] = 'FAIL'
            except Exception as e:
                test_results['basic_tests']['contact_quality'] = 'FAIL'
                self.errors_found.append(f"Contact Quality Analysis failed: {e}")

            # 4. Fuzzy Duplicate Detection
            try:
                duplicate_result = analyzer.identify_fuzzy_duplicates()
                if isinstance(duplicate_result, dict):
                    test_results['basic_tests']['duplicate_detection'] = 'PASS'
                else:
                    test_results['basic_tests']['duplicate_detection'] = 'FAIL'
            except Exception as e:
                test_results['basic_tests']['duplicate_detection'] = 'FAIL'
                self.errors_found.append(f"Duplicate Detection failed: {e}")

        except Exception as e:
            test_results['basic_tests']['initialization'] = 'FAIL'
            self.errors_found.append(f"Basic initialization failed: {e}")

        self.test_results.update(test_results)
        return test_results

    def test_advanced_features(self):
        """Teste erweiterte Features"""
        print("\n🚀 Teste erweiterte Features...")

        test_results = {'advanced_tests': {}}

        try:
            analyzer = CostFreeDataAnalyzer('test_data.xlsx')
            analyzer.df = self.test_data.copy()

            # 1. Auto Data Profiling
            try:
                profiling_result = analyzer.run_auto_data_profiling(apply_fixes=False)
                if isinstance(profiling_result, dict) and 'dataset_overview' in profiling_result:
                    test_results['advanced_tests']['data_profiling'] = 'PASS'
                else:
                    test_results['advanced_tests']['data_profiling'] = 'FAIL'
                    self.errors_found.append("Auto Data Profiling returned invalid format")
            except Exception as e:
                test_results['advanced_tests']['data_profiling'] = 'FAIL'
                self.errors_found.append(f"Auto Data Profiling failed: {e}")

            # 2. Advanced Quality Scoring
            try:
                quality_result = analyzer.calculate_advanced_quality_score(industry='general', apply_fixes=False)
                if isinstance(quality_result, dict) and 'overall_score' in quality_result:
                    test_results['advanced_tests']['quality_scoring'] = 'PASS'
                else:
                    test_results['advanced_tests']['quality_scoring'] = 'FAIL'
                    self.errors_found.append("Advanced Quality Scoring returned invalid format")
            except Exception as e:
                test_results['advanced_tests']['quality_scoring'] = 'FAIL'
                self.errors_found.append(f"Advanced Quality Scoring failed: {e}")

            # 3. Advanced NLP Processing
            try:
                nlp_result = analyzer.run_advanced_nlp_processing(apply_fixes=False)
                if isinstance(nlp_result, dict) and 'overall_nlp_score' in nlp_result:
                    test_results['advanced_tests']['nlp_processing'] = 'PASS'
                else:
                    test_results['advanced_tests']['nlp_processing'] = 'FAIL'
                    self.errors_found.append("Advanced NLP Processing returned invalid format")
            except Exception as e:
                test_results['advanced_tests']['nlp_processing'] = 'FAIL'
                self.errors_found.append(f"Advanced NLP Processing failed: {e}")

            # 4. Statistical Validation
            try:
                stats_result = analyzer.run_advanced_statistical_validation(apply_fixes=False)
                if isinstance(stats_result, dict) and 'statistical_outliers' in stats_result:
                    test_results['advanced_tests']['statistical_validation'] = 'PASS'
                else:
                    test_results['advanced_tests']['statistical_validation'] = 'FAIL'
                    self.errors_found.append("Statistical Validation returned invalid format")
            except Exception as e:
                test_results['advanced_tests']['statistical_validation'] = 'FAIL'
                self.errors_found.append(f"Statistical Validation failed: {e}")

        except Exception as e:
            self.errors_found.append(f"Advanced features initialization failed: {e}")

        self.test_results.update(test_results)
        return test_results

    def test_self_healing_pipeline(self):
        """Teste Self-Healing Pipeline"""
        print("\n🔧 Teste Self-Healing Pipeline...")

        test_results = {'self_healing_tests': {}}

        try:
            analyzer = CostFreeDataAnalyzer('test_data.xlsx')
            analyzer.df = self.test_data.copy()

            # Teste verschiedene Self-Healing Operationen
            operations = ['load_data', 'clean_contacts', 'analyze_structure', 'detect_duplicates']

            for operation in operations:
                try:
                    result = analyzer.run_self_healing_operation(operation)
                    if result is not None:
                        test_results['self_healing_tests'][f'operation_{operation}'] = 'PASS'
                    else:
                        test_results['self_healing_tests'][f'operation_{operation}'] = 'FAIL'
                        self.warnings_found.append(f"Self-healing operation {operation} returned None")
                except Exception as e:
                    test_results['self_healing_tests'][f'operation_{operation}'] = 'FAIL'
                    self.errors_found.append(f"Self-healing operation {operation} failed: {e}")

        except Exception as e:
            self.errors_found.append(f"Self-healing pipeline test failed: {e}")

        self.test_results.update(test_results)
        return test_results

    def test_backup_and_lineage(self):
        """Teste Backup und Data Lineage"""
        print("\n💾 Teste Backup und Data Lineage...")

        test_results = {'backup_lineage_tests': {}}

        try:
            analyzer = CostFreeDataAnalyzer('test_data.xlsx')
            analyzer.df = self.test_data.copy()

            # 1. Backup-Erstellung
            try:
                backup_id = analyzer.backup_manager.create_backup(analyzer.df, "test_operation")
                if backup_id:
                    test_results['backup_lineage_tests']['create_backup'] = 'PASS'
                else:
                    test_results['backup_lineage_tests']['create_backup'] = 'FAIL'
                    self.errors_found.append("Backup creation failed - no ID returned")
            except Exception as e:
                test_results['backup_lineage_tests']['create_backup'] = 'FAIL'
                self.errors_found.append(f"Backup creation failed: {e}")

            # 2. Backup-Liste
            try:
                backups = analyzer.list_available_backups()
                if isinstance(backups, list):
                    test_results['backup_lineage_tests']['list_backups'] = 'PASS'
                else:
                    test_results['backup_lineage_tests']['list_backups'] = 'FAIL'
                    self.errors_found.append("Backup list returned invalid format")
            except Exception as e:
                test_results['backup_lineage_tests']['list_backups'] = 'FAIL'
                self.errors_found.append(f"Backup list failed: {e}")

            # 3. Data Lineage
            try:
                lineage = analyzer.get_data_lineage()
                if isinstance(lineage, dict):
                    test_results['backup_lineage_tests']['data_lineage'] = 'PASS'
                else:
                    test_results['backup_lineage_tests']['data_lineage'] = 'FAIL'
                    self.errors_found.append("Data lineage returned invalid format")
            except Exception as e:
                test_results['backup_lineage_tests']['data_lineage'] = 'FAIL'
                self.errors_found.append(f"Data lineage failed: {e}")

        except Exception as e:
            self.errors_found.append(f"Backup and lineage test failed: {e}")

        self.test_results.update(test_results)
        return test_results

    def test_data_modifications_safe(self):
        """Teste sichere Datenmodifikationen"""
        print("\n🛡️ Teste sichere Datenmodifikationen...")

        test_results = {'modification_tests': {}}

        try:
            analyzer = CostFreeDataAnalyzer('test_data.xlsx')
            analyzer.df = self.test_data.copy()
            original_len = len(analyzer.df)

            # 1. Teste apply_fixes=True Operationen
            try:
                # Auto Profiling mit Fixes
                analyzer.run_auto_data_profiling(apply_fixes=True)

                # Prüfe ob DataFrame noch valide ist
                if len(analyzer.df) > 0 and analyzer.df is not None:
                    test_results['modification_tests']['profiling_fixes'] = 'PASS'
                else:
                    test_results['modification_tests']['profiling_fixes'] = 'FAIL'
                    self.errors_found.append("DataFrame corrupted after profiling fixes")

            except Exception as e:
                test_results['modification_tests']['profiling_fixes'] = 'FAIL'
                self.errors_found.append(f"Profiling fixes failed: {e}")

            # 2. Teste Quality Scoring mit Fixes
            try:
                analyzer.calculate_advanced_quality_score(apply_fixes=True)

                if len(analyzer.df) > 0:
                    test_results['modification_tests']['quality_fixes'] = 'PASS'
                else:
                    test_results['modification_tests']['quality_fixes'] = 'FAIL'
                    self.errors_found.append("DataFrame corrupted after quality fixes")

            except Exception as e:
                test_results['modification_tests']['quality_fixes'] = 'FAIL'
                self.errors_found.append(f"Quality fixes failed: {e}")

            # 3. Teste NLP Processing mit Fixes
            try:
                analyzer.run_advanced_nlp_processing(apply_fixes=True)

                if len(analyzer.df) > 0:
                    test_results['modification_tests']['nlp_fixes'] = 'PASS'
                else:
                    test_results['modification_tests']['nlp_fixes'] = 'FAIL'
                    self.errors_found.append("DataFrame corrupted after NLP fixes")

            except Exception as e:
                test_results['modification_tests']['nlp_fixes'] = 'FAIL'
                self.errors_found.append(f"NLP fixes failed: {e}")

        except Exception as e:
            self.errors_found.append(f"Data modification test failed: {e}")

        self.test_results.update(test_results)
        return test_results

    def test_edge_cases(self):
        """Teste Edge Cases und Grenzfälle"""
        print("\n⚠️ Teste Edge Cases...")

        test_results = {'edge_case_tests': {}}

        # 1. Leerer DataFrame
        try:
            analyzer = CostFreeDataAnalyzer('empty_data.xlsx')
            analyzer.df = pd.DataFrame()

            result = analyzer.analyze_data_structure()
            if isinstance(result, dict):
                test_results['edge_case_tests']['empty_dataframe'] = 'PASS'
            else:
                test_results['edge_case_tests']['empty_dataframe'] = 'FAIL'
                self.errors_found.append("Empty DataFrame handling failed")

        except Exception as e:
            test_results['edge_case_tests']['empty_dataframe'] = 'FAIL'
            self.errors_found.append(f"Empty DataFrame test failed: {e}")

        # 2. DataFrame mit nur NULL-Werten
        try:
            analyzer = CostFreeDataAnalyzer('null_data.xlsx')
            null_data = pd.DataFrame({
                'col1': [None, None, None],
                'col2': [np.nan, np.nan, np.nan],
                'col3': ['', '', '']
            })
            analyzer.df = null_data

            result = analyzer.run_auto_data_profiling(apply_fixes=False)
            if isinstance(result, dict):
                test_results['edge_case_tests']['null_dataframe'] = 'PASS'
            else:
                test_results['edge_case_tests']['null_dataframe'] = 'FAIL'
                self.errors_found.append("NULL DataFrame handling failed")

        except Exception as e:
            test_results['edge_case_tests']['null_dataframe'] = 'FAIL'
            self.errors_found.append(f"NULL DataFrame test failed: {e}")

        # 3. Sehr große Spaltenanzahl
        try:
            analyzer = CostFreeDataAnalyzer('wide_data.xlsx')
            wide_data = pd.DataFrame({f'col_{i}': ['test', 'data', 'value'] for i in range(100)})
            analyzer.df = wide_data

            result = analyzer.analyze_data_structure()
            if isinstance(result, dict) and result.get('total_columns') == 100:
                test_results['edge_case_tests']['wide_dataframe'] = 'PASS'
            else:
                test_results['edge_case_tests']['wide_dataframe'] = 'FAIL'
                self.errors_found.append("Wide DataFrame handling failed")

        except Exception as e:
            test_results['edge_case_tests']['wide_dataframe'] = 'FAIL'
            self.errors_found.append(f"Wide DataFrame test failed: {e}")

        # 4. Spezielle Zeichen und Encodings
        try:
            analyzer = CostFreeDataAnalyzer('special_chars.xlsx')
            special_data = pd.DataFrame({
                'names': ['Müller', 'Weiß', 'José', 'François', '北京'],
                'symbols': ['€', '$', '£', '¥', '₹'],
                'mixed': ['café', 'naïve', 'résumé', 'piñata', 'Москва']
            })
            analyzer.df = special_data

            result = analyzer.run_advanced_nlp_processing(apply_fixes=False)
            if isinstance(result, dict):
                test_results['edge_case_tests']['special_characters'] = 'PASS'
            else:
                test_results['edge_case_tests']['special_characters'] = 'FAIL'
                self.errors_found.append("Special characters handling failed")

        except Exception as e:
            test_results['edge_case_tests']['special_characters'] = 'FAIL'
            self.errors_found.append(f"Special characters test failed: {e}")

        self.test_results.update(test_results)
        return test_results

    def validate_class_dependencies(self):
        """Validiere Klassen-Abhängigkeiten"""
        print("\n🔗 Validiere Klassen-Abhängigkeiten...")

        test_results = {'dependency_tests': {}}

        try:
            # Teste alle Haupt-Klassen
            from cost_free_data_analysis import (
                BackupManager, DataLineageTracker, IncrementalProcessor,
                SelfHealingPipeline, AutoDataProfiler, AdvancedQualityScorer,
                AdvancedNLPProcessor, ConfidenceScoreCalculator
            )

            classes_to_test = [
                ('BackupManager', BackupManager),
                ('DataLineageTracker', DataLineageTracker),
                ('IncrementalProcessor', IncrementalProcessor),
                ('SelfHealingPipeline', SelfHealingPipeline),
                ('AutoDataProfiler', AutoDataProfiler),
                ('AdvancedQualityScorer', AdvancedQualityScorer),
                ('AdvancedNLPProcessor', AdvancedNLPProcessor),
                ('ConfidenceScoreCalculator', ConfidenceScoreCalculator)
            ]

            for class_name, class_obj in classes_to_test:
                try:
                    instance = class_obj()
                    test_results['dependency_tests'][f'class_{class_name}'] = 'PASS'
                except Exception as e:
                    test_results['dependency_tests'][f'class_{class_name}'] = 'FAIL'
                    self.errors_found.append(f"Class {class_name} initialization failed: {e}")

        except ImportError as e:
            test_results['dependency_tests']['import_classes'] = 'FAIL'
            self.errors_found.append(f"Class import failed: {e}")

        self.test_results.update(test_results)
        return test_results

    def generate_validation_report(self):
        """Generiere umfassenden Validierungs-Report"""
        print("\n📋 Generiere Validierungs-Report...")

        total_tests = 0
        passed_tests = 0

        for category, tests in self.test_results.items():
            for test_name, result in tests.items():
                total_tests += 1
                if result == 'PASS':
                    passed_tests += 1

        success_rate = (passed_tests / total_tests * 100) if total_tests > 0 else 0

        report = {
            'validation_summary': {
                'timestamp': datetime.now().isoformat(),
                'total_tests': total_tests,
                'passed_tests': passed_tests,
                'failed_tests': total_tests - passed_tests,
                'success_rate': round(success_rate, 1),
                'status': 'PASS' if success_rate >= 95 else 'FAIL' if success_rate < 80 else 'WARNING'
            },
            'detailed_results': self.test_results,
            'errors_found': self.errors_found,
            'warnings_found': self.warnings_found,
            'recommendations': self._generate_recommendations(success_rate)
        }

        return report

    def _generate_recommendations(self, success_rate):
        """Generiere Empfehlungen basierend auf Test-Ergebnissen"""
        recommendations = []

        if success_rate < 80:
            recommendations.append("🚨 KRITISCH: Erfolgsrate unter 80% - System nicht produktionsreif")
        elif success_rate < 95:
            recommendations.append("⚠️ WARNUNG: Erfolgsrate unter 95% - Überprüfung empfohlen")
        else:
            recommendations.append("✅ EXCELLENT: System ist produktionsreif")

        if len(self.errors_found) > 0:
            recommendations.append(f"🔧 {len(self.errors_found)} kritische Fehler müssen behoben werden")

        if len(self.warnings_found) > 0:
            recommendations.append(f"⚡ {len(self.warnings_found)} Warnungen sollten überprüft werden")

        # Spezifische Empfehlungen basierend auf fehlgeschlagenen Tests
        for category, tests in self.test_results.items():
            failed_tests = [test for test, result in tests.items() if result == 'FAIL']
            if failed_tests:
                recommendations.append(f"🎯 {category}: {len(failed_tests)} fehlgeschlagene Tests")

        return recommendations

def main():
    """Hauptfunktion für System-Validierung"""
    print("🧪 ADVANCED DATA CLEANSING SYSTEM VALIDATION")
    print("=" * 60)
    print("Führe umfassende System-Tests durch...\n")

    validator = SystemValidator()

    # Test-Daten erstellen
    if not validator.create_test_data():
        print("❌ ABBRUCH: Test-Daten konnten nicht erstellt werden")
        return

    # Test-Suite ausführen
    test_functions = [
        validator.test_basic_functionality,
        validator.test_advanced_features,
        validator.test_self_healing_pipeline,
        validator.test_backup_and_lineage,
        validator.test_data_modifications_safe,
        validator.test_edge_cases,
        validator.validate_class_dependencies
    ]

    for test_func in test_functions:
        try:
            test_func()
        except Exception as e:
            validator.errors_found.append(f"Test function {test_func.__name__} crashed: {e}")
            print(f"❌ Test {test_func.__name__} ist abgestürzt: {e}")

    # Validierungs-Report generieren
    report = validator.generate_validation_report()

    # Ergebnisse anzeigen
    print("\n" + "=" * 60)
    print("🎯 VALIDIERUNGS-ERGEBNISSE")
    print("=" * 60)

    summary = report['validation_summary']
    status_icon = "✅" if summary['status'] == 'PASS' else "⚠️" if summary['status'] == 'WARNING' else "❌"

    print(f"{status_icon} STATUS: {summary['status']}")
    print(f"📊 TESTS: {summary['passed_tests']}/{summary['total_tests']} erfolgreich ({summary['success_rate']}%)")
    print(f"🔥 ERRORS: {len(report['errors_found'])}")
    print(f"⚠️ WARNINGS: {len(report['warnings_found'])}")

    # Detaillierte Ergebnisse
    print(f"\n📋 DETAILLIERTE ERGEBNISSE:")
    for category, tests in report['detailed_results'].items():
        print(f"\n{category.upper()}:")
        for test_name, result in tests.items():
            icon = "✅" if result == 'PASS' else "❌"
            print(f"   {icon} {test_name}: {result}")

    # Fehler anzeigen
    if report['errors_found']:
        print(f"\n🚨 GEFUNDENE FEHLER:")
        for i, error in enumerate(report['errors_found'], 1):
            print(f"   {i}. {error}")

    # Warnungen anzeigen
    if report['warnings_found']:
        print(f"\n⚠️ WARNUNGEN:")
        for i, warning in enumerate(report['warnings_found'], 1):
            print(f"   {i}. {warning}")

    # Empfehlungen
    print(f"\n💡 EMPFEHLUNGEN:")
    for rec in report['recommendations']:
        print(f"   {rec}")

    # Report speichern
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    report_filename = f'System_Validation_Report_{timestamp}.json'

    try:
        import json
        with open(report_filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        print(f"\n💾 Vollständiger Report gespeichert: {report_filename}")
    except Exception as e:
        print(f"\n❌ Report konnte nicht gespeichert werden: {e}")

    print("\n" + "=" * 60)
    print("🏁 VALIDIERUNG ABGESCHLOSSEN")
    print("=" * 60)

    return summary['status'] == 'PASS'

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)